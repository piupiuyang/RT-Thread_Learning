/**
 * @file    agile_button.h
 * @brief   Agile Button 杞欢鍖呭ご鏂囦欢
 * @author  椹緳浼� (2544047213@qq.com)
 * @version 1.1.1
 * @date    2021-12-29
 *
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 Ma Longwei.
 * All rights reserved.</center></h2>
 *
 */

#ifndef __PKG_AGILE_BUTTON_H
#define __PKG_AGILE_BUTTON_H

#ifdef __cplusplus
extern "C" {
#endif

#include <rtthread.h>
#include <rtdevice.h>
#include <stdint.h>


/** @defgroup AGILE_BUTTON_Exported_Types Agile Button Exported Types
 * @{
 */

/**
 * @brief   Agile Button 瀵硅薄浜嬩欢
 */
enum agile_btn_event {
    BTN_PRESS_DOWN_EVENT = 0, /**< 鎸変笅浜嬩欢 */
    BTN_HOLD_EVENT,           /**< 鎸佺画鎸変笅鏈夋晥浜嬩欢 */
    BTN_PRESS_UP_EVENT,       /**< 寮硅捣浜嬩欢 */
    BTN_CLICK_EVENT,          /**< 鐐瑰嚮浜嬩欢 */
    BTN_EVENT_SUM             /**< 浜嬩欢鎬绘暟鐩� */
};

/**
 * @brief   Agile Button 瀵硅薄鐘舵��
 */
enum agile_btn_state {
    BTN_STATE_NONE_PRESS = 0, /**< 鏈寜涓嬬姸鎬� */
    BTN_STATE_CHECK_PRESS,    /**< 鎶栧姩妫�鏌ョ姸鎬� */
    BTN_STATE_PRESS_DOWN,     /**< 鎸変笅鐘舵�� */
    BTN_STATE_PRESS_HOLD,     /**< 鎸佺画鎸変笅鐘舵�� */
    BTN_STATE_PRESS_UP,       /**< 寮硅捣鐘舵�� */
};

typedef struct agile_btn agile_btn_t; /**< Agile Button 缁撴瀯浣� */

/**
 * @brief   Agile Button 缁撴瀯浣�
 */
struct agile_btn {
    uint8_t active;                                    /**< 婵�娲绘爣蹇� */
    uint8_t repeat_cnt;                                /**< 鎸夐敭閲嶆寜璁℃暟 */
    uint8_t elimination_time;                          /**< 鎸夐敭娑堟姈鏃堕棿(鍗曚綅ms,榛樿15ms) */
    enum agile_btn_event event;                        /**< 鎸夐敭瀵硅薄浜嬩欢 */
    enum agile_btn_state state;                        /**< 鎸夐敭瀵硅薄鐘舵�� */
    uint32_t hold_time;                                /**< 鎸夐敭鎸変笅鎸佺画鏃堕棿(鍗曚綅ms) */
    uint32_t prev_hold_time;                           /**< 缂撳瓨 hold_time 鍙橀噺 */
    uint32_t hold_cycle_time;                          /**< 鎸夐敭鎸変笅鍚庢寔缁皟鐢ㄥ洖璋冨嚱鏁扮殑鍛ㄦ湡(鍗曚綅ms,榛樿1s) */
    uint32_t two_interval_time;                        /**< 涓ゆ鎸夐敭鎸変笅闂撮殧鐨勮秴鏃舵椂闂� */
    uint32_t pin;                                      /**< 鎸夐敭寮曡剼 */
    uint32_t active_logic;                             /**< 鏈夋晥鐢靛钩(PIN_HIGH/PIN_LOW) */
    rt_tick_t tick_timeout;                            /**< 瓒呮椂鏃堕棿 */
    void (*event_cb[BTN_EVENT_SUM])(agile_btn_t *btn); /**< 鎸夐敭瀵硅薄浜嬩欢鍥炶皟鍑芥暟 */
    rt_slist_t slist;                                  /**< 鍗曞悜閾捐〃鑺傜偣 */
};

/**
 * @}
 */

/** @addtogroup AGILE_BUTTON_Exported_Functions
 * @{
 */
#ifdef RT_USING_HEAP
agile_btn_t *agile_btn_create(uint32_t pin, uint32_t active_logic, uint32_t pin_mode);
int agile_btn_delete(agile_btn_t *btn);
#endif

int agile_btn_init(agile_btn_t *btn, uint32_t pin, uint32_t active_logic, uint32_t pin_mode);
int agile_btn_start(agile_btn_t *btn);
int agile_btn_stop(agile_btn_t *btn);
int agile_btn_set_elimination_time(agile_btn_t *btn, uint8_t elimination_time);
int agile_btn_set_hold_cycle_time(agile_btn_t *btn, uint32_t hold_cycle_time);
int agile_btn_set_two_interval_time(agile_btn_t *btn, uint32_t two_interval_time);
int agile_btn_set_event_cb(agile_btn_t *btn, enum agile_btn_event event, void (*event_cb)(agile_btn_t *btn));
void agile_btn_process(void);
void agile_btn_env_init(void);
/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __PKG_AGILE_BUTTON_H */
