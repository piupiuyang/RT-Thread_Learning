/**
 * @file    agile_button.c
 * @brief   Agile Button 杞欢鍖呮簮鏂囦欢
 * @author  椹緳浼� (2544047213@qq.com)
 * @version 1.1.1
 * @date    2021-12-29
 *
 @verbatim
    浣跨敤锛�
    濡傛灉鏈娇鑳� PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT:
    1. agile_btn_env_init 鍒濆鍖栫幆澧�
    2. 鍒涘缓涓�涓嚎绋嬶紝鍛ㄦ湡璋冪敤 agile_btn_process锛屽缓璁懆鏈熸椂闂翠笉瑕佸お闀�

    - agile_btn_create / agile_btn_init 鍒涘缓 / 鍒濆鍖栧璞�
    - agile_btn_set_elimination_time 鏇存敼娑堟姈鏃堕棿锛屽彲蹇界暐
    - agile_btn_set_hold_cycle_time 鏇存敼鎸佺画鎸変笅瑙﹀彂鍛ㄦ湡鏃堕棿锛屽彲蹇界暐
      璇ユ搷浣滀篃鍙湪杩愯杩囩▼涓墽琛�
    - agile_btn_set_event_cb 璁剧疆浜嬩欢瑙﹀彂鍥炶皟
    - agile_btn_start 鍚姩杩愯
    - agile_btn_stop 杩愯杩囩▼涓己鍒跺仠姝�

 @endverbatim
 *
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 Ma Longwei.
 * All rights reserved.</center></h2>
 *
 */

#include <agile_button.h>

/** @defgroup RT_Thread_DBG_Configuration RT-Thread DBG Configuration
 * @{
 */

/** @name RT-Thread DBG 鍔熻兘閰嶇疆
 * @{
 */
#define DBG_ENABLE
#define DBG_COLOR
#define DBG_SECTION_NAME "agile_button"
#ifdef PKG_AGILE_BUTTON_DEBUG
#define DBG_LEVEL DBG_LOG
#else
#define DBG_LEVEL DBG_INFO
#endif
#include <rtdbg.h>
/**
 * @}
 */

/**
 * @}
 */

#ifdef PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT

/** @defgroup AGILE_BUTTON_Thread_Auto_Init Agile Button Thread Auto Init
 * @{
 */

/** @defgroup AGILE_BUTTON_Thread_Auto_Init_Configuration Agile Button Thread Auto Init Configuration
 * @{
 */

/** @name Agile Button 鑷姩鍒濆鍖栫嚎绋嬮厤缃�
 * @{
 */
#ifndef PKG_AGILE_BUTTON_THREAD_STACK_SIZE
#define PKG_AGILE_BUTTON_THREAD_STACK_SIZE 256 /**< Agile Button 绾跨▼鍫嗘爤澶у皬 */
#endif

#ifndef PKG_AGILE_BUTTON_THREAD_PRIORITY
#define PKG_AGILE_BUTTON_THREAD_PRIORITY RT_THREAD_PRIORITY_MAX - 4 /**< Agile Button 绾跨▼浼樺厛绾� */
#endif
/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */

#endif /* PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT */

/** @defgroup AGILE_BUTTON_Private_Constants Agile Button Private Constants
 * @{
 */
#define AGILE_BUTTON_ELIMINATION_TIME_DEFAULT  15   /**< 鎸夐敭娑堟姈榛樿鏃堕棿 15ms */
#define AGILE_BUTTON_TWO_INTERVAL_TIME_DEFAULT 500  /**< 涓ゆ鎸夐敭鎸変笅闂撮殧瓒呰繃500ms娓呴浂閲嶅璁℃暟 */
#define AGILE_BUTTON_HOLD_CYCLE_TIME_DEFAULT   1000 /**< 鎸夐敭鎸変笅鍚庢寔缁皟鐢ㄥ洖璋冨嚱鏁扮殑鍛ㄦ湡 */
/**
 * @}
 */

/** @defgroup AGILE_BUTTON_Private_Macros Agile Button Private Macros
 * @{
 */

/**
 * @brief   鑾峰彇鎸夐敭寮曡剼鐢靛钩鐘舵��
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @return  寮曡剼鐢靛钩
 */
#define AGILE_BUTTON_PIN_STATE(btn) rt_pin_read(btn->pin)

/**
 * @brief   璋冪敤鎸夐敭浜嬩欢鐨勫洖璋冨嚱鏁�
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @param   event 浜嬩欢绫诲瀷
 * @return  鏃�
 */
#define AGILE_BUTTON_EVENT_CB(btn, event) \
    do {                                  \
        RT_ASSERT(btn);                   \
        if (btn->event_cb[event]) {       \
            btn->event_cb[event](btn);    \
        }                                 \
    } while (0)

/**
 * @}
 */

/** @defgroup AGILE_BUTTON_Private_Variables Agile Button Private Variables
 * @{
 */
ALIGN(RT_ALIGN_SIZE)
static rt_slist_t _slist_head = RT_SLIST_OBJECT_INIT(_slist_head); /**< Agile Button 閾捐〃澶磋妭鐐� */
static struct rt_mutex _mtx;                                       /**< Agile Button 浜掓枼閿� */
static uint8_t _is_init = 0;                                       /**< Agile Button 鍒濆鍖栧畬鎴愭爣蹇� */

#ifdef PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT
static struct rt_thread _thread;                                  /**< Agile Button 绾跨▼鎺у埗鍧� */
static uint8_t _thread_stack[PKG_AGILE_BUTTON_THREAD_STACK_SIZE]; /**< Agile Button 绾跨▼鍫嗘爤 */
#endif
/**
 * @}
 */

/** @defgroup AGILE_BUTTON_Private_Functions Agile Button Private Functions
 * @{
 */

/**
 * @brief   璁＄畻鎸夐敭鎸変笅鎸佺画鏃堕棿
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 */
static void agile_btn_cal_hold_time(agile_btn_t *btn)
{
    RT_ASSERT(btn);

    if (rt_tick_get() < btn->tick_timeout) {
        btn->hold_time = RT_TICK_MAX - btn->tick_timeout + rt_tick_get();
    } else {
        btn->hold_time = rt_tick_get() - btn->tick_timeout;
    }
    btn->hold_time = btn->hold_time * (1000 / RT_TICK_PER_SECOND);
}

/**
 * @}
 */

/** @defgroup AGILE_BUTTON_Exported_Functions Agile Button Exported Functions
 * @{
 */

#ifdef RT_USING_HEAP

/**
 * @brief   鍒涘缓 Agile Button 瀵硅薄
 * @param   pin 鎸夐敭寮曡剼
 * @param   active_logic 鏈夋晥鐢靛钩
 * @param   pin_mode 寮曡剼妯″紡
 * @return  !=RT_NULL:Agile Button 瀵硅薄鎸囬拡; RT_NULL:寮傚父
 */
agile_btn_t *agile_btn_create(uint32_t pin, uint32_t active_logic, uint32_t pin_mode)
{
    if (!_is_init) {
        LOG_E("Please call agile_btn_env_init first.");
        return RT_NULL;
    }

    agile_btn_t *btn = (agile_btn_t *)rt_malloc(sizeof(agile_btn_t));
    if (btn == RT_NULL)
        return RT_NULL;

    rt_memset(btn, 0, sizeof(agile_btn_t));
    btn->active = 0;
    btn->repeat_cnt = 0;
    btn->elimination_time = AGILE_BUTTON_ELIMINATION_TIME_DEFAULT;
    btn->event = BTN_EVENT_SUM;
    btn->state = BTN_STATE_NONE_PRESS;
    btn->hold_time = 0;
    btn->prev_hold_time = 0;
    btn->hold_cycle_time = AGILE_BUTTON_HOLD_CYCLE_TIME_DEFAULT;
    btn->two_interval_time = AGILE_BUTTON_TWO_INTERVAL_TIME_DEFAULT;
    btn->pin = pin;
    btn->active_logic = active_logic;
    btn->tick_timeout = rt_tick_get();
    rt_slist_init(&(btn->slist));

    rt_pin_mode(pin, pin_mode);

    return btn;
}

/**
 * @brief   鍒犻櫎 Agile Button 瀵硅薄
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @return  RT_EOK:鎴愬姛
 */
int agile_btn_delete(agile_btn_t *btn)
{
    RT_ASSERT(btn);

    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    rt_slist_remove(&_slist_head, &(btn->slist));
    btn->slist.next = RT_NULL;
    rt_mutex_release(&_mtx);
    rt_free(btn);

    return RT_EOK;
}

#endif /* RT_USING_HEAP */

/**
 * @brief   鍒濆鍖� Agile Button 瀵硅薄
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @param   pin 鎸夐敭寮曡剼
 * @param   active_logic 鏈夋晥鐢靛钩
 * @param   pin_mode 寮曡剼妯″紡
 * @return  RT_EOK:鎴愬姛; !=RT_EOK:寮傚父
 */
int agile_btn_init(agile_btn_t *btn, uint32_t pin, uint32_t active_logic, uint32_t pin_mode)
{
    RT_ASSERT(btn);

    if (!_is_init) {
        LOG_E("Please call agile_btn_env_init first.");
        return -RT_ERROR;
    }

    rt_memset(btn, 0, sizeof(agile_btn_t));
    btn->active = 0;
    btn->repeat_cnt = 0;
    btn->elimination_time = AGILE_BUTTON_ELIMINATION_TIME_DEFAULT;
    btn->event = BTN_EVENT_SUM;
    btn->state = BTN_STATE_NONE_PRESS;
    btn->hold_time = 0;
    btn->prev_hold_time = 0;
    btn->hold_cycle_time = AGILE_BUTTON_HOLD_CYCLE_TIME_DEFAULT;
    btn->pin = pin;
    btn->active_logic = active_logic;
    btn->tick_timeout = rt_tick_get();
    rt_slist_init(&(btn->slist));

    rt_pin_mode(pin, pin_mode);

    return RT_EOK;
}

/**
 * @brief   鍚姩 Agile Button 瀵硅薄
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @return  RT_EOK:鎴愬姛; !=RT_OK:寮傚父
 */
int agile_btn_start(agile_btn_t *btn)
{
    RT_ASSERT(btn);

    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    if (btn->active) {
        rt_mutex_release(&_mtx);
        return -RT_ERROR;
    }
    btn->repeat_cnt = 0;
    btn->event = BTN_EVENT_SUM;
    btn->state = BTN_STATE_NONE_PRESS;
    btn->hold_time = 0;
    btn->prev_hold_time = 0;
    btn->tick_timeout = rt_tick_get();
    rt_slist_append(&_slist_head, &(btn->slist));
    btn->active = 1;
    rt_mutex_release(&_mtx);

    return RT_EOK;
}

/**
 * @brief   鍋滄 Agile Button 瀵硅薄
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @return  RT_EOK:鎴愬姛
 */
int agile_btn_stop(agile_btn_t *btn)
{
    RT_ASSERT(btn);

    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    if (!btn->active) {
        rt_mutex_release(&_mtx);
        return RT_EOK;
    }
    rt_slist_remove(&_slist_head, &(btn->slist));
    btn->slist.next = RT_NULL;
    btn->active = 0;
    rt_mutex_release(&_mtx);

    return RT_EOK;
}

/**
 * @brief   璁剧疆鎸夐敭娑堟姈鏃堕棿
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @param   elimination_time 娑堟姈鏃堕棿(鍗曚綅ms)
 * @return  RT_EOK:鎴愬姛
 */
int agile_btn_set_elimination_time(agile_btn_t *btn, uint8_t elimination_time)
{
    RT_ASSERT(btn);

    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    btn->elimination_time = elimination_time;
    rt_mutex_release(&_mtx);

    return RT_EOK;
}

/**
 * @brief   璁剧疆鎸夐敭鎸変笅鍚� BTN_HOLD_EVENT 浜嬩欢鍥炶皟鍑芥暟鐨勫懆鏈�
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @param   hold_cycle_time 鍛ㄦ湡鏃堕棿(鍗曚綅ms)
 * @return  RT_EOK:鎴愬姛
 */
int agile_btn_set_hold_cycle_time(agile_btn_t *btn, uint32_t hold_cycle_time)
{
    RT_ASSERT(btn);

    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    btn->hold_cycle_time = hold_cycle_time;
    rt_mutex_release(&_mtx);

    return RT_EOK;
}

/**
 * @brief   璁剧疆涓ゆ鎸夐敭鎸変笅闂撮殧鐨勮秴鏃舵椂闂�
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @param   two_interval_time 瓒呮椂鏃堕棿(鍗曚綅ms)
 * @return  RT_EOK:鎴愬姛
 */
int agile_btn_set_two_interval_time(agile_btn_t *btn, uint32_t two_interval_time)
{
    RT_ASSERT(btn);

    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    btn->two_interval_time = two_interval_time;
    rt_mutex_release(&_mtx);

    return RT_EOK;
}

/**
 * @brief   璁剧疆鎸夐敭浜嬩欢鍥炶皟鍑芥暟
 * @param   btn Agile Button 瀵硅薄鎸囬拡
 * @param   event 浜嬩欢绫诲瀷
 * @param   event_cb 浜嬩欢鍥炶皟鍑芥暟
 * @return  RT_EOK:鎴愬姛; !=RT_OK:寮傚父
 */
int agile_btn_set_event_cb(agile_btn_t *btn, enum agile_btn_event event, void (*event_cb)(agile_btn_t *btn))
{
    RT_ASSERT(btn);

    if (event >= BTN_EVENT_SUM)
        return -RT_ERROR;
    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    btn->event_cb[event] = event_cb;
    rt_mutex_release(&_mtx);

    return RT_EOK;
}

/**
 * @brief   澶勭悊鎵�鏈� Agile Button 瀵硅薄
 * @note    濡傛灉浣胯兘 PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT, 杩欎釜鍑芥暟灏嗚鑷姩鍒濆鍖栫嚎绋� 5ms 鍛ㄦ湡璋冪敤銆�
 *          鐢ㄦ埛璋冪敤闇�瑕佸垱寤轰竴涓嚎绋嬪苟灏嗚繖涓嚱鏁版斁鍏� while (1) {} 涓��
 */
void agile_btn_process(void)
{
    rt_slist_t *node;

    rt_mutex_take(&_mtx, RT_WAITING_FOREVER);
    rt_slist_for_each(node, &_slist_head)
    {
        agile_btn_t *btn = rt_slist_entry(node, agile_btn_t, slist);
        switch (btn->state) {
        case BTN_STATE_NONE_PRESS: {
            if (AGILE_BUTTON_PIN_STATE(btn) == btn->active_logic) {
                btn->tick_timeout = rt_tick_get() + rt_tick_from_millisecond(btn->elimination_time);
                btn->state = BTN_STATE_CHECK_PRESS;
            } else {
                /* 2娆℃寜涓嬩腑闂撮棿闅旇繃澶э紝娓呴浂閲嶆寜璁℃暟 */
                if (btn->repeat_cnt) {
                    if ((rt_tick_get() - btn->tick_timeout) < (RT_TICK_MAX / 2)) {
                        btn->event = BTN_CLICK_EVENT;
                        AGILE_BUTTON_EVENT_CB(btn, btn->event);
                        btn->repeat_cnt = 0;
                    }
                }
            }
        } break;
        case BTN_STATE_CHECK_PRESS: {
            if (AGILE_BUTTON_PIN_STATE(btn) == btn->active_logic) {
                if ((rt_tick_get() - btn->tick_timeout) < (RT_TICK_MAX / 2)) {
                    btn->state = BTN_STATE_PRESS_DOWN;
                }
            } else {
                btn->state = BTN_STATE_NONE_PRESS;
            }
        } break;
        case BTN_STATE_PRESS_DOWN: {
            btn->hold_time = 0;
            btn->prev_hold_time = 0;
            btn->repeat_cnt++;
            btn->event = BTN_PRESS_DOWN_EVENT;
            AGILE_BUTTON_EVENT_CB(btn, btn->event);

            btn->tick_timeout = rt_tick_get();
            btn->state = BTN_STATE_PRESS_HOLD;
        } break;
        case BTN_STATE_PRESS_HOLD: {
            if (AGILE_BUTTON_PIN_STATE(btn) == btn->active_logic) {
                agile_btn_cal_hold_time(btn);
                if (btn->hold_time - btn->prev_hold_time >= btn->hold_cycle_time) {
                    btn->event = BTN_HOLD_EVENT;
                    AGILE_BUTTON_EVENT_CB(btn, btn->event);
                    btn->prev_hold_time = btn->hold_time;
                }
            } else {
                btn->state = BTN_STATE_PRESS_UP;
            }
        } break;
        case BTN_STATE_PRESS_UP: {
            btn->event = BTN_PRESS_UP_EVENT;
            AGILE_BUTTON_EVENT_CB(btn, btn->event);

            btn->tick_timeout = rt_tick_get() + rt_tick_from_millisecond(btn->two_interval_time);
            btn->state = BTN_STATE_NONE_PRESS;
        } break;
        default:
            break;
        }
    }
    rt_mutex_release(&_mtx);
}

/**
 * @brief   Agile Button 鐜鍒濆鍖�
 * @note    浣跨敤鍏朵粬 API 涔嬪墠璇ュ嚱鏁板繀椤昏璋冪敤銆�
 *          濡傛灉浣胯兘 PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT, 杩欎釜鍑芥暟灏嗚鑷姩璋冪敤銆�
 */
void agile_btn_env_init(void)
{
    if (_is_init)
        return;

    rt_mutex_init(&_mtx, "btn_mtx", RT_IPC_FLAG_FIFO);

    _is_init = 1;
}

/**
 * @}
 */

#ifdef PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT

/** @addtogroup AGILE_BUTTON_Thread_Auto_Init
 * @{
 */

/** @defgroup AGILE_BUTTON_Thread_Auto_Init_Functions Agile Button Thread Auto Init Functions
 * @{
 */

/**
 * @brief   Agile Button 鍐呴儴绾跨▼鍑芥暟鍏ュ彛
 * @param   parameter 绾跨▼鍙傛暟
 */
static void agile_btn_auto_thread_entry(void *parameter)
{
    while (1) {
        agile_btn_process();
        rt_thread_mdelay(5);
    }
}

/**
 * @brief   Agile Button 鍐呴儴绾跨▼鍒濆鍖�
 * @return  RT_EOK:鎴愬姛
 */
static int agile_btn_auto_thread_init(void)
{
    agile_btn_env_init();

    rt_thread_init(&_thread,
                   "agbtn",
                   agile_btn_auto_thread_entry,
                   RT_NULL,
                   &_thread_stack[0],
                   sizeof(_thread_stack),
                   PKG_AGILE_BUTTON_THREAD_PRIORITY,
                   100);

    rt_thread_startup(&_thread);

    return RT_EOK;
}
INIT_ENV_EXPORT(agile_btn_auto_thread_init);

/**
 * @}
 */

/**
 * @}
 */

#endif /* PKG_AGILE_BUTTON_USING_THREAD_AUTO_INIT */
