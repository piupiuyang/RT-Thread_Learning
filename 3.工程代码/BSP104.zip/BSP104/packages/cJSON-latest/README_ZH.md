# cJSON for RT-Thread

中文页 | [English](README.md)

超轻量级的 C 语言 json 解析库 

官方仓库：https://github.com/DaveGamble/cJSON


维护：[Meco Man](https://github.com/mysterywolf)

主页：https://github.com/RT-Thread-packages/cJSON
