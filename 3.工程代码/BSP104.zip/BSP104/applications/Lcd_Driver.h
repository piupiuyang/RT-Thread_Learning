/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-07-26     piupiuY       the first version
 */
#include <rtthread.h>
#include <rthw.h>
#include <rtdevice.h>
#include <drv_spi.h>
#define RED       0xf800
#define GREEN     0x07e0
#define BLUE      0x001f
#define WHITE     0xffff
#define BLACK     0x0000
#define YELLOW  0xFFE0
#define GRAY0   0xEF7D          //��ɫ0 3165 00110 001011 00101
#define GRAY1   0x8410          //��ɫ1 00000 000000 00000
#define GRAY2   0x4208          //��ɫ2  1111111111011111
#define DISPALY_DIRECTION 0  //0����   1����  2��ֱ��ת180��  Ĭ�Ϻ�����ת180��
//SPI1
#if 0
#define LCD_LED_PIN         GET_PIN(B,0)  //PB0--->>TFT--LED
#define LCD_SCL_PIN         GET_PIN(A,5) //PA5--->>TFT--SCL/SCK
#define LCD_SDA_PIN         GET_PIN(A,7) //PA7 MOSI--->>TFT--SDA/DIN
#define LCD_RS_PIN          GET_PIN(E,10) //PB1--->>TFT --RS/DC
#define LCD_RST_PIN         GET_PIN(E,11)   //PB2--->>TFT --RST
#define LCD_CS_PIN          GET_PIN(A,4)  //PA4--->>TFT --CS/CE
#endif
#if 0
//SPI1�ض���
//#define LCD_CTRL              //����TFT���ݶ˿�
#define LCD_LED_PIN         GET_PIN(B,0)  //PB0--->>TFT--LED
#define LCD_SCL_PIN         GET_PIN(E,7) //PA5--->>TFT--SCL/SCK
#define LCD_SDA_PIN         GET_PIN(E,9) //PA7 MOSI--->>TFT--SDA/DIN
#define LCD_RS_PIN          GET_PIN(E,10) //PB1--->>TFT --RS/DC
#define LCD_RST_PIN         GET_PIN(E,11)   //PB2--->>TFT --RST
#define LCD_CS_PIN          GET_PIN(B,2)  //PA4--->>TFT --CS/CE
#endif
//SPI2
#if 1
#define LCD_LED_PIN         GET_PIN(B,0)  //PB0--->>TFT--LED
#define LCD_SCL_PIN         GET_PIN(B,13) //PA5--->>TFT--SCL/SCK
#define LCD_SDA_PIN         GET_PIN(B,15) //PA7 MOSI--->>TFT--SDA/DIN
#define LCD_RS_PIN          GET_PIN(E,10) //PB1--->>TFT --RS/DC
#define LCD_RST_PIN         GET_PIN(E,11)   //PB2--->>TFT --RST
#define LCD_CS_PIN          GET_PIN(B,12)  //PA4--->>TFT --CS/CE
#endif


//#define LCD_CS_SET(x) LCD_CTRL->ODR=(LCD_CTRL->ODR&~LCD_CS)|(x ? LCD_CS:0)
//Һ�����ƿ���1�������궨��

#define LCD_CS_SET      rt_pin_write(LCD_CS_PIN,PIN_HIGH)
#define LCD_RST_SET     rt_pin_write(LCD_RST_PIN,PIN_HIGH)
#define LCD_RS_SET      rt_pin_write(LCD_RS_PIN,PIN_HIGH)
#define LCD_SDA_SET     rt_pin_write(LCD_SDA_PIN ,PIN_HIGH)
#define LCD_SCL_SET     rt_pin_write(LCD_SCL_PIN,PIN_HIGH)
#define LCD_LED_SET     rt_pin_write(LCD_LED_PIN,PIN_HIGH)

//Һ�����ƿ���0�������궨��
#define LCD_CS_CLR      rt_pin_write(LCD_CS_PIN,PIN_LOW)
#define LCD_RST_CLR     rt_pin_write(LCD_RST_PIN,PIN_LOW)
#define LCD_RS_CLR      rt_pin_write(LCD_RS_PIN,PIN_LOW)
#define LCD_SDA_CLR     rt_pin_write(LCD_SDA_PIN,PIN_LOW)
#define LCD_SCL_CLR     rt_pin_write(LCD_SCL_PIN,PIN_LOW)
#define LCD_LED_CLR     rt_pin_write(LCD_LED_PIN,PIN_LOW)
//#define LCD_DATAOUT(x) LCD_DATA->ODR=x; //�������
//#define LCD_DATAIN     LCD_DATA->IDR;   //��������
//#define LCD_WR_DATA(data){\

/*LCD_RS_SET;
LCD_CS_CLR;\
LCD_DATAOUT(data);\
LCD_WR_CLR;\
LCD_WR_SET;\
LCD_CS_SET;\*/



void LCD_GPIO_Init(void);
void Lcd_WriteIndex(u8 Index);
void Lcd_WriteData(u8 Data);
void Lcd_WriteReg(u8 Index,u8 Data);
u16 Lcd_ReadReg(u8 LCD_Reg);
void Lcd_Reset(void);
int Lcd_Init(void);
void Lcd_Clear(u16 Color);
void Lcd_SetXY(u16 x,u16 y);
void Gui_DrawPoint(u16 x,u16 y,u16 Data);
void lv_Gui_DrawPoint(u16 x,u16 y,u16 *Data);
void LV_LCD_Fill(u16 sx,u16 sy,u16 ex,u16 ey,u16 *color);
unsigned int Lcd_ReadPoint(u16 x,u16 y);
void Lcd_SetRegion(u16 x_start,u16 y_start,u16 x_end,u16 y_end);
void LCD_WriteData_16Bit(u16 Data);

