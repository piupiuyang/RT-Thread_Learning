/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-07-26     piupiuY       the first version
 */
#ifndef LIBRARIES_N32_DRIVERS_DRV_LCD_C_

#define LIBRARIES_N32_DRIVERS_DRV_LCD_C_

#include <rthw.h>
#include <rtthread.h>
#include "board.h"
#include <Lcd_Driver.h>


#define SPI_LCD_BUS_NAME "spi2" //lcd将要挂载的总线名称
#define SPI_LCD_NAME "spi20"//lcd 设备名

struct stm32_hw_spi_cs//片选引脚句柄
{
    rt_uint32_t pin;
};

static struct stm32_hw_spi_cs  spi_cs;

struct rt_spi_device spi_dev_lcd ;//lcd设备句柄
struct rt_spi_device *dev_lcd =RT_NULL ;//lcd设备句柄

void LCD_GPIO_Init(){//要用的IO口初始化
    rt_pin_mode(LCD_RST_PIN,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_CS_PIN,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_RS_PIN,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_LED_PIN,PIN_MODE_OUTPUT);

}


void  SPI_WriteData(rt_uint8_t Data)
{
    rt_spi_send(dev_lcd, &Data, 1);
}
//向液晶屏写一个8位指令
void Lcd_WriteIndex(rt_uint8_t Index)
{
   //SPI 写命令时序开始
  // LCD_CS_CLR;
   LCD_RS_CLR;
   SPI_WriteData(Index);
   //LCD_RS_SET;
   //LCD_CS_SET;

}

//向液晶屏写一个8位数据
void Lcd_WriteData(rt_uint8_t Data)
{
   //LCD_CS_CLR;
   LCD_RS_SET;
   SPI_WriteData(Data);
   //LCD_CS_SET;
}
//向液晶屏写一个16位数据
void LCD_WriteData_16Bit(rt_uint16_t Data)
{
    LCD_RS_SET;
    SPI_WriteData(Data>>8);      //写入高8位数据
    SPI_WriteData(Data);           //写入低8位数据

}

void Lv_LCD_WriteData_16Bit(rt_uint16_t* Data)
{
    uint8_t datahi;
    uint8_t datalo;
    datalo = (*Data)&0xff;
    datahi = (*Data)>>8;
    LCD_RS_SET;
    SPI_WriteData(datahi);      //写入高8位数据
    SPI_WriteData(datalo);           //写入低8位数据

}

void Lcd_WriteReg(rt_uint8_t Index,rt_uint8_t Data)
{
    Lcd_WriteIndex(Index);
    Lcd_WriteData(Data);
}

void Lcd_Reset(void)
{
    LCD_RST_CLR;
    rt_thread_mdelay(100);
    LCD_RST_SET;
    rt_thread_mdelay(50);
}


int SPI_Lcd_device_Init(void){
      rt_err_t rtn;
      spi_cs.pin=LCD_CS_PIN;//片选引脚赋值
       rtn = rt_spi_bus_attach_device(&spi_dev_lcd, SPI_LCD_NAME, SPI_LCD_BUS_NAME, (void *)&spi_cs);
       if(rtn == !RT_EOK){
           rt_kprintf("Lcd_Init run failed! attach failed %s device!\n", SPI_LCD_NAME);
           return -1;
       }else{
           struct rt_spi_configuration cfg;//lcd 配置
           spi_dev_lcd.bus->owner = &spi_dev_lcd;
           cfg.data_width = 8;
           cfg.mode = RT_SPI_MASTER | RT_SPI_MODE_3 | RT_SPI_MSB;
           cfg.max_hz = 18 * 1000 *1000;                           /* 20M */

           rt_spi_configure(&spi_dev_lcd, &cfg);
       }
       return RT_EOK;
}
INIT_DEVICE_EXPORT(SPI_Lcd_device_Init);
//LCD Init For 1.44Inch LCD Panel with ST7735R.
int Lcd_Init(void)
{

    LCD_GPIO_Init();
    //LCD_CS_CLR;
    dev_lcd = (struct rt_spi_device*)rt_device_find(SPI_LCD_NAME);
        if(dev_lcd == RT_NULL){
            rt_kprintf("Lcd_Init run failed! can't find %s device!\n", SPI_LCD_NAME);
            return RT_ERROR;
        }

    Lcd_Reset(); //Reset before LCD Init.
    LCD_LED_SET;
    //LCD Init For 1.44Inch LCD Panel with ST7735R.
    Lcd_WriteIndex(0x11);//Sleep exit
    rt_thread_mdelay(100);
    //ST7735R Frame Rate
    Lcd_WriteIndex(0xB1);
    Lcd_WriteData(0x01);
    Lcd_WriteData(0x2C);
    Lcd_WriteData(0x2D);

    Lcd_WriteIndex(0xB2);
    Lcd_WriteData(0x01);
    Lcd_WriteData(0x2C);
    Lcd_WriteData(0x2D);

    Lcd_WriteIndex(0xB3);
    Lcd_WriteData(0x01);
    Lcd_WriteData(0x2C);
    Lcd_WriteData(0x2D);
    Lcd_WriteData(0x01);
    Lcd_WriteData(0x2C);
    Lcd_WriteData(0x2D);

    Lcd_WriteIndex(0xB4); //Column inversion
    Lcd_WriteData(0x07);

    //ST7735R Power Sequence
    Lcd_WriteIndex(0xC0);
    Lcd_WriteData(0xA2);
    Lcd_WriteData(0x02);
    Lcd_WriteData(0x84);
    Lcd_WriteIndex(0xC1);
    Lcd_WriteData(0xC5);

    Lcd_WriteIndex(0xC2);
    Lcd_WriteData(0x0A);
    Lcd_WriteData(0x00);

    Lcd_WriteIndex(0xC3);
    Lcd_WriteData(0x8A);
    Lcd_WriteData(0x2A);
    Lcd_WriteIndex(0xC4);
    Lcd_WriteData(0x8A);
    Lcd_WriteData(0xEE);

    Lcd_WriteIndex(0xC5); //VCOM
    Lcd_WriteData(0x0E);

    Lcd_WriteIndex(0x36); //MX, MY, RGB mode

    switch(DISPALY_DIRECTION){//显示方向
        case 0: Lcd_WriteData(0xC8);break;
        case 1: Lcd_WriteData(0xA8);break;
        case 2: Lcd_WriteData(0x08);break;
        default:Lcd_WriteData(68);break;
    }


    //ST7735R Gamma Sequence
    Lcd_WriteIndex(0xe0);
    Lcd_WriteData(0x0f);
    Lcd_WriteData(0x1a);
    Lcd_WriteData(0x0f);
    Lcd_WriteData(0x18);
    Lcd_WriteData(0x2f);
    Lcd_WriteData(0x28);
    Lcd_WriteData(0x20);
    Lcd_WriteData(0x22);
    Lcd_WriteData(0x1f);
    Lcd_WriteData(0x1b);
    Lcd_WriteData(0x23);
    Lcd_WriteData(0x37);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x07);
    Lcd_WriteData(0x02);
    Lcd_WriteData(0x10);

    Lcd_WriteIndex(0xe1);
    Lcd_WriteData(0x0f);
    Lcd_WriteData(0x1b);
    Lcd_WriteData(0x0f);
    Lcd_WriteData(0x17);
    Lcd_WriteData(0x33);
    Lcd_WriteData(0x2c);
    Lcd_WriteData(0x29);
    Lcd_WriteData(0x2e);
    Lcd_WriteData(0x30);
    Lcd_WriteData(0x30);
    Lcd_WriteData(0x39);
    Lcd_WriteData(0x3f);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x07);
    Lcd_WriteData(0x03);
    Lcd_WriteData(0x10);

    Lcd_WriteIndex(0x2a);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x7f);

    Lcd_WriteIndex(0x2b);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x00);
    Lcd_WriteData(0x9f);

    Lcd_WriteIndex(0xF0); //Enable test command
    Lcd_WriteData(0x01);
    Lcd_WriteIndex(0xF6); //Disable ram power save mode
    Lcd_WriteData(0x00);

    Lcd_WriteIndex(0x3A); //65k mode
    Lcd_WriteData(0x05);
    Lcd_WriteIndex(0x29);//Display on
    rt_thread_mdelay(100);
    Lcd_Clear(GRAY0);


    return RT_EOK;
}

/*************************************************
函数名：LCD_Set_Region
功能：设置lcd显示区域，在此区域写点数据自动换行
入口参数：xy起点和终点
返回值：无
*************************************************/
void Lcd_SetRegion(u16 x_start,u16 y_start,u16 x_end,u16 y_end)
{
        Lcd_WriteIndex(0x2a);
        Lcd_WriteData(0x00);
        Lcd_WriteData(x_start+2);
        Lcd_WriteData(0x00);
        Lcd_WriteData(x_end+2);

        Lcd_WriteIndex(0x2b);
        Lcd_WriteData(0x00);
        Lcd_WriteData(y_start+3);
        Lcd_WriteData(0x00);
        Lcd_WriteIndex(0x2c);


}

/*************************************************
函数名：LCD_Set_XY
功能：设置lcd显示起始点
入口参数：xy坐标
返回值：无
*************************************************/
void Lcd_SetXY(u16 x,u16 y)
{
    Lcd_SetRegion(x,y,x,y);
}


/*************************************************
函数名：LCD_DrawPoint
功能：画一个点
入口参数：无
返回值：无
*************************************************/
void Gui_DrawPoint(u16 x,u16 y,u16 Data)
{
    Lcd_SetRegion(x,y,x+1,y+1);
    LCD_WriteData_16Bit(Data);

}

void lv_Gui_DrawPoint(u16 x,u16 y,u16 *Data)
{
    Lcd_SetRegion(x,y,x+1,y+1);
    Lv_LCD_WriteData_16Bit(Data);

}
void LV_LCD_Fill(u16 sx,u16 sy,u16 ex,u16 ey,u16 *color){

    u16 i,j;
        u16 width=ex-sx+1;      //得到填充的宽度
        u16 height=ey-sy+1;     //高度
        Lcd_SetRegion(sx,sy,ex-1,ey-1);//设置显示窗口
        for(i=0;i<height-1;i++)
        {
            for(j=0;j<width-1;j++){
                LCD_WriteData_16Bit(color[i * (width) + j]);   //写入数据
                //LCD_WriteData_16Bit(*color);   //写入数据
                //color+=1;

            }
        }

        Lcd_SetRegion(0,0,127,127);//恢复窗口设置为全屏
}

/*****************************************
 函数功能：读TFT某一点的颜色
 出口参数：color  点颜色值
******************************************/
unsigned int Lcd_ReadPoint(u16 x,u16 y)
{
  unsigned int Data;
  Lcd_SetXY(x,y);

  //Lcd_ReadData();//丢掉无用字节
  //Data=Lcd_ReadData();
  Lcd_WriteData(Data);
  return Data;
}
/*************************************************
函数名：Lcd_Clear
功能：全屏清屏函数
入口参数：填充颜色COLOR
返回值：无
*************************************************/
void Lcd_Clear(u16 Color)
{
   unsigned int i,m;
   Lcd_SetRegion(0,0,127,127);
   Lcd_WriteIndex(0x2C);
   for(i=0;i<128;i++)
    for(m=0;m<128;m++)
    {
        LCD_WriteData_16Bit(Color);
    }
}
#endif /* LIBRARIES_N32_DRIVERS_DRV_LCD_C_ */

