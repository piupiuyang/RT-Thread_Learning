/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-08-04     piupiuY       the first version
 */
#include <rtthread.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include <board.h>
#define LED_PIN_NUM GET_PIN(B, 0) /* PA8 LED PIN�ű�ţ��鿴�����ļ�drv_gpio.cȷ�� */
#define PWM_DEV_LCD "tim3pwm3" /* PWM�豸���� */
#define PWM_DEV_LCD_CHANNEL 3 /* PWMͨ�� */
struct rt_device_pwm *pwm_LCD;      /* PWM�豸��� */

int adjust_ligth_init(){

    rt_uint32_t period = 5000;
    //rt_pin_mode(LED_PIN_NUM, PIN_MODE_OUTPUT);
    rt_pin_write(LED_PIN_NUM, PIN_HIGH);
    pwm_LCD  = (struct rt_device_pwm *)rt_device_find(PWM_DEV_LCD);
    if(pwm_LCD == RT_NULL ){
               rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM_DEV_LCD);
               return RT_ERROR;
        }
    rt_pwm_set(pwm_LCD, PWM_DEV_LCD_CHANNEL, period, 1000);
    rt_pwm_enable(pwm_LCD, PWM_DEV_LCD_CHANNEL);
    return 0;
}
extern int adjust_ligth(rt_uint32_t pulse){

    rt_pwm_set(pwm_LCD, PWM_DEV_LCD_CHANNEL, 5000, pulse);
    rt_pwm_enable(pwm_LCD, PWM_DEV_LCD_CHANNEL);
    return 0;
}
INIT_DEVICE_EXPORT(adjust_ligth_init);
