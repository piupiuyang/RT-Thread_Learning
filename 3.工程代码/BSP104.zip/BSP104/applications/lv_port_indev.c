/**
 * @file lv_port_indev_templ.c
 *
 */

/*Copy this file as "lv_port_indev.c" and set this value to "1" to enable content*/
#if 1

/*********************
 *      INCLUDES
 *********************/
#include "lv_port_indev.h"
#include "lvgl.h"
#include <agile_button.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <rtdbg.h>

/*********************
 *      DEFINES
 *********************/
#define Button1_PIN 4
#define Button2_PIN 5
#define Button3_PIN 6
static agile_btn_t *btn1 = RT_NULL;
static agile_btn_t *btn2 = RT_NULL;
static agile_btn_t *btn3 = RT_NULL;
uint32_t key1_state = 0;
uint32_t key2_state = 0;
uint32_t key3_state = 0;
/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
/*
static void touchpad_init(void);
static void touchpad_read(lv_indev_drv_t * indev_drv, lv_indev_data_t * data);
static bool touchpad_is_pressed(void);
static void touchpad_get_xy(lv_coord_t * x, lv_coord_t * y);

static void mouse_init(void);
static void mouse_read(lv_indev_drv_t * indev_drv, lv_indev_data_t * data);
static bool mouse_is_pressed(void);
static void mouse_get_xy(lv_coord_t * x, lv_coord_t * y);

static void encoder_init(void);
static void encoder_read(lv_indev_drv_t * indev_drv, lv_indev_data_t * data);
static void encoder_handler(void);

void button_init(void);
static void button_read(lv_indev_drv_t * indev_drv, lv_indev_data_t * data);
static int8_t button_get_pressed_id(void);
static bool button_is_pressed(uint8_t id);
*/
static void keypad_init(void);
static void keypad_read(lv_indev_drv_t * indev_drv, lv_indev_data_t * data);
static uint32_t keypad_get_key(void);
void button_init(void);

/**********************
 *  STATIC VARIABLES
 **********************/
//lv_indev_t * indev_touchpad;
//lv_indev_t * indev_mouse;
lv_indev_t * indev_keypad;
//lv_indev_t * indev_encoder;
//lv_indev_t * indev_button;

//static int32_t encoder_diff;
//static lv_indev_state_t encoder_state;

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

void lv_port_indev_init(void)
{
    /**
     * Here you will find example implementation of input devices supported by LittelvGL:
     *  - Touchpad
     *  - Mouse (with cursor support)
     *  - Keypad (supports GUI usage only with key)
     *  - Encoder (supports GUI usage only with: left, right, push)
     *  - Button (external buttons to press points on the screen)
     *
     *  The `..._read()` function are only examples.
     *  You should shape them according to your hardware
     */

    static lv_indev_drv_t indev_drv;


    /*------------------
     * Keypad
     * -----------------*/

    /*Initialize your keypad or keyboard if you have*/
    button_init();
    //keypad_init();

    /*Register a keypad input device*/
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_KEYPAD;
    indev_drv.read_cb = keypad_read;
    indev_keypad = lv_indev_drv_register(&indev_drv);

}

/**********************
 *   STATIC FUNCTIONS
 **********************/
/*------------------
 * Button
 * -----------------*/
static void btn_click_event_cb(agile_btn_t *btn)
{
    switch(btn->pin){
    case 4:key1_state = 1;break;
    case 5:key2_state = 1;break;
    case 6:key3_state = 1;break;
    }
    rt_kprintf("lv[button click event] pin:%d   repeat:%d, hold_time:%d\r\n", btn->pin, btn->repeat_cnt, btn->hold_time);
}

static void btn_hold_event_cb(agile_btn_t *btn)
{
    switch(btn->pin){
    case 4:key1_state = 2;break;
    case 5:key2_state = 2;break;
    case 6:key3_state = 2;break;
    }
    rt_kprintf("lv[button hold event] pin:%d   hold_time:%d\r\n", btn->pin, btn->hold_time);
}



/*Will be called by the library to read the button*/
/*------------------
 * Keypad
 * -----------------*/

/*Initialize your keypad*/

void button_init(void)
{
       btn1 = agile_btn_create(Button1_PIN, 0, PIN_MODE_INPUT_PULLUP);
       btn2 = agile_btn_create(Button2_PIN, 0, PIN_MODE_INPUT_PULLUP);
       btn3 = agile_btn_create(Button3_PIN, 0, PIN_MODE_INPUT_PULLUP);//PIN_MODE_INPUT_PULLDOWN

       agile_btn_set_event_cb(btn1, BTN_CLICK_EVENT, btn_click_event_cb);
       agile_btn_set_event_cb(btn1, BTN_HOLD_EVENT, btn_hold_event_cb);
       agile_btn_set_event_cb(btn2, BTN_CLICK_EVENT, btn_click_event_cb);
       agile_btn_set_event_cb(btn2, BTN_HOLD_EVENT, btn_hold_event_cb);
       agile_btn_set_event_cb(btn3, BTN_CLICK_EVENT, btn_click_event_cb);
       agile_btn_set_event_cb(btn3, BTN_HOLD_EVENT, btn_hold_event_cb);
       agile_btn_start(btn1);
       agile_btn_start(btn2);
       agile_btn_start(btn3);
    /*Your code comes here*/
}

/*Will be called by the library to read the mouse*/
static void keypad_read(lv_indev_drv_t * indev_drv, lv_indev_data_t * data)
{
    static uint32_t last_key = 0;

    /*Get the current x and y coordinates*/
    //mouse_get_xy(&data->point.x, &data->point.y);

    /*Get whether the a key is pressed and save the pressed key*/
    uint32_t act_key = keypad_get_key();
    if(act_key != 0) {
        data->state = LV_INDEV_STATE_PR;

        /*Translate the keys to LVGL control characters according to your key definitions*/
        switch(act_key) {
            case 1:
                act_key = LV_KEY_NEXT;
                break;
            case 2:
                act_key = LV_KEY_PREV;
                break;
            case 3:
                act_key = LV_KEY_LEFT;
                break;
            case 4:
                act_key = LV_KEY_RIGHT;
                break;
            case 5:
                act_key = LV_KEY_ENTER;
                break;
        }

        last_key = act_key;
    }
    else {
        data->state = LV_INDEV_STATE_REL;
    }

    data->key = last_key;
}

/*Get the currently being pressed key.  0 if no key is pressed*/
static uint32_t keypad_get_key(void)
{
    /*Your code comes here*/
   if(key1_state == 1){
       key1_state = 0;
       return 5;
   }
   if(key2_state == 1){
       key2_state = 0;
       return 1;
   }
   if(key2_state == 2){
       key2_state = 0;
       return 3;
   }
   if(key3_state == 1){
       key3_state = 0;
       return 2;
   }
   if(key3_state == 2){
       key3_state = 0;
       return 4;
   }
    return 0;
}

#else /*Enable this file at the top*/

/*This dummy typedef exists purely to silence -Wpedantic.*/
typedef int keep_pedantic_happy;
#endif
