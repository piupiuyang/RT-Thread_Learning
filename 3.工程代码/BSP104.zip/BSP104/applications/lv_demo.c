/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-07-28     piupiuY       the first version
 */
//���ƽ�ȥ�����������Լ�д�Ļ������Ҳ�������ģ�壬��Щ�ط�Ҫע��
#include <rtthread.h>
#include <lvgl.h>
#include <lv_port_indev.h>

#define DBG_TAG    "LVGL.demo"
#define DBG_LVL    DBG_INFO
#include <rtdbg.h>
#include "Lcd_Driver.h"

#ifndef LV_THREAD_STACK_SIZE
#define LV_THREAD_STACK_SIZE 8192
#endif

#ifndef LV_THREAD_PRIO
#define LV_THREAD_PRIO (RT_THREAD_PRIORITY_MAX*2/3)
#endif





/**
 * Create a slider and write its value on a label.
 */


static void lvgl_thread(void *parameter)
{
    //lv_example_flex_1();

    while(1)
    {
        lv_task_handler();  //����Ҫ��  LVGL�������

        rt_thread_mdelay(10);
    }
}

static int lvgl_demo_init(void)
{

       //MX_GPIO_Init();
       //MX_FSMC_Init();
       Lcd_Init();         //LCD��ʼ��
       //rt_pin_write(LCD_LED_PIN, PIN_HIGH);
       //button_init();      //��������ʼ��

       lv_init();         //LVGL ��ʼ��


    rt_thread_t tid;
    tid = rt_thread_create("LV_demo", lvgl_thread, RT_NULL, LV_THREAD_STACK_SIZE, LV_THREAD_PRIO, 0);
    if(tid == RT_NULL)
    {
        LOG_E("Fail to create 'LVGL' thread");
    }
    rt_thread_startup(tid);

    return 0;
}


//INIT_APP_EXPORT(lvgl_demo_init);

