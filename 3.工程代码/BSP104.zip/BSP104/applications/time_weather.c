/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-08-02     piupiuY       the first version
 */
#include <rtthread.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include <rtthread.h>
#include <webclient.h>
#include "cJSON_util.h"

#define THREAD_PRIORITY         25
#define THREAD_STACK_SIZE       2048
#define THREAD_TIMESLICE        5
static rt_thread_t get_weather_tid = RT_NULL; //������ȡ���߳̾��
struct rt_mailbox weather_mb;//��������
static char mb_pool[16];

#define GET_LOCAL_WEATHER_URI "http://api.seniverse.com/v3/weather/now.json?key=Sb1RX4Y3u5dyrpJk4&location=chengdu&language=en"
#define GET_LOCAL_TIME_URI    "http://api.k780.com:88/?app=life.time&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=json"
typedef struct http_weather_time_info_s {
    char weather[8];
    char temperature[2];
}http_weather_info_t;
http_weather_info_t* weather_time_info = RT_NULL;//��Ż�ȡ������������


static void weather_data_parse(char* data, unsigned char debug)
{
    cJSON *root = RT_NULL, *arrayItem = RT_NULL,*object = RT_NULL;
    cJSON *daily = RT_NULL, *list = RT_NULL, *item = RT_NULL;

    //weather_info = (http_weather_info_t*)rt_malloc(sizeof(http_weather_info_t));
    root = cJSON_Parse((const char *)data);
    if (!root)
    {
        LOG_E("No memory for cJSON root!\n");
        return;
    }

    arrayItem = cJSON_GetObjectItem(root, "results");
    if (arrayItem == RT_NULL)
    {
        LOG_E("cJSON get results failed.");
        goto __EXIT;
    }

    object = cJSON_GetArrayItem(arrayItem, 0);
    if (object == RT_NULL)
    {
        LOG_E("cJSON get object failed.");
        goto __EXIT;
    }

    item = cJSON_GetObjectItem(object, "location");
    if (item == RT_NULL)
    {
        LOG_E("cJSON get location failed.");
        goto __EXIT;
    }

    if ((list = cJSON_GetObjectItem(item, "name")) != NULL)
    {
         rt_kprintf("city: %s\r\n",list->valuestring);
    }

    daily = cJSON_GetObjectItem(object, "now");
    if (daily == RT_NULL)
    {
        LOG_E("cJSON get dayItem failed.");
        goto __EXIT;
    }

    if ((list = cJSON_GetObjectItem(daily, "text")) != NULL)
    {

          rt_strncpy(weather_time_info->weather, list->valuestring,rt_strlen(list->valuestring));
          rt_kprintf("weather: %s\r\n",weather_time_info->weather);

     }

    if ((list = cJSON_GetObjectItem(daily, "temperature")) != NULL)
    {

       rt_strncpy(weather_time_info->temperature, list->valuestring,rt_strlen(list->valuestring));
       rt_kprintf("temperature: %s\r\n",weather_time_info->temperature);

    }
__EXIT:
   if (root != RT_NULL)
       cJSON_Delete(root);
}

void time_set(char* now_date){

    char year[4];
    char month[2];
    char date[2];
    char hour[2];
    char min[2];
    char sec[2];

    int j = 0;
    for(int i  = 0 ; i < rt_strlen(now_date) ; i++){
                 if(i<=3){
                             year[j] = now_date[i];
                             //rt_kprintf("%c\n",year[j]);
                             j++;
                             continue;
                         }else if(i>=5&&i<=6){
                             month[j] =  now_date[i];
                             //rt_kprintf("%c\n",month[j]);
                             j++;
                             continue;
                         }else if(i>=8&&i<=9){
                             date[j] =  now_date[i];
                             //rt_kprintf("%c\n",date[j]);
                             j++;
                             continue;
                         }else if(i>=11&&i<=12){
                             hour[j] =  now_date[i];
                             //rt_kprintf("%c\n",hour[j]);
                             j++;
                             continue;
                         }else if(i>=14&&i<=15){
                             min[j] =  now_date[i];
                             //rt_kprintf("%c\n",min[j]);
                             j++;
                             continue;
                         }else if(i>=17&&i<=18){
                             sec[j] =  now_date[i];
                             //rt_kprintf("%c\n",sec[j]);
                             j++;
                             continue;
                 }
         j = 0;
      }
    time_t now;
    now = time(RT_NULL);
    rt_kprintf("%s\n", ctime(&now));
    set_time(atoi(hour), atoi(min), atoi(sec));

    set_date(atoi(year), atoi(month), atoi(date));

}
static void time_data_parse(char* data, unsigned char debug)
{
    cJSON *root = RT_NULL, *arrayItem = RT_NULL,*object = RT_NULL;
    //cJSON *daily = RT_NULL, *list = RT_NULL, *item = RT_NULL;

    //weather_info = (http_weather_info_t*)rt_malloc(sizeof(http_weather_info_t));

    root = cJSON_Parse((const char *)data);
    if (!root)
    {
        LOG_E("No memory for cJSON root!\n");
        return;
    }

    arrayItem = cJSON_GetObjectItem(root, "result");
    if (arrayItem == RT_NULL)
    {
        LOG_E("cJSON get results failed.");
        goto __EXIT;
    }
    if ((object = cJSON_GetObjectItem(arrayItem, "datetime_1")) != NULL){
        time_set(object->valuestring);
        rt_kprintf("%s\n",object->valuestring);
    }

__EXIT:
   if (root != RT_NULL)
       cJSON_Delete(root);
}


static int Get_Now_Weather_Time()
{
    char *Weather_response = RT_NULL;
    char *Time_response = RT_NULL;
    size_t resp_len = 0;
    int index;
    weather_time_info = (http_weather_info_t*)rt_malloc_align(sizeof(http_weather_info_t), 4);

    //���� get ����
    if (webclient_request(GET_LOCAL_WEATHER_URI, RT_NULL, RT_NULL, 0, (void **)&Weather_response, &resp_len) < 0)
    {
        rt_kprintf("webclient send get request failed.");
        return -RT_ERROR;
    }
    //ʱ�� get ����
    if (webclient_request(GET_LOCAL_TIME_URI, RT_NULL, RT_NULL, 0, (void **)&Time_response, &resp_len) < 0)
    {
        rt_kprintf("webclient send get request failed.");
        return -RT_ERROR;
    }
    rt_kprintf("webclient send get request by simplify request interface.\n");
    rt_kprintf("webclient get response data: \n");
    for (index = 0; index < rt_strlen(Weather_response); index++)
    {
        rt_kprintf("%c", Weather_response[index]);
    }
    for (index = 0; index < rt_strlen(Time_response); index++)
    {
        rt_kprintf("%c", Time_response[index]);
    }
    rt_kprintf("\n");
    weather_data_parse(Weather_response,1);//����cjson����
    time_data_parse(Time_response,1);//����cjson����
    if (Weather_response)
    {
        web_free(Weather_response);
    }
    if (Time_response)
    {
        web_free(Time_response);
    }

    return 0;
}

static void get_weatherThread_entry(void *parameter)
{
    while(1)
    {
        Get_Now_Weather_Time();
        rt_mb_send(&weather_mb, (rt_ubase_t)weather_time_info);
        rt_thread_mdelay(100 * 1000);
    }
}

int get_weatherThread(void)
{
    rt_err_t result = RT_EOK;

    result = rt_mb_init(&weather_mb,
                        "weat_mbt",
                        &mb_pool[0],
                        sizeof(mb_pool) / 4,
                        RT_IPC_FLAG_FIFO);
    if (result != RT_EOK)
    {
        LOG_E("rt_mb_init failed.\n");
        return -1;
    }

    get_weather_tid = rt_thread_create("weather",
                            get_weatherThread_entry,
                            RT_NULL,
                            THREAD_STACK_SIZE,
                            THREAD_PRIORITY, THREAD_TIMESLICE);
    if (get_weather_tid != RT_NULL)
    {
        rt_thread_startup(get_weather_tid);
    }

    return 0;
}
INIT_APP_EXPORT(get_weatherThread);
//MSH_CMD_EXPORT(Get_Now_Weather_Time,location);
