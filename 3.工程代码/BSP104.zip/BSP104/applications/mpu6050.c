/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-07-24     piupiuY       the first version
 */
#include <rtthread.h>
#include <rtdevice.h>
#include "mpu6050.h"
#include <rtdbg.h>

/*�̺߳궨��*/
#define THREAD_PRIORITY         25
#define THREAD_STACK_SIZE       1024
#define THREAD_TIMESLICE        5
static rt_thread_t tid_mpu6050 = RT_NULL;

#define MPU6050_IC2_BUS_NAME "i2c1"
#define MPU6050_ADDR 0x68

struct mpu6xxx_device *i2c_bus_mpu6050 = RT_NULL;     /* I2C�����豸��� */
struct mpu6xxx_3axes accel,gyro; // ���ٶȣ�������
float temp;// �¶�



int mpu_accel_gyro_temp_read(){

    i2c_bus_mpu6050 = (struct mpu6xxx_device *)mpu6xxx_init(MPU6050_IC2_BUS_NAME,MPU6050_ADDR);
    while(1){

        mpu6xxx_get_accel(i2c_bus_mpu6050, &accel);
        mpu6xxx_get_gyro(i2c_bus_mpu6050, &gyro);
        mpu6xxx_get_temp(i2c_bus_mpu6050, &temp);
        rt_kprintf("accel.x = %4d, accel.y = %4d, accel.z = %4d ", accel.x, accel.y, accel.z);
        rt_kprintf("gyro.x = %4d gyro.y = %4d, gyro.z = %4d, ", gyro.x, gyro.y, gyro.z);
        rt_kprintf("temp = %d.%d\n", (int)(temp * 100) / 100, (int)(temp * 100) % 100);

    }
    return 0;

}

static void thread_mpu6050_entry(void *parameter)
{
    mpu_accel_gyro_temp_read();
}

static int thread_mpu6050(void){

    tid_mpu6050 = rt_thread_create("thread_mpu6050",
            thread_mpu6050_entry,
            RT_NULL,
            THREAD_STACK_SIZE,
            THREAD_PRIORITY,
            THREAD_TIMESLICE);
    if(tid_mpu6050 != RT_NULL)
        rt_thread_startup(tid_mpu6050);

}

