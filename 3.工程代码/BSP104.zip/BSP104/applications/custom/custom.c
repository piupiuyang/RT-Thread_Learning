// SPDX-License-Identifier: MIT
// Copyright 2020 NXP

/**
 * @file custom.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include <stdio.h>
#include "lvgl.h"
#include "custom.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/

/**
 * Create a demo application
 */
time_t now;
lv_timer_t* get_time_timer;
lv_timer_t* homepage_timer;
typedef struct http_weather_time_info_s {
    char weather[8];
    char temperature[2];
}http_weather_info_t;
extern http_weather_info_t *weather_time_info;
extern struct rt_mailbox weather_mb;
extern void read_temp_humi(float *cur_temp, float *cur_humi);
extern int adjust_ligth(rt_uint32_t pulse);
extern int light;
void custom_init(lv_ui *ui)
{
    /* Add your codes here */
}


void clock_date_task_callback(lv_timer_t *timer){
    int year;
    float humidity, temperature;
    humidity = 0.0;
    temperature = 0.0;
    lv_ui * ui = timer->user_data;

    now = time(RT_NULL);
    now_time = localtime(&now);

    switch(now_time->tm_wday){
        case 1:
            lv_label_set_text(ui->screen_label_1,"Mo");break;
        case 2:
            lv_label_set_text(ui->screen_label_1,"Tu");break;
        case 3:
            lv_label_set_text(ui->screen_label_1,"We");break;
        case 4:
            lv_label_set_text(ui->screen_label_1,"Th");break;
        case 5:
            lv_label_set_text(ui->screen_label_1,"Fr");break;
        case 6:
            lv_label_set_text(ui->screen_label_1,"Sa");break;
        case 7:
            lv_label_set_text(ui->screen_label_1,"Su");break;

    }
    year = ((now_time->tm_year + 1900)/100)*100+((now_time->tm_year + 1900)%100);



        if(rt_strcmp(weather_time_info->weather, "Sunny")==0){
            lv_img_set_src(ui->screen_img_weather,&_sun_50x50);
        }else{
            lv_img_set_src(ui->screen_img_weather,&_cloude_50x50);
        }

        rt_thread_mdelay(20);
    lv_label_set_text_fmt(ui->screen_label_time, "%02d:%02d:%02d",now_time->tm_hour,now_time->tm_min,now_time->tm_sec);
    lv_label_set_text_fmt(ui->screen_label_date,"%d,%d,%d",year,(now_time->tm_mon+1),now_time->tm_mday);

    read_temp_humi(&temperature, &humidity);
    lv_label_set_text_fmt(ui->screen_lable_temp,  ":%02d.%02d\n", (int)temperature, (int)(temperature * 10) % 10);
    lv_label_set_text_fmt(ui->screen_label_humid,  ":%02d.%02d\n", (int)humidity, (int)(humidity * 10) % 10);
}

void home_timer_init(lv_ui *ui){

    get_time_timer = lv_timer_create(clock_date_task_callback, 400, ui); // ������ʱ����200msˢ��һ��
    if (get_time_timer == NULL)
    {
        rt_kprintf("[%s:%d] lv_timer_create failed\n", __FUNCTION__, __LINE__);
    }
}

//��ҳ�ص�4���޲����ص�ʱ�ӽ���
void backHome_task_callback(lv_timer_t *timer){
    //lv_obj_t *time_lable = guider_ui.screen_label_time;
    lv_ui * ui = timer->user_data;
    if (!lv_obj_is_valid(ui->screen)){
        rt_kprintf("not screen exist\n");
        setup_scr_screen(ui);
    }else{
        rt_kprintf("screen exist\n");
    }
    lv_scr_load_anim(ui->screen, LV_SCR_LOAD_ANIM_FADE_ON, 500, 0, true);
    lv_timer_pause(homepage_timer);
    lv_timer_resume(get_time_timer);
}


void homepage_timer_init(lv_ui *ui){

    homepage_timer = lv_timer_create(backHome_task_callback, 4000, ui); // ������ʱ����4000msˢ��һ��
    if (homepage_timer == NULL)
    {
        rt_kprintf("[%s:%d] lv_timer_create failed\n", __FUNCTION__, __LINE__);
    }
}

void slider_event_cb(lv_event_t * e)
{
    lv_obj_t * slider = lv_event_get_target(e);
    adjust_ligth((int)lv_slider_get_value(slider)*500);
    light = (int)lv_slider_get_value(slider);
    //lv_snprintf(buf, sizeof(buf), "%d%%", (int)lv_slider_get_value(slider));
    //lv_label_set_text(slider_label, buf);
    //lv_obj_align_to(slider_label, slider, LV_ALIGN_OUT_BOTTOM_MID, 0, 10);
}

void events_init_adjust_light_slider(lv_ui *ui){

    lv_obj_add_event_cb(ui->adjust_light_page_slider_1, slider_event_cb, LV_EVENT_VALUE_CHANGED, NULL);

}

