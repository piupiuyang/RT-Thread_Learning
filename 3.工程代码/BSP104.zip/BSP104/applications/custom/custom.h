// SPDX-License-Identifier: MIT
// Copyright 2020 NXP

/*
 * custom.h
 *
 *  Created on: July 29, 2020
 *      Author: nxf53801
 */

#ifndef __CUSTOM_H_
#define __CUSTOM_H_

#include "gui_guider.h"
#include <rtthread.h>
#include <rtdevice.h>

extern lv_timer_t* get_time_timer  ;
extern lv_timer_t* homepage_timer  ;
void custom_init(lv_ui *ui);
void home_timer_init(lv_ui *ui);
void homepage_timer_init(lv_ui *ui);
void events_init_adjust_light_slider(lv_ui *ui);
struct tm* now_time;
#endif /* EVENT_CB_H_ */
