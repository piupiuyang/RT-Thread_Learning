# Copyright 2021 NXP
# SPDX-License-Identifier: MIT

import SDL
import utime as time
import usys as sys
import lvgl as lv
import lodepng as png
import ustruct

lv.init()
SDL.init(w=128,h=128)

# Register SDL display driver.
disp_buf1 = lv.disp_draw_buf_t()
buf1_1 = bytearray(128*10)
disp_buf1.init(buf1_1, None, len(buf1_1)//4)
disp_drv = lv.disp_drv_t()
disp_drv.init()
disp_drv.draw_buf = disp_buf1
disp_drv.flush_cb = SDL.monitor_flush
disp_drv.hor_res = 128
disp_drv.ver_res = 128
disp_drv.register()

# Regsiter SDL mouse driver
indev_drv = lv.indev_drv_t()
indev_drv.init() 
indev_drv.type = lv.INDEV_TYPE.POINTER
indev_drv.read_cb = SDL.mouse_read
indev_drv.register()

# Below: Taken from https://github.com/lvgl/lv_binding_micropython/blob/master/driver/js/imagetools.py#L22-L94

COLOR_SIZE = lv.color_t.__SIZE__
COLOR_IS_SWAPPED = hasattr(lv.color_t().ch,'green_h')

class lodepng_error(RuntimeError):
    def __init__(self, err):
        if type(err) is int:
            super().__init__(png.error_text(err))
        else:
            super().__init__(err)

# Parse PNG file header
# Taken from https://github.com/shibukawa/imagesize_py/blob/ffef30c1a4715c5acf90e8945ceb77f4a2ed2d45/imagesize.py#L63-L85

def get_png_info(decoder, src, header):
    # Only handle variable image types

    if lv.img.src_get_type(src) != lv.img.SRC.VARIABLE:
        return lv.RES.INV

    data = lv.img_dsc_t.__cast__(src).data
    if data == None:
        return lv.RES.INV

    png_header = bytes(data.__dereference__(24))

    if png_header.startswith(b'\211PNG\r\n\032\n'):
        if png_header[12:16] == b'IHDR':
            start = 16
        # Maybe this is for an older PNG version.
        else:
            start = 8
        try:
            width, height = ustruct.unpack(">LL", png_header[start:start+8])
        except ustruct.error:
            return lv.RES.INV
    else:
        return lv.RES.INV

    header.always_zero = 0
    header.w = width
    header.h = height
    header.cf = lv.img.CF.TRUE_COLOR_ALPHA

    return lv.RES.OK

def convert_rgba8888_to_bgra8888(img_view):
    for i in range(0, len(img_view), lv.color_t.__SIZE__):
        ch = lv.color_t.__cast__(img_view[i:i]).ch
        ch.red, ch.blue = ch.blue, ch.red

# Read and parse PNG file

def open_png(decoder, dsc):
    img_dsc = lv.img_dsc_t.__cast__(dsc.src)
    png_data = img_dsc.data
    png_size = img_dsc.data_size
    png_decoded = png.C_Pointer()
    png_width = png.C_Pointer()
    png_height = png.C_Pointer()
    error = png.decode32(png_decoded, png_width, png_height, png_data, png_size)
    if error:
        raise lodepng_error(error)
    img_size = png_width.int_val * png_height.int_val * 4
    img_data = png_decoded.ptr_val
    img_view = img_data.__dereference__(img_size)

    if COLOR_SIZE == 4:
        convert_rgba8888_to_bgra8888(img_view)
    else:
        raise lodepng_error("Error: Color mode not supported yet!")

    dsc.img_data = img_data
    return lv.RES.OK

# Above: Taken from https://github.com/lvgl/lv_binding_micropython/blob/master/driver/js/imagetools.py#L22-L94

decoder = lv.img.decoder_create()
decoder.info_cb = get_png_info
decoder.open_cb = open_png

def anim_x_cb(obj, v):
    obj.set_x(v)

def anim_y_cb(obj, v):
    obj.set_y(v)

def ta_event_cb(e,kb):
    code = e.get_code()
    ta = e.get_target()
    if code == lv.EVENT.FOCUSED:
        kb.set_textarea(ta)
        kb.clear_flag(lv.obj.FLAG.HIDDEN)

    if code == lv.EVENT.DEFOCUSED:
        kb.set_textarea(None)
        kb.add_flag(lv.obj.FLAG.HIDDEN)


screen = lv.obj()
# create style style_screen_main_main_default
style_screen_main_main_default = lv.style_t()
style_screen_main_main_default.init()
style_screen_main_main_default.set_bg_color(lv.color_make(0x00,0x00,0x00))
style_screen_main_main_default.set_bg_opa(255)

# add style for screen
screen.add_style(style_screen_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_btn_home = lv.btn(screen)
screen_btn_home.set_pos(0,0)
screen_btn_home.set_size(128,128)
screen_btn_home.update_layout()
screen_btn_home_anim_move_x = lv.anim_t()
screen_btn_home_anim_move_x.init()
screen_btn_home_anim_move_x.set_var(screen_btn_home)
screen_btn_home_anim_move_x.set_values(screen_btn_home.get_x(), 0)
screen_btn_home_anim_move_x.set_time(100)
screen_btn_home_anim_move_x.set_path_cb(lv.anim_t.path_linear)
screen_btn_home_anim_move_x.set_custom_exec_cb(lambda a,val: anim_x_cb(screen_btn_home,val))
lv.anim_t.start(screen_btn_home_anim_move_x)

screen_btn_home_anim_move_y = lv.anim_t()
screen_btn_home_anim_move_y.init()
screen_btn_home_anim_move_y.set_var(screen_btn_home)
screen_btn_home_anim_move_y.set_values(screen_btn_home.get_x(), 0)
screen_btn_home_anim_move_y.set_time(100)
screen_btn_home_anim_move_y.set_path_cb(lv.anim_t.path_linear)
screen_btn_home_anim_move_y.set_custom_exec_cb(lambda a,val: anim_y_cb(screen_btn_home,val))
lv.anim_t.start(screen_btn_home_anim_move_y)

# create style style_screen_btn_home_main_main_default
style_screen_btn_home_main_main_default = lv.style_t()
style_screen_btn_home_main_main_default.init()
style_screen_btn_home_main_main_default.set_radius(10)
style_screen_btn_home_main_main_default.set_bg_color(lv.color_make(0x23,0x9a,0xf6))
style_screen_btn_home_main_main_default.set_bg_grad_color(lv.color_make(0xf6,0xda,0x23))
style_screen_btn_home_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_screen_btn_home_main_main_default.set_bg_opa(149)
style_screen_btn_home_main_main_default.set_shadow_color(lv.color_make(0x21,0x95,0xf6))
style_screen_btn_home_main_main_default.set_shadow_opa(0)
style_screen_btn_home_main_main_default.set_border_color(lv.color_make(0x23,0xaf,0xf6))
style_screen_btn_home_main_main_default.set_border_width(2)
style_screen_btn_home_main_main_default.set_border_opa(255)

# add style for screen_btn_home
screen_btn_home.add_style(style_screen_btn_home_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_label_time = lv.label(screen)
screen_label_time.set_pos(16,10)
screen_label_time.set_size(95,23)
screen_label_time.set_text("23:07:33")
screen_label_time.set_long_mode(lv.label.LONG.WRAP)
screen_label_time.set_style_text_align(lv.TEXT_ALIGN.CENTER, 0)
# create style style_screen_label_time_main_main_default
style_screen_label_time_main_main_default = lv.style_t()
style_screen_label_time_main_main_default.init()
style_screen_label_time_main_main_default.set_radius(4)
style_screen_label_time_main_main_default.set_bg_color(lv.color_make(0xf6,0xee,0x09))
style_screen_label_time_main_main_default.set_bg_grad_color(lv.color_make(0x23,0xf6,0xc1))
style_screen_label_time_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_screen_label_time_main_main_default.set_bg_opa(82)
style_screen_label_time_main_main_default.set_text_color(lv.color_make(0xbf,0xba,0x31))
try:
    style_screen_label_time_main_main_default.set_text_font(lv.font_montserratMedium_22)
except AttributeError:
    try:
        style_screen_label_time_main_main_default.set_text_font(lv.font_montserrat_22)
    except AttributeError:
        style_screen_label_time_main_main_default.set_text_font(lv.font_montserrat_16)
style_screen_label_time_main_main_default.set_text_letter_space(0)
style_screen_label_time_main_main_default.set_pad_left(0)
style_screen_label_time_main_main_default.set_pad_right(0)
style_screen_label_time_main_main_default.set_pad_top(0)
style_screen_label_time_main_main_default.set_pad_bottom(0)

# add style for screen_label_time
screen_label_time.add_style(style_screen_label_time_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_img_weather = lv.img(screen)
screen_img_weather.set_pos(5,54)
screen_img_weather.set_size(50,50)
screen_img_weather.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-1277548269.png','rb') as f:
        screen_img_weather_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-1277548269.png')
    sys.exit()

screen_img_weather_img = lv.img_dsc_t({
  'data_size': len(screen_img_weather_img_data),
  'header': {'always_zero': 0, 'w': 50, 'h': 50, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': screen_img_weather_img_data
})

screen_img_weather.set_src(screen_img_weather_img)
screen_img_weather.set_pivot(0,0)
screen_img_weather.set_angle(0)
# create style style_screen_img_weather_main_main_default
style_screen_img_weather_main_main_default = lv.style_t()
style_screen_img_weather_main_main_default.init()
style_screen_img_weather_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_screen_img_weather_main_main_default.set_img_recolor_opa(0)
style_screen_img_weather_main_main_default.set_img_opa(255)

# add style for screen_img_weather
screen_img_weather.add_style(style_screen_img_weather_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_lable_temp = lv.label(screen)
screen_lable_temp.set_pos(71,56)
screen_lable_temp.set_size(43,12)
screen_lable_temp.set_text(":27.2")
screen_lable_temp.set_long_mode(lv.label.LONG.WRAP)
screen_lable_temp.set_style_text_align(lv.TEXT_ALIGN.CENTER, 0)
# create style style_screen_lable_temp_main_main_default
style_screen_lable_temp_main_main_default = lv.style_t()
style_screen_lable_temp_main_main_default.init()
style_screen_lable_temp_main_main_default.set_radius(0)
style_screen_lable_temp_main_main_default.set_bg_color(lv.color_make(0x21,0x95,0xf6))
style_screen_lable_temp_main_main_default.set_bg_grad_color(lv.color_make(0x21,0x95,0xf6))
style_screen_lable_temp_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_screen_lable_temp_main_main_default.set_bg_opa(0)
style_screen_lable_temp_main_main_default.set_text_color(lv.color_make(0xd7,0xc0,0x28))
try:
    style_screen_lable_temp_main_main_default.set_text_font(lv.font_montserratMedium_11)
except AttributeError:
    try:
        style_screen_lable_temp_main_main_default.set_text_font(lv.font_montserrat_11)
    except AttributeError:
        style_screen_lable_temp_main_main_default.set_text_font(lv.font_montserrat_16)
style_screen_lable_temp_main_main_default.set_text_letter_space(2)
style_screen_lable_temp_main_main_default.set_pad_left(0)
style_screen_lable_temp_main_main_default.set_pad_right(0)
style_screen_lable_temp_main_main_default.set_pad_top(0)
style_screen_lable_temp_main_main_default.set_pad_bottom(0)

# add style for screen_lable_temp
screen_lable_temp.add_style(style_screen_lable_temp_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_label_humid = lv.label(screen)
screen_label_humid.set_pos(71,76)
screen_label_humid.set_size(43,12)
screen_label_humid.set_text(":33%")
screen_label_humid.set_long_mode(lv.label.LONG.WRAP)
screen_label_humid.set_style_text_align(lv.TEXT_ALIGN.CENTER, 0)
# create style style_screen_label_humid_main_main_default
style_screen_label_humid_main_main_default = lv.style_t()
style_screen_label_humid_main_main_default.init()
style_screen_label_humid_main_main_default.set_radius(0)
style_screen_label_humid_main_main_default.set_bg_color(lv.color_make(0x21,0x95,0xf6))
style_screen_label_humid_main_main_default.set_bg_grad_color(lv.color_make(0x21,0x95,0xf6))
style_screen_label_humid_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_screen_label_humid_main_main_default.set_bg_opa(0)
style_screen_label_humid_main_main_default.set_text_color(lv.color_make(0xcc,0xd8,0x22))
try:
    style_screen_label_humid_main_main_default.set_text_font(lv.font_montserratMedium_11)
except AttributeError:
    try:
        style_screen_label_humid_main_main_default.set_text_font(lv.font_montserrat_11)
    except AttributeError:
        style_screen_label_humid_main_main_default.set_text_font(lv.font_montserrat_16)
style_screen_label_humid_main_main_default.set_text_letter_space(2)
style_screen_label_humid_main_main_default.set_pad_left(0)
style_screen_label_humid_main_main_default.set_pad_right(0)
style_screen_label_humid_main_main_default.set_pad_top(0)
style_screen_label_humid_main_main_default.set_pad_bottom(0)

# add style for screen_label_humid
screen_label_humid.add_style(style_screen_label_humid_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_label_pace = lv.label(screen)
screen_label_pace.set_pos(71,96)
screen_label_pace.set_size(43,12)
screen_label_pace.set_text(":3421")
screen_label_pace.set_long_mode(lv.label.LONG.WRAP)
screen_label_pace.set_style_text_align(lv.TEXT_ALIGN.CENTER, 0)
# create style style_screen_label_pace_main_main_default
style_screen_label_pace_main_main_default = lv.style_t()
style_screen_label_pace_main_main_default.init()
style_screen_label_pace_main_main_default.set_radius(0)
style_screen_label_pace_main_main_default.set_bg_color(lv.color_make(0x21,0x95,0xf6))
style_screen_label_pace_main_main_default.set_bg_grad_color(lv.color_make(0x21,0x95,0xf6))
style_screen_label_pace_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_screen_label_pace_main_main_default.set_bg_opa(0)
style_screen_label_pace_main_main_default.set_text_color(lv.color_make(0xd9,0xe7,0x23))
try:
    style_screen_label_pace_main_main_default.set_text_font(lv.font_montserratMedium_11)
except AttributeError:
    try:
        style_screen_label_pace_main_main_default.set_text_font(lv.font_montserrat_11)
    except AttributeError:
        style_screen_label_pace_main_main_default.set_text_font(lv.font_montserrat_16)
style_screen_label_pace_main_main_default.set_text_letter_space(2)
style_screen_label_pace_main_main_default.set_pad_left(0)
style_screen_label_pace_main_main_default.set_pad_right(0)
style_screen_label_pace_main_main_default.set_pad_top(0)
style_screen_label_pace_main_main_default.set_pad_bottom(0)

# add style for screen_label_pace
screen_label_pace.add_style(style_screen_label_pace_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_label_date = lv.label(screen)
screen_label_date.set_pos(16,38)
screen_label_date.set_size(74,12)
screen_label_date.set_text("2022.7.31")
screen_label_date.set_long_mode(lv.label.LONG.WRAP)
screen_label_date.set_style_text_align(lv.TEXT_ALIGN.CENTER, 0)
# create style style_screen_label_date_main_main_default
style_screen_label_date_main_main_default = lv.style_t()
style_screen_label_date_main_main_default.init()
style_screen_label_date_main_main_default.set_radius(4)
style_screen_label_date_main_main_default.set_bg_color(lv.color_make(0x3b,0xd3,0x1d))
style_screen_label_date_main_main_default.set_bg_grad_color(lv.color_make(0xa0,0xb1,0x25))
style_screen_label_date_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_screen_label_date_main_main_default.set_bg_opa(117)
style_screen_label_date_main_main_default.set_text_color(lv.color_make(0x56,0xe6,0xc2))
try:
    style_screen_label_date_main_main_default.set_text_font(lv.font_montserratMedium_11)
except AttributeError:
    try:
        style_screen_label_date_main_main_default.set_text_font(lv.font_montserrat_11)
    except AttributeError:
        style_screen_label_date_main_main_default.set_text_font(lv.font_montserrat_16)
style_screen_label_date_main_main_default.set_text_letter_space(0)
style_screen_label_date_main_main_default.set_pad_left(0)
style_screen_label_date_main_main_default.set_pad_right(0)
style_screen_label_date_main_main_default.set_pad_top(0)
style_screen_label_date_main_main_default.set_pad_bottom(0)

# add style for screen_label_date
screen_label_date.add_style(style_screen_label_date_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_img_thermometer = lv.img(screen)
screen_img_thermometer.set_pos(61,54)
screen_img_thermometer.set_size(16,16)
screen_img_thermometer.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-581403103.png','rb') as f:
        screen_img_thermometer_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-581403103.png')
    sys.exit()

screen_img_thermometer_img = lv.img_dsc_t({
  'data_size': len(screen_img_thermometer_img_data),
  'header': {'always_zero': 0, 'w': 16, 'h': 16, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': screen_img_thermometer_img_data
})

screen_img_thermometer.set_src(screen_img_thermometer_img)
screen_img_thermometer.set_pivot(0,0)
screen_img_thermometer.set_angle(0)
# create style style_screen_img_thermometer_main_main_default
style_screen_img_thermometer_main_main_default = lv.style_t()
style_screen_img_thermometer_main_main_default.init()
style_screen_img_thermometer_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_screen_img_thermometer_main_main_default.set_img_recolor_opa(0)
style_screen_img_thermometer_main_main_default.set_img_opa(255)

# add style for screen_img_thermometer
screen_img_thermometer.add_style(style_screen_img_thermometer_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_img_humid = lv.img(screen)
screen_img_humid.set_pos(64,76)
screen_img_humid.set_size(12,13)
screen_img_humid.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-1788668113.png','rb') as f:
        screen_img_humid_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-1788668113.png')
    sys.exit()

screen_img_humid_img = lv.img_dsc_t({
  'data_size': len(screen_img_humid_img_data),
  'header': {'always_zero': 0, 'w': 12, 'h': 13, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': screen_img_humid_img_data
})

screen_img_humid.set_src(screen_img_humid_img)
screen_img_humid.set_pivot(0,0)
screen_img_humid.set_angle(0)
# create style style_screen_img_humid_main_main_default
style_screen_img_humid_main_main_default = lv.style_t()
style_screen_img_humid_main_main_default.init()
style_screen_img_humid_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_screen_img_humid_main_main_default.set_img_recolor_opa(0)
style_screen_img_humid_main_main_default.set_img_opa(255)

# add style for screen_img_humid
screen_img_humid.add_style(style_screen_img_humid_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_img_pace = lv.img(screen)
screen_img_pace.set_pos(62,95)
screen_img_pace.set_size(11,14)
screen_img_pace.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-251191864.png','rb') as f:
        screen_img_pace_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-251191864.png')
    sys.exit()

screen_img_pace_img = lv.img_dsc_t({
  'data_size': len(screen_img_pace_img_data),
  'header': {'always_zero': 0, 'w': 11, 'h': 14, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': screen_img_pace_img_data
})

screen_img_pace.set_src(screen_img_pace_img)
screen_img_pace.set_pivot(0,0)
screen_img_pace.set_angle(0)
# create style style_screen_img_pace_main_main_default
style_screen_img_pace_main_main_default = lv.style_t()
style_screen_img_pace_main_main_default.init()
style_screen_img_pace_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_screen_img_pace_main_main_default.set_img_recolor_opa(0)
style_screen_img_pace_main_main_default.set_img_opa(255)

# add style for screen_img_pace
screen_img_pace.add_style(style_screen_img_pace_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_label_1 = lv.label(screen)
screen_label_1.set_pos(94,38)
screen_label_1.set_size(24,12)
screen_label_1.set_text("Th")
screen_label_1.set_long_mode(lv.label.LONG.WRAP)
screen_label_1.set_style_text_align(lv.TEXT_ALIGN.CENTER, 0)
# create style style_screen_label_1_main_main_default
style_screen_label_1_main_main_default = lv.style_t()
style_screen_label_1_main_main_default.init()
style_screen_label_1_main_main_default.set_radius(4)
style_screen_label_1_main_main_default.set_bg_color(lv.color_make(0x3b,0xd3,0x1d))
style_screen_label_1_main_main_default.set_bg_grad_color(lv.color_make(0xa0,0xb1,0x25))
style_screen_label_1_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_screen_label_1_main_main_default.set_bg_opa(117)
style_screen_label_1_main_main_default.set_text_color(lv.color_make(0x56,0xe6,0xc2))
try:
    style_screen_label_1_main_main_default.set_text_font(lv.font_montserratMedium_11)
except AttributeError:
    try:
        style_screen_label_1_main_main_default.set_text_font(lv.font_montserrat_11)
    except AttributeError:
        style_screen_label_1_main_main_default.set_text_font(lv.font_montserrat_16)
style_screen_label_1_main_main_default.set_text_letter_space(0)
style_screen_label_1_main_main_default.set_pad_left(0)
style_screen_label_1_main_main_default.set_pad_right(0)
style_screen_label_1_main_main_default.set_pad_top(0)
style_screen_label_1_main_main_default.set_pad_bottom(0)

# add style for screen_label_1
screen_label_1.add_style(style_screen_label_1_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_img_1 = lv.img(screen)
screen_img_1.set_pos(0,78)
screen_img_1.set_size(50,50)
screen_img_1.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-976224203.png','rb') as f:
        screen_img_1_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-976224203.png')
    sys.exit()

screen_img_1_img = lv.img_dsc_t({
  'data_size': len(screen_img_1_img_data),
  'header': {'always_zero': 0, 'w': 50, 'h': 50, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': screen_img_1_img_data
})

screen_img_1.set_src(screen_img_1_img)
screen_img_1.set_pivot(0,0)
screen_img_1.set_angle(0)
# create style style_screen_img_1_main_main_default
style_screen_img_1_main_main_default = lv.style_t()
style_screen_img_1_main_main_default.init()
style_screen_img_1_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_screen_img_1_main_main_default.set_img_recolor_opa(0)
style_screen_img_1_main_main_default.set_img_opa(255)

# add style for screen_img_1
screen_img_1.add_style(style_screen_img_1_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_img_2 = lv.img(screen)
screen_img_2.set_pos(52.631578947368425,86.31578947368422)
screen_img_2.set_size(50,50)
screen_img_2.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp1093954233.png','rb') as f:
        screen_img_2_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp1093954233.png')
    sys.exit()

screen_img_2_img = lv.img_dsc_t({
  'data_size': len(screen_img_2_img_data),
  'header': {'always_zero': 0, 'w': 50, 'h': 50, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': screen_img_2_img_data
})

screen_img_2.set_src(screen_img_2_img)
screen_img_2.set_pivot(0,0)
screen_img_2.set_angle(0)
# create style style_screen_img_2_main_main_default
style_screen_img_2_main_main_default = lv.style_t()
style_screen_img_2_main_main_default.init()
style_screen_img_2_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_screen_img_2_main_main_default.set_img_recolor_opa(0)
style_screen_img_2_main_main_default.set_img_opa(255)

# add style for screen_img_2
screen_img_2.add_style(style_screen_img_2_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

screen_img_3 = lv.img(screen)
screen_img_3.set_pos(62,47)
screen_img_3.set_size(50,50)
screen_img_3.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-213170442.png','rb') as f:
        screen_img_3_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-213170442.png')
    sys.exit()

screen_img_3_img = lv.img_dsc_t({
  'data_size': len(screen_img_3_img_data),
  'header': {'always_zero': 0, 'w': 50, 'h': 50, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': screen_img_3_img_data
})

screen_img_3.set_src(screen_img_3_img)
screen_img_3.set_pivot(0,0)
screen_img_3.set_angle(0)
# create style style_screen_img_3_main_main_default
style_screen_img_3_main_main_default = lv.style_t()
style_screen_img_3_main_main_default.init()
style_screen_img_3_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_screen_img_3_main_main_default.set_img_recolor_opa(0)
style_screen_img_3_main_main_default.set_img_opa(255)

# add style for screen_img_3
screen_img_3.add_style(style_screen_img_3_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

home_page = lv.obj()
# create style style_home_page_main_main_default
style_home_page_main_main_default = lv.style_t()
style_home_page_main_main_default.init()
style_home_page_main_main_default.set_bg_color(lv.color_make(0x29,0xae,0xdb))
style_home_page_main_main_default.set_bg_opa(255)

# add style for home_page
home_page.add_style(style_home_page_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

home_page_img_adjustlight = lv.img(home_page)
home_page_img_adjustlight.set_pos(11,11)
home_page_img_adjustlight.set_size(40,40)
home_page_img_adjustlight.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp1365521695.png','rb') as f:
        home_page_img_adjustlight_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp1365521695.png')
    sys.exit()

home_page_img_adjustlight_img = lv.img_dsc_t({
  'data_size': len(home_page_img_adjustlight_img_data),
  'header': {'always_zero': 0, 'w': 40, 'h': 40, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': home_page_img_adjustlight_img_data
})

home_page_img_adjustlight.set_src(home_page_img_adjustlight_img)
home_page_img_adjustlight.set_pivot(0,0)
home_page_img_adjustlight.set_angle(0)
# create style style_home_page_img_adjustlight_main_main_default
style_home_page_img_adjustlight_main_main_default = lv.style_t()
style_home_page_img_adjustlight_main_main_default.init()
style_home_page_img_adjustlight_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_home_page_img_adjustlight_main_main_default.set_img_recolor_opa(0)
style_home_page_img_adjustlight_main_main_default.set_img_opa(255)

# add style for home_page_img_adjustlight
home_page_img_adjustlight.add_style(style_home_page_img_adjustlight_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

home_page_img_sport = lv.img(home_page)
home_page_img_sport.set_pos(74,11)
home_page_img_sport.set_size(40,40)
home_page_img_sport.add_flag(lv.obj.FLAG.CLICKABLE)
try:
    with open('D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-447713923.png','rb') as f:
        home_page_img_sport_img_data = f.read()
except:
    print('Could not open D:\\NXP\\GUI-Guider-Projects\\demo_01\\generated\\mp-447713923.png')
    sys.exit()

home_page_img_sport_img = lv.img_dsc_t({
  'data_size': len(home_page_img_sport_img_data),
  'header': {'always_zero': 0, 'w': 40, 'h': 40, 'cf': lv.img.CF.TRUE_COLOR_ALPHA},
  'data': home_page_img_sport_img_data
})

home_page_img_sport.set_src(home_page_img_sport_img)
home_page_img_sport.set_pivot(0,0)
home_page_img_sport.set_angle(0)
# create style style_home_page_img_sport_main_main_default
style_home_page_img_sport_main_main_default = lv.style_t()
style_home_page_img_sport_main_main_default.init()
style_home_page_img_sport_main_main_default.set_img_recolor(lv.color_make(0xff,0xff,0xff))
style_home_page_img_sport_main_main_default.set_img_recolor_opa(0)
style_home_page_img_sport_main_main_default.set_img_opa(255)

# add style for home_page_img_sport
home_page_img_sport.add_style(style_home_page_img_sport_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

home_page_btn_adjustlight = lv.btn(home_page)
home_page_btn_adjustlight.set_pos(11,11)
home_page_btn_adjustlight.set_size(40,40)
# create style style_home_page_btn_adjustlight_main_main_default
style_home_page_btn_adjustlight_main_main_default = lv.style_t()
style_home_page_btn_adjustlight_main_main_default.init()
style_home_page_btn_adjustlight_main_main_default.set_radius(4)
style_home_page_btn_adjustlight_main_main_default.set_bg_color(lv.color_make(0xff,0xff,0xff))
style_home_page_btn_adjustlight_main_main_default.set_bg_grad_color(lv.color_make(0xff,0xff,0xff))
style_home_page_btn_adjustlight_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_home_page_btn_adjustlight_main_main_default.set_bg_opa(0)
style_home_page_btn_adjustlight_main_main_default.set_shadow_color(lv.color_make(0x21,0x95,0xf6))
style_home_page_btn_adjustlight_main_main_default.set_shadow_opa(0)
style_home_page_btn_adjustlight_main_main_default.set_border_color(lv.color_make(0x21,0x95,0xf6))
style_home_page_btn_adjustlight_main_main_default.set_border_width(0)
style_home_page_btn_adjustlight_main_main_default.set_border_opa(255)

# add style for home_page_btn_adjustlight
home_page_btn_adjustlight.add_style(style_home_page_btn_adjustlight_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

home_page_btn_sport = lv.btn(home_page)
home_page_btn_sport.set_pos(74,11)
home_page_btn_sport.set_size(40,40)
# create style style_home_page_btn_sport_main_main_default
style_home_page_btn_sport_main_main_default = lv.style_t()
style_home_page_btn_sport_main_main_default.init()
style_home_page_btn_sport_main_main_default.set_radius(5)
style_home_page_btn_sport_main_main_default.set_bg_color(lv.color_make(0xff,0xff,0xff))
style_home_page_btn_sport_main_main_default.set_bg_grad_color(lv.color_make(0xff,0xff,0xff))
style_home_page_btn_sport_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_home_page_btn_sport_main_main_default.set_bg_opa(0)
style_home_page_btn_sport_main_main_default.set_shadow_color(lv.color_make(0x21,0x95,0xf6))
style_home_page_btn_sport_main_main_default.set_shadow_opa(0)
style_home_page_btn_sport_main_main_default.set_border_color(lv.color_make(0x21,0x95,0xf6))
style_home_page_btn_sport_main_main_default.set_border_width(0)
style_home_page_btn_sport_main_main_default.set_border_opa(255)

# add style for home_page_btn_sport
home_page_btn_sport.add_style(style_home_page_btn_sport_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

adjust_light_page = lv.obj()
# create style style_adjust_light_page_main_main_default
style_adjust_light_page_main_main_default = lv.style_t()
style_adjust_light_page_main_main_default.init()
style_adjust_light_page_main_main_default.set_bg_color(lv.color_make(0xff,0xff,0xff))
style_adjust_light_page_main_main_default.set_bg_opa(255)

# add style for adjust_light_page
adjust_light_page.add_style(style_adjust_light_page_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

adjust_light_page_slider_1 = lv.slider(adjust_light_page)
adjust_light_page_slider_1.set_pos(14,51)
adjust_light_page_slider_1.set_size(100,6)
adjust_light_page_slider_1.set_range(0, 100)
adjust_light_page_slider_1.set_value(31, False)

# create style style_adjust_light_page_slider_1_main_main_default
style_adjust_light_page_slider_1_main_main_default = lv.style_t()
style_adjust_light_page_slider_1_main_main_default.init()
style_adjust_light_page_slider_1_main_main_default.set_radius(50)
style_adjust_light_page_slider_1_main_main_default.set_bg_color(lv.color_make(0x84,0x22,0xb9))
style_adjust_light_page_slider_1_main_main_default.set_bg_grad_color(lv.color_make(0xe3,0x0d,0xbf))
style_adjust_light_page_slider_1_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.HOR)
style_adjust_light_page_slider_1_main_main_default.set_bg_opa(100)
style_adjust_light_page_slider_1_main_main_default.set_outline_color(lv.color_make(0xba,0x08,0xdd))
style_adjust_light_page_slider_1_main_main_default.set_outline_width(0)
style_adjust_light_page_slider_1_main_main_default.set_outline_opa(255)
style_adjust_light_page_slider_1_main_main_default.set_pad_left(0)
style_adjust_light_page_slider_1_main_main_default.set_pad_right(0)
style_adjust_light_page_slider_1_main_main_default.set_pad_top(0)
style_adjust_light_page_slider_1_main_main_default.set_pad_bottom(0)

# add style for adjust_light_page_slider_1
adjust_light_page_slider_1.add_style(style_adjust_light_page_slider_1_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

# create style style_adjust_light_page_slider_1_main_indicator_default
style_adjust_light_page_slider_1_main_indicator_default = lv.style_t()
style_adjust_light_page_slider_1_main_indicator_default.init()
style_adjust_light_page_slider_1_main_indicator_default.set_radius(50)
style_adjust_light_page_slider_1_main_indicator_default.set_bg_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_slider_1_main_indicator_default.set_bg_grad_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_slider_1_main_indicator_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_adjust_light_page_slider_1_main_indicator_default.set_bg_opa(255)

# add style for adjust_light_page_slider_1
adjust_light_page_slider_1.add_style(style_adjust_light_page_slider_1_main_indicator_default, lv.PART.INDICATOR|lv.STATE.DEFAULT)

# create style style_adjust_light_page_slider_1_main_knob_default
style_adjust_light_page_slider_1_main_knob_default = lv.style_t()
style_adjust_light_page_slider_1_main_knob_default.init()
style_adjust_light_page_slider_1_main_knob_default.set_radius(50)
style_adjust_light_page_slider_1_main_knob_default.set_bg_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_slider_1_main_knob_default.set_bg_grad_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_slider_1_main_knob_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_adjust_light_page_slider_1_main_knob_default.set_bg_opa(255)

# add style for adjust_light_page_slider_1
adjust_light_page_slider_1.add_style(style_adjust_light_page_slider_1_main_knob_default, lv.PART.KNOB|lv.STATE.DEFAULT)

adjust_light_page_btn_light_set = lv.btn(adjust_light_page)
adjust_light_page_btn_light_set.set_pos(41,81)
adjust_light_page_btn_light_set.set_size(40,25)
adjust_light_page_btn_light_set_label = lv.label(adjust_light_page_btn_light_set)
adjust_light_page_btn_light_set_label.set_text("set")
adjust_light_page_btn_light_set.set_style_pad_all(0, lv.STATE.DEFAULT)
adjust_light_page_btn_light_set_label.align(lv.ALIGN.CENTER,0,0)
adjust_light_page_btn_light_set_label.set_style_text_color(lv.color_make(0xe8,0xec,0x13), lv.STATE.DEFAULT)
try:
    adjust_light_page_btn_light_set_label.set_style_text_font(lv.font_montserratMedium_11, lv.STATE.DEFAULT)
except AttributeError:
    try:
        adjust_light_page_btn_light_set_label.set_style_text_font(lv.font_montserrat_11, lv.STATE.DEFAULT)
    except AttributeError:
        adjust_light_page_btn_light_set_label.set_style_text_font(lv.font_montserrat_16, lv.STATE.DEFAULT)
# create style style_adjust_light_page_btn_light_set_main_main_default
style_adjust_light_page_btn_light_set_main_main_default = lv.style_t()
style_adjust_light_page_btn_light_set_main_main_default.init()
style_adjust_light_page_btn_light_set_main_main_default.set_radius(5)
style_adjust_light_page_btn_light_set_main_main_default.set_bg_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_btn_light_set_main_main_default.set_bg_grad_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_btn_light_set_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_adjust_light_page_btn_light_set_main_main_default.set_bg_opa(255)
style_adjust_light_page_btn_light_set_main_main_default.set_shadow_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_btn_light_set_main_main_default.set_shadow_opa(255)
style_adjust_light_page_btn_light_set_main_main_default.set_border_color(lv.color_make(0x21,0x95,0xf6))
style_adjust_light_page_btn_light_set_main_main_default.set_border_width(0)
style_adjust_light_page_btn_light_set_main_main_default.set_border_opa(255)

# add style for adjust_light_page_btn_light_set
adjust_light_page_btn_light_set.add_style(style_adjust_light_page_btn_light_set_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

sport_data_page = lv.obj()
# create style style_sport_data_page_main_main_default
style_sport_data_page_main_main_default = lv.style_t()
style_sport_data_page_main_main_default.init()
style_sport_data_page_main_main_default.set_bg_color(lv.color_make(0xff,0xff,0xff))
style_sport_data_page_main_main_default.set_bg_opa(255)

# add style for sport_data_page
sport_data_page.add_style(style_sport_data_page_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

sport_data_page_btn_sport_data_page = lv.btn(sport_data_page)
sport_data_page_btn_sport_data_page.set_pos(0,0)
sport_data_page_btn_sport_data_page.set_size(128,128)
# create style style_sport_data_page_btn_sport_data_page_main_main_default
style_sport_data_page_btn_sport_data_page_main_main_default = lv.style_t()
style_sport_data_page_btn_sport_data_page_main_main_default.init()
style_sport_data_page_btn_sport_data_page_main_main_default.set_radius(5)
style_sport_data_page_btn_sport_data_page_main_main_default.set_bg_color(lv.color_make(0x21,0x95,0xf6))
style_sport_data_page_btn_sport_data_page_main_main_default.set_bg_grad_color(lv.color_make(0x21,0x95,0xf6))
style_sport_data_page_btn_sport_data_page_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_sport_data_page_btn_sport_data_page_main_main_default.set_bg_opa(0)
style_sport_data_page_btn_sport_data_page_main_main_default.set_shadow_color(lv.color_make(0x0c,0xa2,0xed))
style_sport_data_page_btn_sport_data_page_main_main_default.set_shadow_opa(255)
style_sport_data_page_btn_sport_data_page_main_main_default.set_border_color(lv.color_make(0x21,0x95,0xf6))
style_sport_data_page_btn_sport_data_page_main_main_default.set_border_width(0)
style_sport_data_page_btn_sport_data_page_main_main_default.set_border_opa(255)

# add style for sport_data_page_btn_sport_data_page
sport_data_page_btn_sport_data_page.add_style(style_sport_data_page_btn_sport_data_page_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

sport_data_page_chart_sport = lv.chart(sport_data_page)
sport_data_page_chart_sport.set_pos(0,0)
sport_data_page_chart_sport.set_size(128,100)
sport_data_page_chart_sport.set_type(lv.chart.TYPE.LINE)
sport_data_page_chart_sport.set_range(lv.chart.AXIS.PRIMARY_Y, 0, 200)
sport_data_page_chart_sport.set_div_line_count(20, 12)
sport_data_page_chart_sport.set_point_count(50)
chart_series_0 = lv.chart.add_series(sport_data_page_chart_sport, lv.color_make(0xea,0x79,0x10), lv.chart.AXIS.PRIMARY_Y);
sport_data_page_chart_sport.set_next_value(chart_series_0, 100)
sport_data_page_chart_sport.set_next_value(chart_series_0, 20)
sport_data_page_chart_sport.set_next_value(chart_series_0, 30)
sport_data_page_chart_sport.set_next_value(chart_series_0, 40)
sport_data_page_chart_sport.set_next_value(chart_series_0, 5)
# create style style_sport_data_page_chart_sport_main_main_default
style_sport_data_page_chart_sport_main_main_default = lv.style_t()
style_sport_data_page_chart_sport_main_main_default.init()
style_sport_data_page_chart_sport_main_main_default.set_bg_color(lv.color_make(0xe8,0xee,0x96))
style_sport_data_page_chart_sport_main_main_default.set_bg_grad_color(lv.color_make(0xff,0xff,0xff))
style_sport_data_page_chart_sport_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.VER)
style_sport_data_page_chart_sport_main_main_default.set_bg_opa(158)
style_sport_data_page_chart_sport_main_main_default.set_pad_left(0)
style_sport_data_page_chart_sport_main_main_default.set_pad_right(0)
style_sport_data_page_chart_sport_main_main_default.set_pad_top(4)
style_sport_data_page_chart_sport_main_main_default.set_pad_bottom(0)
style_sport_data_page_chart_sport_main_main_default.set_line_color(lv.color_make(0xe9,0xaa,0xaa))
style_sport_data_page_chart_sport_main_main_default.set_line_width(1)
style_sport_data_page_chart_sport_main_main_default.set_line_opa(255)

# add style for sport_data_page_chart_sport
sport_data_page_chart_sport.add_style(style_sport_data_page_chart_sport_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)

sport_data_page_label_sport_time_data = lv.label(sport_data_page)
sport_data_page_label_sport_time_data.set_pos(0,100)
sport_data_page_label_sport_time_data.set_size(128,28)
sport_data_page_label_sport_time_data.set_text("12 11 10 9 8 7 6 5 4 3 2 1")
sport_data_page_label_sport_time_data.set_long_mode(lv.label.LONG.WRAP)
sport_data_page_label_sport_time_data.set_style_text_align(lv.TEXT_ALIGN.CENTER, 0)
# create style style_sport_data_page_label_sport_time_data_main_main_default
style_sport_data_page_label_sport_time_data_main_main_default = lv.style_t()
style_sport_data_page_label_sport_time_data_main_main_default.init()
style_sport_data_page_label_sport_time_data_main_main_default.set_radius(0)
style_sport_data_page_label_sport_time_data_main_main_default.set_bg_color(lv.color_make(0xda,0xc6,0xa9))
style_sport_data_page_label_sport_time_data_main_main_default.set_bg_grad_color(lv.color_make(0xee,0x8c,0x1b))
style_sport_data_page_label_sport_time_data_main_main_default.set_bg_grad_dir(lv.GRAD_DIR.HOR)
style_sport_data_page_label_sport_time_data_main_main_default.set_bg_opa(147)
style_sport_data_page_label_sport_time_data_main_main_default.set_text_color(lv.color_make(0xf4,0x4d,0x06))
try:
    style_sport_data_page_label_sport_time_data_main_main_default.set_text_font(lv.font_montserratMedium_5)
except AttributeError:
    try:
        style_sport_data_page_label_sport_time_data_main_main_default.set_text_font(lv.font_montserrat_5)
    except AttributeError:
        style_sport_data_page_label_sport_time_data_main_main_default.set_text_font(lv.font_montserrat_16)
style_sport_data_page_label_sport_time_data_main_main_default.set_text_letter_space(2)
style_sport_data_page_label_sport_time_data_main_main_default.set_pad_left(0)
style_sport_data_page_label_sport_time_data_main_main_default.set_pad_right(0)
style_sport_data_page_label_sport_time_data_main_main_default.set_pad_top(0)
style_sport_data_page_label_sport_time_data_main_main_default.set_pad_bottom(0)

# add style for sport_data_page_label_sport_time_data
sport_data_page_label_sport_time_data.add_style(style_sport_data_page_label_sport_time_data_main_main_default, lv.PART.MAIN|lv.STATE.DEFAULT)



def sport_data_page_btn_sport_data_page_clicked_1_event_cb(e,home_page):
    src = e.get_target()
    code = e.get_code()
    lv.scr_load_anim(home_page, lv.SCR_LOAD_ANIM.FADE_ON, 500, 0, False)
sport_data_page_btn_sport_data_page.add_event_cb(lambda e: sport_data_page_btn_sport_data_page_clicked_1_event_cb(e,home_page), lv.EVENT.CLICKED, None)


def home_page_btn_adjustlight_clicked_1_event_cb(e,adjust_light_page):
    src = e.get_target()
    code = e.get_code()
    lv.scr_load_anim(adjust_light_page, lv.SCR_LOAD_ANIM.OVER_LEFT, 500, 0, False)
home_page_btn_adjustlight.add_event_cb(lambda e: home_page_btn_adjustlight_clicked_1_event_cb(e,adjust_light_page), lv.EVENT.CLICKED, None)


def home_page_btn_sport_clicked_1_event_cb(e,sport_data_page):
    src = e.get_target()
    code = e.get_code()
    lv.scr_load_anim(sport_data_page, lv.SCR_LOAD_ANIM.OVER_LEFT, 500, 0, False)
home_page_btn_sport.add_event_cb(lambda e: home_page_btn_sport_clicked_1_event_cb(e,sport_data_page), lv.EVENT.CLICKED, None)


def adjust_light_page_btn_light_set_clicked_1_event_cb(e,home_page):
    src = e.get_target()
    code = e.get_code()
    lv.scr_load_anim(home_page, lv.SCR_LOAD_ANIM.FADE_ON, 500, 0, False)
adjust_light_page_btn_light_set.add_event_cb(lambda e: adjust_light_page_btn_light_set_clicked_1_event_cb(e,home_page), lv.EVENT.CLICKED, None)


def screen_btn_home_clicked_1_event_cb(e,home_page):
    src = e.get_target()
    code = e.get_code()
    lv.scr_load_anim(home_page, lv.SCR_LOAD_ANIM.FADE_ON, 500, 0, False)
screen_btn_home.add_event_cb(lambda e: screen_btn_home_clicked_1_event_cb(e,home_page), lv.EVENT.CLICKED, None)



# content from custom.py

# Load the default screen
lv.scr_load(screen)

while SDL.check():
    time.sleep_ms(5)
