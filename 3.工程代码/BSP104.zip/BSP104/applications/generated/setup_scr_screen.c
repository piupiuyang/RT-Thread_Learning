/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "custom/custom.h"


void setup_scr_screen(lv_ui *ui){
    extern lv_indev_t *indev_keypad;
    lv_group_t* g = lv_group_create();
    lv_indev_set_group(indev_keypad, g);
	//Write codes screen
	ui->screen = lv_obj_create(NULL);
	rt_kprintf("ui->screen:%x",ui->screen);

	//Write style state: LV_STATE_DEFAULT for style_screen_main_main_default
	static lv_style_t style_screen_main_main_default;
	lv_style_reset(&style_screen_main_main_default);
	lv_style_set_bg_color(&style_screen_main_main_default, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_bg_opa(&style_screen_main_main_default, 255);
	lv_obj_add_style(ui->screen, &style_screen_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_btn_home
	ui->screen_btn_home = lv_btn_create(ui->screen);
	lv_obj_set_pos(ui->screen_btn_home, 0, 0);
	lv_obj_set_size(ui->screen_btn_home, 128, 128);

	//Write style state: LV_STATE_DEFAULT for style_screen_btn_home_main_main_default
	static lv_style_t style_screen_btn_home_main_main_default;
	lv_style_reset(&style_screen_btn_home_main_main_default);
	lv_style_set_radius(&style_screen_btn_home_main_main_default, 10);
	lv_style_set_bg_color(&style_screen_btn_home_main_main_default, lv_color_make(0x23, 0x9a, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_btn_home_main_main_default, lv_color_make(0xf6, 0xda, 0x23));
	lv_style_set_bg_grad_dir(&style_screen_btn_home_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_btn_home_main_main_default, 149);
	lv_style_set_shadow_color(&style_screen_btn_home_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_screen_btn_home_main_main_default, 0);
	lv_style_set_border_color(&style_screen_btn_home_main_main_default, lv_color_make(0x23, 0xaf, 0xf6));
	lv_style_set_border_width(&style_screen_btn_home_main_main_default, 2);
	lv_style_set_border_opa(&style_screen_btn_home_main_main_default, 255);
	lv_obj_add_style(ui->screen_btn_home, &style_screen_btn_home_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Update pos for widget screen_btn_home
	lv_obj_update_layout(ui->screen_btn_home);
	ui->screen_btn_home_label = lv_label_create(ui->screen_btn_home);
	lv_label_set_text(ui->screen_btn_home_label, "");
	lv_obj_set_style_text_color(ui->screen_btn_home_label, lv_color_make(0x0d, 0xe1, 0xfd), LV_STATE_DEFAULT);
	lv_obj_set_style_pad_all(ui->screen_btn_home, 0, LV_STATE_DEFAULT);
	lv_obj_align(ui->screen_btn_home_label, LV_ALIGN_CENTER, 0, 0);

	lv_group_add_obj(g, ui->screen_btn_home);

	//Write codes screen_label_time
	ui->screen_label_time = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_time, 14, 10);
	lv_obj_set_size(ui->screen_label_time, 100, 23);
	lv_label_set_text(ui->screen_label_time, "23:07:33");
	lv_label_set_long_mode(ui->screen_label_time, LV_LABEL_LONG_WRAP);
	lv_obj_set_style_text_align(ui->screen_label_time, LV_TEXT_ALIGN_CENTER, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_time_main_main_default
	static lv_style_t style_screen_label_time_main_main_default;
	lv_style_reset(&style_screen_label_time_main_main_default);
	lv_style_set_radius(&style_screen_label_time_main_main_default, 4);
	lv_style_set_bg_color(&style_screen_label_time_main_main_default, lv_color_make(0xf6, 0xee, 0x09));
	lv_style_set_bg_grad_color(&style_screen_label_time_main_main_default, lv_color_make(0x23, 0xf6, 0xc1));
	lv_style_set_bg_grad_dir(&style_screen_label_time_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_time_main_main_default, 82);
	lv_style_set_text_color(&style_screen_label_time_main_main_default, lv_color_make(0xbf, 0xba, 0x31));
	lv_style_set_text_font(&style_screen_label_time_main_main_default, &lv_font_montserratMedium_22);
	lv_style_set_text_letter_space(&style_screen_label_time_main_main_default, 0);
	lv_style_set_pad_left(&style_screen_label_time_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_time_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_time_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_time_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_time, &style_screen_label_time_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_img_weather
	ui->screen_img_weather = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_weather, 5, 54);
	lv_obj_set_size(ui->screen_img_weather, 50, 50);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_weather_main_main_default
	static lv_style_t style_screen_img_weather_main_main_default;
	lv_style_reset(&style_screen_img_weather_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_weather_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_weather_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_weather_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_weather, &style_screen_img_weather_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_weather, LV_OBJ_FLAG_CLICKABLE);
	//lv_img_set_src(ui->screen_img_weather,&_cloude_50x50);
	lv_img_set_pivot(ui->screen_img_weather, 0,0);
	lv_img_set_angle(ui->screen_img_weather, 0);

	//Write codes screen_lable_temp
	ui->screen_lable_temp = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_lable_temp, 71, 56);
	lv_obj_set_size(ui->screen_lable_temp, 43, 12);
	lv_label_set_text(ui->screen_lable_temp, ":27.2");
	lv_label_set_long_mode(ui->screen_lable_temp, LV_LABEL_LONG_WRAP);
	lv_obj_set_style_text_align(ui->screen_lable_temp, LV_TEXT_ALIGN_CENTER, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_lable_temp_main_main_default
	static lv_style_t style_screen_lable_temp_main_main_default;
	lv_style_reset(&style_screen_lable_temp_main_main_default);
	lv_style_set_radius(&style_screen_lable_temp_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_lable_temp_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_lable_temp_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_lable_temp_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_lable_temp_main_main_default, 0);
	lv_style_set_text_color(&style_screen_lable_temp_main_main_default, lv_color_make(0xd7, 0xc0, 0x28));
	lv_style_set_text_font(&style_screen_lable_temp_main_main_default, &lv_font_montserratMedium_11);
	lv_style_set_text_letter_space(&style_screen_lable_temp_main_main_default, 2);
	lv_style_set_pad_left(&style_screen_lable_temp_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_lable_temp_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_lable_temp_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_lable_temp_main_main_default, 0);
	lv_obj_add_style(ui->screen_lable_temp, &style_screen_lable_temp_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_humid
	ui->screen_label_humid = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_humid, 71, 76);
	lv_obj_set_size(ui->screen_label_humid, 43, 12);
	lv_label_set_text(ui->screen_label_humid, ":33%");
	lv_label_set_long_mode(ui->screen_label_humid, LV_LABEL_LONG_WRAP);
	lv_obj_set_style_text_align(ui->screen_label_humid, LV_TEXT_ALIGN_CENTER, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_humid_main_main_default
	static lv_style_t style_screen_label_humid_main_main_default;
	lv_style_reset(&style_screen_label_humid_main_main_default);
	lv_style_set_radius(&style_screen_label_humid_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_humid_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_humid_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_humid_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_humid_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_humid_main_main_default, lv_color_make(0xcc, 0xd8, 0x22));
	lv_style_set_text_font(&style_screen_label_humid_main_main_default, &lv_font_montserratMedium_11);
	lv_style_set_text_letter_space(&style_screen_label_humid_main_main_default, 2);
	lv_style_set_pad_left(&style_screen_label_humid_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_humid_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_humid_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_humid_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_humid, &style_screen_label_humid_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_pace
	ui->screen_label_pace = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_pace, 71, 96);
	lv_obj_set_size(ui->screen_label_pace, 43, 12);
	lv_label_set_text(ui->screen_label_pace, ":3421");
	lv_label_set_long_mode(ui->screen_label_pace, LV_LABEL_LONG_WRAP);
	lv_obj_set_style_text_align(ui->screen_label_pace, LV_TEXT_ALIGN_CENTER, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_pace_main_main_default
	static lv_style_t style_screen_label_pace_main_main_default;
	lv_style_reset(&style_screen_label_pace_main_main_default);
	lv_style_set_radius(&style_screen_label_pace_main_main_default, 0);
	lv_style_set_bg_color(&style_screen_label_pace_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_screen_label_pace_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_screen_label_pace_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_pace_main_main_default, 0);
	lv_style_set_text_color(&style_screen_label_pace_main_main_default, lv_color_make(0xd9, 0xe7, 0x23));
	lv_style_set_text_font(&style_screen_label_pace_main_main_default, &lv_font_montserratMedium_11);
	lv_style_set_text_letter_space(&style_screen_label_pace_main_main_default, 2);
	lv_style_set_pad_left(&style_screen_label_pace_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_pace_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_pace_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_pace_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_pace, &style_screen_label_pace_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_label_date
	ui->screen_label_date = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_date, 16, 38);
	lv_obj_set_size(ui->screen_label_date, 74, 12);
	lv_label_set_text(ui->screen_label_date, "2022.7.31");
	lv_label_set_long_mode(ui->screen_label_date, LV_LABEL_LONG_WRAP);
	lv_obj_set_style_text_align(ui->screen_label_date, LV_TEXT_ALIGN_CENTER, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_date_main_main_default
	static lv_style_t style_screen_label_date_main_main_default;
	lv_style_reset(&style_screen_label_date_main_main_default);
	lv_style_set_radius(&style_screen_label_date_main_main_default, 4);
	lv_style_set_bg_color(&style_screen_label_date_main_main_default, lv_color_make(0x3b, 0xd3, 0x1d));
	lv_style_set_bg_grad_color(&style_screen_label_date_main_main_default, lv_color_make(0xa0, 0xb1, 0x25));
	lv_style_set_bg_grad_dir(&style_screen_label_date_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_date_main_main_default, 117);
	lv_style_set_text_color(&style_screen_label_date_main_main_default, lv_color_make(0x56, 0xe6, 0xc2));
	lv_style_set_text_font(&style_screen_label_date_main_main_default, &lv_font_montserratMedium_11);
	lv_style_set_text_letter_space(&style_screen_label_date_main_main_default, 0);
	lv_style_set_pad_left(&style_screen_label_date_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_date_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_date_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_date_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_date, &style_screen_label_date_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_img_thermometer
	ui->screen_img_thermometer = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_thermometer, 61, 54);
	lv_obj_set_size(ui->screen_img_thermometer, 16, 16);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_thermometer_main_main_default
	static lv_style_t style_screen_img_thermometer_main_main_default;
	lv_style_reset(&style_screen_img_thermometer_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_thermometer_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_thermometer_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_thermometer_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_thermometer, &style_screen_img_thermometer_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_thermometer, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_thermometer,&_Thermometer_16x16);
	lv_img_set_pivot(ui->screen_img_thermometer, 0,0);
	lv_img_set_angle(ui->screen_img_thermometer, 0);

	//Write codes screen_img_humid
	ui->screen_img_humid = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_humid, 64, 76);
	lv_obj_set_size(ui->screen_img_humid, 12, 13);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_humid_main_main_default
	static lv_style_t style_screen_img_humid_main_main_default;
	lv_style_reset(&style_screen_img_humid_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_humid_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_humid_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_humid_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_humid, &style_screen_img_humid_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_humid, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_humid,&_humid_12x13);
	lv_img_set_pivot(ui->screen_img_humid, 0,0);
	lv_img_set_angle(ui->screen_img_humid, 0);

	//Write codes screen_img_pace
	ui->screen_img_pace = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_pace, 62, 95);
	lv_obj_set_size(ui->screen_img_pace, 11, 14);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_pace_main_main_default
	static lv_style_t style_screen_img_pace_main_main_default;
	lv_style_reset(&style_screen_img_pace_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_pace_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_pace_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_pace_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_pace, &style_screen_img_pace_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_pace, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_pace,&_sport_11x14);
	lv_img_set_pivot(ui->screen_img_pace, 0,0);
	lv_img_set_angle(ui->screen_img_pace, 0);

	//Write codes screen_label_1
	ui->screen_label_1 = lv_label_create(ui->screen);
	lv_obj_set_pos(ui->screen_label_1, 94, 38);
	lv_obj_set_size(ui->screen_label_1, 24, 12);
	lv_label_set_text(ui->screen_label_1, "Th");
	lv_label_set_long_mode(ui->screen_label_1, LV_LABEL_LONG_CLIP);
	lv_obj_set_style_text_align(ui->screen_label_1, LV_TEXT_ALIGN_CENTER, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_1_main_main_default
	static lv_style_t style_screen_label_1_main_main_default;
	lv_style_reset(&style_screen_label_1_main_main_default);
	lv_style_set_radius(&style_screen_label_1_main_main_default, 4);
	lv_style_set_bg_color(&style_screen_label_1_main_main_default, lv_color_make(0x3b, 0xd3, 0x1d));
	lv_style_set_bg_grad_color(&style_screen_label_1_main_main_default, lv_color_make(0xa0, 0xb1, 0x25));
	lv_style_set_bg_grad_dir(&style_screen_label_1_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_1_main_main_default, 117);
	lv_style_set_text_color(&style_screen_label_1_main_main_default, lv_color_make(0x56, 0xe6, 0xc2));
	lv_style_set_text_font(&style_screen_label_1_main_main_default, &lv_font_montserratMedium_11);
	lv_style_set_text_letter_space(&style_screen_label_1_main_main_default, 0);
	lv_style_set_pad_left(&style_screen_label_1_main_main_default, 0);
	lv_style_set_pad_right(&style_screen_label_1_main_main_default, 0);
	lv_style_set_pad_top(&style_screen_label_1_main_main_default, 0);
	lv_style_set_pad_bottom(&style_screen_label_1_main_main_default, 0);
	lv_obj_add_style(ui->screen_label_1, &style_screen_label_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);



	//Init events for screen
	events_init_screen(ui);
	home_timer_init(ui);

}
