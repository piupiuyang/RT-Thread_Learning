/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#ifndef GUI_GUIDER_H
#define GUI_GUIDER_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"
#include "guider_fonts/guider_fonts.h"

typedef struct
{
	lv_obj_t *screen;
	lv_obj_t *screen_btn_home;
	lv_obj_t *screen_btn_home_label;
	lv_obj_t *screen_label_time;
	lv_obj_t *screen_img_weather;
	lv_obj_t *screen_lable_temp;
	lv_obj_t *screen_label_humid;
	lv_obj_t *screen_label_pace;
	lv_obj_t *screen_label_date;
	lv_obj_t *screen_img_thermometer;
	lv_obj_t *screen_img_humid;
	lv_obj_t *screen_img_pace;
	lv_obj_t *screen_label_1;
	lv_obj_t *screen_img_1;
	lv_obj_t *screen_img_2;
	lv_obj_t *screen_img_3;
	lv_obj_t *home_page;
	lv_obj_t *home_page_img_adjustlight;
	lv_obj_t *home_page_img_sport;
	lv_obj_t *home_page_btn_adjustlight;
	lv_obj_t *home_page_btn_adjustlight_label;
	lv_obj_t *home_page_btn_sport;
	lv_obj_t *home_page_btn_sport_label;
	lv_obj_t *adjust_light_page;
	lv_obj_t *adjust_light_page_slider_1;
	lv_obj_t *adjust_light_page_btn_light_set;
	lv_obj_t *adjust_light_page_btn_light_set_label;
	lv_obj_t *sport_data_page;
	lv_obj_t *sport_data_page_btn_sport_data_page;
	lv_obj_t *sport_data_page_btn_sport_data_page_label;
	lv_obj_t *sport_data_page_chart_sport;
	lv_obj_t *sport_data_page_label_sport_time_data;
}lv_ui;

void setup_ui(lv_ui *ui);
extern lv_ui guider_ui;
void setup_scr_screen(lv_ui *ui);
void setup_scr_home_page(lv_ui *ui);
void setup_scr_adjust_light_page(lv_ui *ui);
void setup_scr_sport_data_page(lv_ui *ui);
LV_IMG_DECLARE(_sport_40x40);
LV_IMG_DECLARE(_sun_50x50);
LV_IMG_DECLARE(_smoke_50x50);
LV_IMG_DECLARE(_rain_50x50);
LV_IMG_DECLARE(_sport_11x14);
LV_IMG_DECLARE(_Thermometer_16x16);
LV_IMG_DECLARE(_humid_12x13);
LV_IMG_DECLARE(_light_40x40);
LV_IMG_DECLARE(_cloude_50x50);

#ifdef __cplusplus
}
#endif
#endif
