/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "custom/custom.h"


void setup_scr_home_page(lv_ui *ui){
    extern lv_indev_t *indev_keypad;
    lv_group_t* homepage_group = lv_group_create();
    lv_indev_set_group(indev_keypad, homepage_group);
	//Write codes home_page
	ui->home_page = lv_obj_create(NULL);

	//Write style state: LV_STATE_DEFAULT for style_home_page_main_main_default
	static lv_style_t style_home_page_main_main_default;
	lv_style_reset(&style_home_page_main_main_default);
	lv_style_set_bg_color(&style_home_page_main_main_default, lv_color_make(0x29, 0xae, 0xdb));
	lv_style_set_bg_opa(&style_home_page_main_main_default, 255);
	lv_obj_add_style(ui->home_page, &style_home_page_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes home_page_img_adjustlight
	ui->home_page_img_adjustlight = lv_img_create(ui->home_page);
	lv_obj_set_pos(ui->home_page_img_adjustlight, 11, 11);
	lv_obj_set_size(ui->home_page_img_adjustlight, 40, 40);

	//Write style state: LV_STATE_DEFAULT for style_home_page_img_adjustlight_main_main_default
	static lv_style_t style_home_page_img_adjustlight_main_main_default;
	lv_style_reset(&style_home_page_img_adjustlight_main_main_default);
	lv_style_set_img_recolor(&style_home_page_img_adjustlight_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_home_page_img_adjustlight_main_main_default, 0);
	lv_style_set_img_opa(&style_home_page_img_adjustlight_main_main_default, 255);
	lv_obj_add_style(ui->home_page_img_adjustlight, &style_home_page_img_adjustlight_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->home_page_img_adjustlight, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->home_page_img_adjustlight,&_light_40x40);
	lv_img_set_pivot(ui->home_page_img_adjustlight, 0,0);
	lv_img_set_angle(ui->home_page_img_adjustlight, 0);

	//Write codes home_page_img_sport
	ui->home_page_img_sport = lv_img_create(ui->home_page);
	lv_obj_set_pos(ui->home_page_img_sport, 74, 11);
	lv_obj_set_size(ui->home_page_img_sport, 40, 40);

	//Write style state: LV_STATE_DEFAULT for style_home_page_img_sport_main_main_default
	static lv_style_t style_home_page_img_sport_main_main_default;
	lv_style_reset(&style_home_page_img_sport_main_main_default);
	lv_style_set_img_recolor(&style_home_page_img_sport_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_home_page_img_sport_main_main_default, 0);
	lv_style_set_img_opa(&style_home_page_img_sport_main_main_default, 255);
	lv_obj_add_style(ui->home_page_img_sport, &style_home_page_img_sport_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->home_page_img_sport, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->home_page_img_sport,&_sport_40x40);
	lv_img_set_pivot(ui->home_page_img_sport, 0,0);
	lv_img_set_angle(ui->home_page_img_sport, 0);

	//Write codes home_page_btn_adjustlight
	ui->home_page_btn_adjustlight = lv_btn_create(ui->home_page);
	lv_obj_set_pos(ui->home_page_btn_adjustlight, 11, 11);
	lv_obj_set_size(ui->home_page_btn_adjustlight, 40, 40);

	//Write style state: LV_STATE_DEFAULT for style_home_page_btn_adjustlight_main_main_default
	static lv_style_t style_home_page_btn_adjustlight_main_main_default;
	lv_style_reset(&style_home_page_btn_adjustlight_main_main_default);
	lv_style_set_radius(&style_home_page_btn_adjustlight_main_main_default, 4);
	lv_style_set_bg_color(&style_home_page_btn_adjustlight_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_home_page_btn_adjustlight_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_home_page_btn_adjustlight_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_home_page_btn_adjustlight_main_main_default, 0);
	lv_style_set_shadow_color(&style_home_page_btn_adjustlight_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_home_page_btn_adjustlight_main_main_default, 0);
	lv_style_set_border_color(&style_home_page_btn_adjustlight_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_border_width(&style_home_page_btn_adjustlight_main_main_default, 0);
	lv_style_set_border_opa(&style_home_page_btn_adjustlight_main_main_default, 255);
	lv_obj_add_style(ui->home_page_btn_adjustlight, &style_home_page_btn_adjustlight_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	ui->home_page_btn_adjustlight_label = lv_label_create(ui->home_page_btn_adjustlight);
	lv_label_set_text(ui->home_page_btn_adjustlight_label, "");
	lv_obj_set_style_text_color(ui->home_page_btn_adjustlight_label, lv_color_make(0x00, 0x00, 0x00), LV_STATE_DEFAULT);
	lv_obj_set_style_pad_all(ui->home_page_btn_adjustlight, 0, LV_STATE_DEFAULT);
	lv_obj_align(ui->home_page_btn_adjustlight_label, LV_ALIGN_CENTER, 0, 0);

	//Write codes home_page_btn_sport
	ui->home_page_btn_sport = lv_btn_create(ui->home_page);
	lv_obj_set_pos(ui->home_page_btn_sport, 74, 11);
	lv_obj_set_size(ui->home_page_btn_sport, 40, 40);

	//Write style state: LV_STATE_DEFAULT for style_home_page_btn_sport_main_main_default
	static lv_style_t style_home_page_btn_sport_main_main_default;
	lv_style_reset(&style_home_page_btn_sport_main_main_default);
	lv_style_set_radius(&style_home_page_btn_sport_main_main_default, 5);
	lv_style_set_bg_color(&style_home_page_btn_sport_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_home_page_btn_sport_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_home_page_btn_sport_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_home_page_btn_sport_main_main_default, 0);
	lv_style_set_shadow_color(&style_home_page_btn_sport_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_home_page_btn_sport_main_main_default, 0);
	lv_style_set_border_color(&style_home_page_btn_sport_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_border_width(&style_home_page_btn_sport_main_main_default, 0);
	lv_style_set_border_opa(&style_home_page_btn_sport_main_main_default, 255);
	lv_obj_add_style(ui->home_page_btn_sport, &style_home_page_btn_sport_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	ui->home_page_btn_sport_label = lv_label_create(ui->home_page_btn_sport);
	lv_label_set_text(ui->home_page_btn_sport_label, "");
	lv_obj_set_style_text_color(ui->home_page_btn_sport_label, lv_color_make(0x00, 0x00, 0x00), LV_STATE_DEFAULT);
	lv_obj_set_style_pad_all(ui->home_page_btn_sport, 0, LV_STATE_DEFAULT);
	lv_obj_align(ui->home_page_btn_sport_label, LV_ALIGN_CENTER, 0, 0);

	lv_group_add_obj(homepage_group, ui->home_page_btn_adjustlight);
	lv_group_add_obj(homepage_group, ui->home_page_btn_sport);
	//Init events for screen
	events_init_home_page(ui);
    homepage_timer_init(ui);
}
