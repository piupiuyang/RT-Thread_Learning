/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "custom/custom.h"


void setup_scr_sport_data_page(lv_ui *ui){
    extern lv_indev_t *indev_keypad;
    lv_group_t* sportdata_group = lv_group_create();
    lv_indev_set_group(indev_keypad, sportdata_group);
	//Write codes sport_data_page
	ui->sport_data_page = lv_obj_create(NULL);

	//Write style state: LV_STATE_DEFAULT for style_sport_data_page_main_main_default
	static lv_style_t style_sport_data_page_main_main_default;
	lv_style_reset(&style_sport_data_page_main_main_default);
	lv_style_set_bg_color(&style_sport_data_page_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_opa(&style_sport_data_page_main_main_default, 255);
	lv_obj_add_style(ui->sport_data_page, &style_sport_data_page_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes sport_data_page_btn_sport_data_page
	ui->sport_data_page_btn_sport_data_page = lv_btn_create(ui->sport_data_page);
	lv_obj_set_pos(ui->sport_data_page_btn_sport_data_page, 0, 0);
	lv_obj_set_size(ui->sport_data_page_btn_sport_data_page, 128, 128);

	//Write style state: LV_STATE_DEFAULT for style_sport_data_page_btn_sport_data_page_main_main_default
	static lv_style_t style_sport_data_page_btn_sport_data_page_main_main_default;
	lv_style_reset(&style_sport_data_page_btn_sport_data_page_main_main_default);
	lv_style_set_radius(&style_sport_data_page_btn_sport_data_page_main_main_default, 5);
	lv_style_set_bg_color(&style_sport_data_page_btn_sport_data_page_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_sport_data_page_btn_sport_data_page_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_sport_data_page_btn_sport_data_page_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_sport_data_page_btn_sport_data_page_main_main_default, 0);
	lv_style_set_shadow_color(&style_sport_data_page_btn_sport_data_page_main_main_default, lv_color_make(0x0c, 0xa2, 0xed));
	lv_style_set_shadow_opa(&style_sport_data_page_btn_sport_data_page_main_main_default, 255);
	lv_style_set_border_color(&style_sport_data_page_btn_sport_data_page_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_border_width(&style_sport_data_page_btn_sport_data_page_main_main_default, 0);
	lv_style_set_border_opa(&style_sport_data_page_btn_sport_data_page_main_main_default, 255);
	lv_obj_add_style(ui->sport_data_page_btn_sport_data_page, &style_sport_data_page_btn_sport_data_page_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	ui->sport_data_page_btn_sport_data_page_label = lv_label_create(ui->sport_data_page_btn_sport_data_page);
	lv_label_set_text(ui->sport_data_page_btn_sport_data_page_label, "");
	lv_obj_set_style_text_color(ui->sport_data_page_btn_sport_data_page_label, lv_color_make(0x00, 0x00, 0x00), LV_STATE_DEFAULT);
	lv_obj_set_style_pad_all(ui->sport_data_page_btn_sport_data_page, 0, LV_STATE_DEFAULT);
	lv_obj_align(ui->sport_data_page_btn_sport_data_page_label, LV_ALIGN_CENTER, 0, 0);

	//Write codes sport_data_page_chart_sport
	ui->sport_data_page_chart_sport = lv_chart_create(ui->sport_data_page);
	lv_obj_set_pos(ui->sport_data_page_chart_sport, 0, 0);
	lv_obj_set_size(ui->sport_data_page_chart_sport, 128, 100);

	//Write style state: LV_STATE_DEFAULT for style_sport_data_page_chart_sport_main_main_default
	static lv_style_t style_sport_data_page_chart_sport_main_main_default;
	lv_style_reset(&style_sport_data_page_chart_sport_main_main_default);
	lv_style_set_bg_color(&style_sport_data_page_chart_sport_main_main_default, lv_color_make(0xe8, 0xee, 0x96));
	lv_style_set_bg_grad_color(&style_sport_data_page_chart_sport_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_sport_data_page_chart_sport_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_sport_data_page_chart_sport_main_main_default, 158);
	lv_style_set_pad_left(&style_sport_data_page_chart_sport_main_main_default, 0);
	lv_style_set_pad_right(&style_sport_data_page_chart_sport_main_main_default, 0);
	lv_style_set_pad_top(&style_sport_data_page_chart_sport_main_main_default, 4);
	lv_style_set_pad_bottom(&style_sport_data_page_chart_sport_main_main_default, 0);
	lv_style_set_line_color(&style_sport_data_page_chart_sport_main_main_default, lv_color_make(0xe9, 0xaa, 0xaa));
	lv_style_set_line_width(&style_sport_data_page_chart_sport_main_main_default, 1);
	lv_style_set_line_opa(&style_sport_data_page_chart_sport_main_main_default, 255);
	lv_obj_add_style(ui->sport_data_page_chart_sport, &style_sport_data_page_chart_sport_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_chart_set_type(ui->sport_data_page_chart_sport, LV_CHART_TYPE_LINE);
	lv_chart_set_range(ui->sport_data_page_chart_sport,LV_CHART_AXIS_PRIMARY_Y, 0, 200);
	lv_chart_set_div_line_count(ui->sport_data_page_chart_sport, 12, 12);
	lv_chart_set_point_count(ui->sport_data_page_chart_sport, 12);
	lv_chart_series_t * sport_data_page_chart_sport_0 = lv_chart_add_series(ui->sport_data_page_chart_sport, lv_color_make(0xea, 0x79, 0x10), LV_CHART_AXIS_PRIMARY_Y);
	lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 100);
	lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 20);
	lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 30);
	lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 40);
	lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 5);
    lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 100);
    lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 20);
    lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 30);
    lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 40);
    lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 5);
    lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 20);
    lv_chart_set_next_value(ui->sport_data_page_chart_sport, sport_data_page_chart_sport_0, 30);
	//Write codes sport_data_page_label_sport_time_data
	ui->sport_data_page_label_sport_time_data = lv_label_create(ui->sport_data_page);
	lv_obj_set_pos(ui->sport_data_page_label_sport_time_data, 0, 100);
	lv_obj_set_size(ui->sport_data_page_label_sport_time_data, 128, 28);
	lv_label_set_text(ui->sport_data_page_label_sport_time_data, "1 2 3 4 5 6 7 8 9 10 11 12");
	lv_label_set_long_mode(ui->sport_data_page_label_sport_time_data, LV_LABEL_LONG_WRAP);
	lv_obj_set_style_text_align(ui->sport_data_page_label_sport_time_data, LV_TEXT_ALIGN_CENTER, 0);

	//Write style state: LV_STATE_DEFAULT for style_sport_data_page_label_sport_time_data_main_main_default
	static lv_style_t style_sport_data_page_label_sport_time_data_main_main_default;
	lv_style_reset(&style_sport_data_page_label_sport_time_data_main_main_default);
	lv_style_set_radius(&style_sport_data_page_label_sport_time_data_main_main_default, 0);
	lv_style_set_bg_color(&style_sport_data_page_label_sport_time_data_main_main_default, lv_color_make(0xda, 0xc6, 0xa9));
	lv_style_set_bg_grad_color(&style_sport_data_page_label_sport_time_data_main_main_default, lv_color_make(0xee, 0x8c, 0x1b));
	lv_style_set_bg_grad_dir(&style_sport_data_page_label_sport_time_data_main_main_default, LV_GRAD_DIR_HOR);
	lv_style_set_bg_opa(&style_sport_data_page_label_sport_time_data_main_main_default, 147);
	lv_style_set_text_color(&style_sport_data_page_label_sport_time_data_main_main_default, lv_color_make(0xf4, 0x4d, 0x06));
	lv_style_set_text_font(&style_sport_data_page_label_sport_time_data_main_main_default, &lv_font_montserratMedium_5);
	lv_style_set_text_letter_space(&style_sport_data_page_label_sport_time_data_main_main_default, 2);
	lv_style_set_pad_left(&style_sport_data_page_label_sport_time_data_main_main_default, 0);
	lv_style_set_pad_right(&style_sport_data_page_label_sport_time_data_main_main_default, 0);
	lv_style_set_pad_top(&style_sport_data_page_label_sport_time_data_main_main_default, 0);
	lv_style_set_pad_bottom(&style_sport_data_page_label_sport_time_data_main_main_default, 0);
	lv_obj_add_style(ui->sport_data_page_label_sport_time_data, &style_sport_data_page_label_sport_time_data_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	lv_group_add_obj(sportdata_group, ui->sport_data_page_btn_sport_data_page);

	//Init events for screen
	events_init_sport_data_page(ui);
}
