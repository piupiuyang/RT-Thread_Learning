/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */


#ifndef EVENTS_INIT_H_
#define EVENTS_INIT_H_
#include "gui_guider.h"
#include "custom/custom.h"
void events_init(lv_ui *ui);
void events_init_screen(lv_ui *ui);
void events_init_home_page(lv_ui *ui);
void events_init_adjust_light_page(lv_ui *ui);
void events_init_sport_data_page(lv_ui *ui);
#endif /* EVENT_CB_H_ */
