/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "custom/custom.h"
int light = 2;//Ĭ������ֵ

void setup_scr_adjust_light_page(lv_ui *ui){
    extern lv_indev_t *indev_keypad;
    lv_group_t* adjust_light_group = lv_group_create();
    lv_indev_set_group(indev_keypad, adjust_light_group);
	//Write codes adjust_light_page
	ui->adjust_light_page = lv_obj_create(NULL);

	//Write style state: LV_STATE_DEFAULT for style_adjust_light_page_main_main_default
	static lv_style_t style_adjust_light_page_main_main_default;
	lv_style_reset(&style_adjust_light_page_main_main_default);
	lv_style_set_bg_color(&style_adjust_light_page_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_opa(&style_adjust_light_page_main_main_default, 255);
	lv_obj_add_style(ui->adjust_light_page, &style_adjust_light_page_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes adjust_light_page_slider_1
	ui->adjust_light_page_slider_1 = lv_slider_create(ui->adjust_light_page);
	lv_obj_set_pos(ui->adjust_light_page_slider_1, 14, 51);
	lv_obj_set_size(ui->adjust_light_page_slider_1, 100, 6);

	//Write style state: LV_STATE_DEFAULT for style_adjust_light_page_slider_1_main_main_default
	static lv_style_t style_adjust_light_page_slider_1_main_main_default;
	lv_style_reset(&style_adjust_light_page_slider_1_main_main_default);
	lv_style_set_radius(&style_adjust_light_page_slider_1_main_main_default, 50);
	lv_style_set_bg_color(&style_adjust_light_page_slider_1_main_main_default, lv_color_make(0x84, 0x22, 0xb9));
	lv_style_set_bg_grad_color(&style_adjust_light_page_slider_1_main_main_default, lv_color_make(0xe3, 0x0d, 0xbf));
	lv_style_set_bg_grad_dir(&style_adjust_light_page_slider_1_main_main_default, LV_GRAD_DIR_HOR);
	lv_style_set_bg_opa(&style_adjust_light_page_slider_1_main_main_default, 100);
	lv_style_set_outline_color(&style_adjust_light_page_slider_1_main_main_default, lv_color_make(0xba, 0x08, 0xdd));
	lv_style_set_outline_width(&style_adjust_light_page_slider_1_main_main_default, 0);
	lv_style_set_outline_opa(&style_adjust_light_page_slider_1_main_main_default, 255);
	lv_style_set_pad_left(&style_adjust_light_page_slider_1_main_main_default, 0);
	lv_style_set_pad_right(&style_adjust_light_page_slider_1_main_main_default, 0);
	lv_style_set_pad_top(&style_adjust_light_page_slider_1_main_main_default, 0);
	lv_style_set_pad_bottom(&style_adjust_light_page_slider_1_main_main_default, 0);
	lv_obj_add_style(ui->adjust_light_page_slider_1, &style_adjust_light_page_slider_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for style_adjust_light_page_slider_1_main_indicator_default
	static lv_style_t style_adjust_light_page_slider_1_main_indicator_default;
	lv_style_reset(&style_adjust_light_page_slider_1_main_indicator_default);
	lv_style_set_radius(&style_adjust_light_page_slider_1_main_indicator_default, 50);
	lv_style_set_bg_color(&style_adjust_light_page_slider_1_main_indicator_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_adjust_light_page_slider_1_main_indicator_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_adjust_light_page_slider_1_main_indicator_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_adjust_light_page_slider_1_main_indicator_default, 255);
	lv_obj_add_style(ui->adjust_light_page_slider_1, &style_adjust_light_page_slider_1_main_indicator_default, LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for style_adjust_light_page_slider_1_main_knob_default
	static lv_style_t style_adjust_light_page_slider_1_main_knob_default;
	lv_style_reset(&style_adjust_light_page_slider_1_main_knob_default);
	lv_style_set_radius(&style_adjust_light_page_slider_1_main_knob_default, 50);
	lv_style_set_bg_color(&style_adjust_light_page_slider_1_main_knob_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_adjust_light_page_slider_1_main_knob_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_adjust_light_page_slider_1_main_knob_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_adjust_light_page_slider_1_main_knob_default, 255);
	lv_obj_add_style(ui->adjust_light_page_slider_1, &style_adjust_light_page_slider_1_main_knob_default, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_slider_set_range(ui->adjust_light_page_slider_1,0, 10);
	lv_slider_set_value(ui->adjust_light_page_slider_1,light,false);

	//Write codes adjust_light_page_btn_light_set
	ui->adjust_light_page_btn_light_set = lv_btn_create(ui->adjust_light_page);
	lv_obj_set_pos(ui->adjust_light_page_btn_light_set, 41, 81);
	lv_obj_set_size(ui->adjust_light_page_btn_light_set, 40, 25);

	//Write style state: LV_STATE_DEFAULT for style_adjust_light_page_btn_light_set_main_main_default
	static lv_style_t style_adjust_light_page_btn_light_set_main_main_default;
	lv_style_reset(&style_adjust_light_page_btn_light_set_main_main_default);
	lv_style_set_radius(&style_adjust_light_page_btn_light_set_main_main_default, 5);
	lv_style_set_bg_color(&style_adjust_light_page_btn_light_set_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_color(&style_adjust_light_page_btn_light_set_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_bg_grad_dir(&style_adjust_light_page_btn_light_set_main_main_default, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_adjust_light_page_btn_light_set_main_main_default, 255);
	lv_style_set_shadow_color(&style_adjust_light_page_btn_light_set_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_shadow_opa(&style_adjust_light_page_btn_light_set_main_main_default, 255);
	lv_style_set_border_color(&style_adjust_light_page_btn_light_set_main_main_default, lv_color_make(0x21, 0x95, 0xf6));
	lv_style_set_border_width(&style_adjust_light_page_btn_light_set_main_main_default, 0);
	lv_style_set_border_opa(&style_adjust_light_page_btn_light_set_main_main_default, 255);
	lv_obj_add_style(ui->adjust_light_page_btn_light_set, &style_adjust_light_page_btn_light_set_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	ui->adjust_light_page_btn_light_set_label = lv_label_create(ui->adjust_light_page_btn_light_set);
	lv_label_set_text(ui->adjust_light_page_btn_light_set_label, "set");
	lv_obj_set_style_text_color(ui->adjust_light_page_btn_light_set_label, lv_color_make(0xe8, 0xec, 0x13), LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->adjust_light_page_btn_light_set_label, &lv_font_montserratMedium_11, LV_STATE_DEFAULT);
	lv_obj_set_style_pad_all(ui->adjust_light_page_btn_light_set, 0, LV_STATE_DEFAULT);
	lv_obj_align(ui->adjust_light_page_btn_light_set_label, LV_ALIGN_CENTER, 0, 0);

    lv_group_add_obj(adjust_light_group, ui->adjust_light_page_btn_light_set);
    lv_group_add_obj(adjust_light_group, ui->adjust_light_page_slider_1);
	//Init events for screen
	events_init_adjust_light_page(ui);
	events_init_adjust_light_slider(ui);
}
