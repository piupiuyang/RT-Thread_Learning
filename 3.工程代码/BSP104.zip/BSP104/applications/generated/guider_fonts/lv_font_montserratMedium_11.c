#include "lvgl.h"

/*******************************************************************************
 * Size: 11 px
 * Bpp: 4
 * Opts: 
 ******************************************************************************/

#ifndef LV_FONT_MONTSERRATMEDIUM_11
#define LV_FONT_MONTSERRATMEDIUM_11 1
#endif

#if LV_FONT_MONTSERRATMEDIUM_11

/*-----------------
 *    BITMAPS
 *----------------*/

/*Store the image of the glyphs*/
static LV_ATTRIBUTE_LARGE_CONST const uint8_t gylph_bitmap[] = {
    /* U+21 "!" */
    0x1f, 0x11, 0xf0, 0xf, 0x0, 0xf0, 0xe, 0x0,
    0x50, 0x5, 0x1, 0xe1,

    /* U+22 "\"" */
    0x49, 0x49, 0x49, 0x49, 0x48, 0x48, 0x0, 0x0,

    /* U+23 "#" */
    0x0, 0x84, 0xa, 0x10, 0x0, 0xa2, 0xc, 0x0,
    0x4d, 0xfd, 0xdf, 0xd5, 0x0, 0xc0, 0xb, 0x0,
    0x0, 0xc0, 0x2a, 0x0, 0x9d, 0xed, 0xde, 0xd1,
    0x4, 0x80, 0x66, 0x0, 0x5, 0x60, 0x84, 0x0,

    /* U+24 "$" */
    0x0, 0x5, 0x0, 0x0, 0x0, 0xb0, 0x0, 0x6,
    0xdf, 0xe9, 0x2, 0xe2, 0xb1, 0x50, 0x4d, 0xb,
    0x0, 0x0, 0xcd, 0xd3, 0x0, 0x0, 0x4d, 0xeb,
    0x0, 0x0, 0xb0, 0xd5, 0x46, 0x1b, 0x1e, 0x32,
    0xae, 0xfe, 0x60, 0x0, 0xb, 0x0, 0x0, 0x0,
    0x50, 0x0,

    /* U+25 "%" */
    0x1a, 0xb4, 0x0, 0x75, 0x7, 0x40, 0xb0, 0x2a,
    0x0, 0x92, 0xb, 0xb, 0x10, 0x6, 0x50, 0xb7,
    0x60, 0x0, 0x8, 0xa5, 0xb1, 0x9a, 0x20, 0x0,
    0xb2, 0x92, 0xa, 0x0, 0x66, 0xa, 0x10, 0xb0,
    0x2b, 0x0, 0x3a, 0xa4,

    /* U+26 "&" */
    0x1, 0xcc, 0xc1, 0x0, 0x8, 0x80, 0x86, 0x0,
    0x5, 0xb2, 0xd2, 0x0, 0x0, 0xef, 0x30, 0x0,
    0xc, 0x7a, 0x90, 0x90, 0x6a, 0x0, 0xbc, 0xb0,
    0x6c, 0x10, 0x4f, 0xa0, 0x8, 0xde, 0xc3, 0xb2,
    0x0, 0x0, 0x0, 0x0,

    /* U+27 "'" */
    0x49, 0x49, 0x48, 0x0,

    /* U+28 "(" */
    0xd, 0x25, 0xa0, 0xa5, 0xd, 0x20, 0xe1, 0xe,
    0x10, 0xd2, 0xa, 0x50, 0x5a, 0x0, 0xd2,

    /* U+29 ")" */
    0x6a, 0x0, 0xe1, 0xa, 0x50, 0x78, 0x6, 0xa0,
    0x6a, 0x7, 0x80, 0xa5, 0xe, 0x16, 0x90,

    /* U+2A "*" */
    0x12, 0x81, 0x6, 0xbd, 0xa0, 0x4c, 0xe8, 0x3,
    0x28, 0x30, 0x0, 0x10, 0x0,

    /* U+2B "+" */
    0x0, 0x39, 0x0, 0x0, 0x4a, 0x0, 0x3e, 0xef,
    0xe9, 0x0, 0x4a, 0x0, 0x0, 0x4a, 0x0,

    /* U+2D "-" */
    0x5f, 0xf8,

    /* U+2E "." */
    0x15, 0x5c,

    /* U+2F "/" */
    0x0, 0x0, 0x61, 0x0, 0x0, 0xe0, 0x0, 0x5,
    0x90, 0x0, 0xb, 0x30, 0x0, 0x1d, 0x0, 0x0,
    0x68, 0x0, 0x0, 0xc3, 0x0, 0x1, 0xd0, 0x0,
    0x7, 0x80, 0x0, 0xc, 0x20, 0x0, 0x2d, 0x0,
    0x0,

    /* U+30 "0" */
    0x1, 0xbf, 0xd4, 0x0, 0xd8, 0x14, 0xe3, 0x4d,
    0x0, 0x8, 0x96, 0xa0, 0x0, 0x5c, 0x6a, 0x0,
    0x5, 0xc4, 0xd0, 0x0, 0x89, 0xd, 0x81, 0x4e,
    0x30, 0x2b, 0xfd, 0x50,

    /* U+31 "1" */
    0xef, 0xe0, 0x2e, 0x2, 0xe0, 0x2e, 0x2, 0xe0,
    0x2e, 0x2, 0xe0, 0x2e,

    /* U+32 "2" */
    0x2b, 0xfe, 0x90, 0x76, 0x11, 0xc7, 0x0, 0x0,
    0x89, 0x0, 0x0, 0xd4, 0x0, 0xc, 0x80, 0x0,
    0xc8, 0x0, 0xc, 0x80, 0x0, 0x9f, 0xff, 0xfe,

    /* U+33 "3" */
    0x9f, 0xff, 0xf7, 0x0, 0x5, 0xd0, 0x0, 0x2e,
    0x20, 0x0, 0xcd, 0x50, 0x0, 0x25, 0xd7, 0x0,
    0x0, 0x5c, 0x84, 0x11, 0xb9, 0x5c, 0xff, 0xa0,

    /* U+34 "4" */
    0x0, 0x1, 0xe3, 0x0, 0x0, 0xc, 0x60, 0x0,
    0x0, 0x8a, 0x0, 0x0, 0x4, 0xd0, 0x28, 0x0,
    0x1e, 0x30, 0x4c, 0x0, 0x8f, 0xff, 0xff, 0xf3,
    0x0, 0x0, 0x4c, 0x0, 0x0, 0x0, 0x4c, 0x0,

    /* U+35 "5" */
    0xe, 0xff, 0xf7, 0xf, 0x0, 0x0, 0x1e, 0x0,
    0x0, 0x3f, 0xfe, 0xa1, 0x0, 0x1, 0xaa, 0x0,
    0x0, 0x3e, 0x76, 0x11, 0x9a, 0x3b, 0xef, 0xb1,

    /* U+36 "6" */
    0x0, 0x9e, 0xfb, 0x0, 0xc9, 0x10, 0x20, 0x3d,
    0x0, 0x0, 0x6, 0xb9, 0xed, 0x60, 0x6f, 0x60,
    0x2e, 0x44, 0xf0, 0x0, 0xa7, 0xd, 0x50, 0x1e,
    0x30, 0x2c, 0xee, 0x60,

    /* U+37 "7" */
    0xaf, 0xff, 0xff, 0x2a, 0x60, 0x5, 0xd0, 0x42,
    0x0, 0xc6, 0x0, 0x0, 0x3e, 0x0, 0x0, 0xa,
    0x80, 0x0, 0x1, 0xf1, 0x0, 0x0, 0x7a, 0x0,
    0x0, 0xe, 0x30, 0x0,

    /* U+38 "8" */
    0x6, 0xde, 0xd7, 0x2, 0xf2, 0x1, 0xe3, 0x1e,
    0x20, 0x1e, 0x20, 0x8f, 0xef, 0x90, 0x4e, 0x20,
    0x2d, 0x57, 0xa0, 0x0, 0x88, 0x4e, 0x20, 0x1d,
    0x50, 0x6d, 0xee, 0x70,

    /* U+39 "9" */
    0x8, 0xee, 0xa1, 0x7, 0xb0, 0x9, 0xa0, 0xa6,
    0x0, 0x2f, 0x17, 0xc1, 0x9, 0xf3, 0x8, 0xed,
    0x8e, 0x30, 0x0, 0x1, 0xf0, 0x2, 0x2, 0xb8,
    0x1, 0xdf, 0xe7, 0x0,

    /* U+3A ":" */
    0x5c, 0x25, 0x0, 0x0, 0x15, 0x5c,

    /* U+3B ";" */
    0x5c, 0x25, 0x0, 0x0, 0x0, 0x5e, 0x2c, 0x47,

    /* U+3C "<" */
    0x0, 0x0, 0x2, 0x0, 0x18, 0xd7, 0x1b, 0xc6,
    0x0, 0x2d, 0xa3, 0x0, 0x0, 0x4a, 0xd5, 0x0,
    0x0, 0x14,

    /* U+3D "=" */
    0x3e, 0xee, 0xe9, 0x0, 0x0, 0x0, 0x0, 0x0,
    0x0, 0x3e, 0xee, 0xe9,

    /* U+3E ">" */
    0x11, 0x0, 0x0, 0x2d, 0xa4, 0x0, 0x0, 0x3a,
    0xd5, 0x0, 0x17, 0xd7, 0x1b, 0xd6, 0x10, 0x23,
    0x0, 0x0,

    /* U+3F "?" */
    0x3b, 0xfe, 0xa0, 0x76, 0x1, 0xd7, 0x0, 0x0,
    0xa7, 0x0, 0x6, 0xd1, 0x0, 0x3e, 0x10, 0x0,
    0x35, 0x0, 0x0, 0x23, 0x0, 0x0, 0x79, 0x0,

    /* U+40 "@" */
    0x0, 0x18, 0xcb, 0xba, 0x40, 0x0, 0x2c, 0x40,
    0x0, 0x19, 0x70, 0xc, 0x22, 0xcd, 0xba, 0x7a,
    0x33, 0x90, 0xd5, 0x2, 0xe7, 0x29, 0x66, 0x2d,
    0x0, 0x9, 0x70, 0xb6, 0x62, 0xd0, 0x0, 0x97,
    0xb, 0x39, 0xd, 0x40, 0x2e, 0x83, 0x90, 0xc2,
    0x2c, 0xdc, 0x3e, 0xc1, 0x2, 0xc4, 0x0, 0x0,
    0x0, 0x0, 0x1, 0x8c, 0xbc, 0xa0, 0x0,

    /* U+41 "A" */
    0x0, 0x0, 0xcc, 0x0, 0x0, 0x0, 0x2, 0xdd,
    0x30, 0x0, 0x0, 0x9, 0x76, 0xa0, 0x0, 0x0,
    0x1e, 0x10, 0xe1, 0x0, 0x0, 0x79, 0x0, 0x98,
    0x0, 0x0, 0xee, 0xee, 0xee, 0x0, 0x5, 0xb0,
    0x0, 0xb, 0x60, 0xc, 0x50, 0x0, 0x4, 0xd0,

    /* U+42 "B" */
    0xde, 0xee, 0xd6, 0xd, 0x40, 0x2, 0xf2, 0xd4,
    0x0, 0xc, 0x5d, 0x40, 0x3, 0xe2, 0xde, 0xee,
    0xfb, 0xd, 0x40, 0x0, 0x99, 0xd4, 0x0, 0x8,
    0xad, 0xee, 0xee, 0xb2,

    /* U+43 "C" */
    0x0, 0x6d, 0xfe, 0x80, 0x9, 0xd3, 0x2, 0xa3,
    0x2f, 0x10, 0x0, 0x0, 0x6b, 0x0, 0x0, 0x0,
    0x6b, 0x0, 0x0, 0x0, 0x2f, 0x10, 0x0, 0x0,
    0x9, 0xd3, 0x2, 0xa3, 0x0, 0x7d, 0xfe, 0x80,

    /* U+44 "D" */
    0xdf, 0xff, 0xd7, 0x0, 0xd4, 0x0, 0x2b, 0xb0,
    0xd4, 0x0, 0x0, 0xe4, 0xd4, 0x0, 0x0, 0x98,
    0xd4, 0x0, 0x0, 0x98, 0xd4, 0x0, 0x0, 0xe4,
    0xd4, 0x0, 0x2b, 0xb0, 0xdf, 0xff, 0xd7, 0x0,

    /* U+45 "E" */
    0xdf, 0xff, 0xf9, 0xd4, 0x0, 0x0, 0xd4, 0x0,
    0x0, 0xd4, 0x0, 0x0, 0xdf, 0xff, 0xf1, 0xd4,
    0x0, 0x0, 0xd4, 0x0, 0x0, 0xdf, 0xff, 0xfb,

    /* U+46 "F" */
    0xdf, 0xff, 0xf9, 0xd4, 0x0, 0x0, 0xd4, 0x0,
    0x0, 0xd4, 0x0, 0x0, 0xdf, 0xff, 0xf1, 0xd4,
    0x0, 0x0, 0xd4, 0x0, 0x0, 0xd4, 0x0, 0x0,

    /* U+47 "G" */
    0x0, 0x6d, 0xfe, 0x90, 0x9, 0xd3, 0x2, 0x94,
    0x2f, 0x10, 0x0, 0x0, 0x6b, 0x0, 0x0, 0x0,
    0x6b, 0x0, 0x0, 0x88, 0x2f, 0x10, 0x0, 0x88,
    0x9, 0xd3, 0x1, 0xb8, 0x0, 0x6d, 0xfd, 0x91,

    /* U+48 "H" */
    0xd4, 0x0, 0x5, 0xcd, 0x40, 0x0, 0x5c, 0xd4,
    0x0, 0x5, 0xcd, 0x40, 0x0, 0x5c, 0xdf, 0xff,
    0xff, 0xcd, 0x40, 0x0, 0x5c, 0xd4, 0x0, 0x5,
    0xcd, 0x40, 0x0, 0x5c,

    /* U+49 "I" */
    0xd4, 0xd4, 0xd4, 0xd4, 0xd4, 0xd4, 0xd4, 0xd4,

    /* U+4A "J" */
    0x4, 0xff, 0xf8, 0x0, 0x0, 0x88, 0x0, 0x0,
    0x88, 0x0, 0x0, 0x88, 0x0, 0x0, 0x88, 0x0,
    0x0, 0x88, 0x9, 0x21, 0xd5, 0x6, 0xee, 0x90,

    /* U+4B "K" */
    0xd4, 0x0, 0x2d, 0x4d, 0x40, 0x1d, 0x50, 0xd4,
    0x1d, 0x60, 0xd, 0x4c, 0xa0, 0x0, 0xde, 0xcf,
    0x20, 0xd, 0xa0, 0x7d, 0x0, 0xd4, 0x0, 0xab,
    0xd, 0x40, 0x0, 0xc7,

    /* U+4C "L" */
    0xd4, 0x0, 0x0, 0xd4, 0x0, 0x0, 0xd4, 0x0,
    0x0, 0xd4, 0x0, 0x0, 0xd4, 0x0, 0x0, 0xd4,
    0x0, 0x0, 0xd4, 0x0, 0x0, 0xdf, 0xff, 0xf6,

    /* U+4D "M" */
    0xd5, 0x0, 0x0, 0xd, 0x5d, 0xe0, 0x0, 0x6,
    0xf5, 0xdd, 0x70, 0x0, 0xed, 0x5d, 0x4e, 0x10,
    0x88, 0xb5, 0xd3, 0x79, 0x2d, 0xb, 0x5d, 0x30,
    0xdc, 0x60, 0xb5, 0xd3, 0x4, 0xc0, 0xb, 0x5d,
    0x30, 0x0, 0x0, 0xb5,

    /* U+4E "N" */
    0xd7, 0x0, 0x5, 0xcd, 0xf3, 0x0, 0x5c, 0xda,
    0xe1, 0x5, 0xcd, 0x49, 0xb0, 0x5c, 0xd4, 0xc,
    0x85, 0xcd, 0x40, 0x2e, 0xac, 0xd4, 0x0, 0x4f,
    0xcd, 0x40, 0x0, 0x8c,

    /* U+4F "O" */
    0x0, 0x6d, 0xfe, 0x80, 0x0, 0x9d, 0x30, 0x2a,
    0xc0, 0x2f, 0x10, 0x0, 0xc, 0x66, 0xb0, 0x0,
    0x0, 0x7a, 0x6b, 0x0, 0x0, 0x7, 0xa2, 0xf1,
    0x0, 0x0, 0xc6, 0x9, 0xd3, 0x2, 0xac, 0x0,
    0x6, 0xdf, 0xe8, 0x0,

    /* U+50 "P" */
    0xdf, 0xff, 0xb3, 0xd, 0x40, 0x6, 0xe1, 0xd4,
    0x0, 0xd, 0x4d, 0x40, 0x0, 0xd4, 0xd4, 0x0,
    0x6e, 0xd, 0xff, 0xeb, 0x20, 0xd4, 0x0, 0x0,
    0xd, 0x40, 0x0, 0x0,

    /* U+51 "Q" */
    0x0, 0x6d, 0xfe, 0x80, 0x0, 0x8, 0xd3, 0x2,
    0xac, 0x0, 0x2f, 0x10, 0x0, 0xc, 0x60, 0x6b,
    0x0, 0x0, 0x7, 0xa0, 0x6a, 0x0, 0x0, 0x7,
    0xa0, 0x3f, 0x10, 0x0, 0xc, 0x60, 0xa, 0xc3,
    0x1, 0xad, 0x0, 0x0, 0x7e, 0xff, 0x91, 0x0,
    0x0, 0x0, 0x4e, 0x30, 0x90, 0x0, 0x0, 0x4,
    0xcd, 0x50,

    /* U+52 "R" */
    0xdf, 0xff, 0xb3, 0xd, 0x40, 0x6, 0xe1, 0xd4,
    0x0, 0xd, 0x4d, 0x40, 0x0, 0xd5, 0xd4, 0x0,
    0x6e, 0xd, 0xff, 0xfe, 0x30, 0xd4, 0x1, 0xd4,
    0xd, 0x40, 0x2, 0xe2,

    /* U+53 "S" */
    0x6, 0xdf, 0xe8, 0x3, 0xe3, 0x1, 0x60, 0x5d,
    0x0, 0x0, 0x0, 0xcd, 0x83, 0x0, 0x0, 0x48,
    0xdb, 0x0, 0x0, 0x0, 0xd5, 0x47, 0x10, 0x2e,
    0x31, 0xae, 0xfd, 0x60,

    /* U+54 "T" */
    0xef, 0xff, 0xff, 0x60, 0x5, 0xc0, 0x0, 0x0,
    0x5c, 0x0, 0x0, 0x5, 0xc0, 0x0, 0x0, 0x5c,
    0x0, 0x0, 0x5, 0xc0, 0x0, 0x0, 0x5c, 0x0,
    0x0, 0x5, 0xc0, 0x0,

    /* U+55 "U" */
    0xe3, 0x0, 0x7, 0x9e, 0x30, 0x0, 0x79, 0xe3,
    0x0, 0x7, 0x9e, 0x30, 0x0, 0x79, 0xe3, 0x0,
    0x7, 0x9c, 0x50, 0x0, 0xa7, 0x6d, 0x20, 0x5f,
    0x10, 0x7d, 0xfc, 0x40,

    /* U+56 "V" */
    0xc, 0x60, 0x0, 0x7, 0xa0, 0x6c, 0x0, 0x0,
    0xe3, 0x0, 0xe3, 0x0, 0x5c, 0x0, 0x8, 0xa0,
    0xb, 0x50, 0x0, 0x1f, 0x12, 0xe0, 0x0, 0x0,
    0xa7, 0x98, 0x0, 0x0, 0x4, 0xef, 0x10, 0x0,
    0x0, 0xd, 0xa0, 0x0,

    /* U+57 "W" */
    0x7a, 0x0, 0x6, 0xe0, 0x0, 0x2d, 0x2, 0xf0,
    0x0, 0xcf, 0x30, 0x8, 0x80, 0xd, 0x40, 0x1e,
    0x88, 0x0, 0xd3, 0x0, 0x89, 0x7, 0x92, 0xe0,
    0x2e, 0x0, 0x3, 0xe0, 0xc4, 0xd, 0x37, 0x90,
    0x0, 0xe, 0x5e, 0x0, 0x88, 0xc4, 0x0, 0x0,
    0x8e, 0x90, 0x2, 0xee, 0x0, 0x0, 0x3, 0xf4,
    0x0, 0xd, 0x90, 0x0,

    /* U+58 "X" */
    0x5d, 0x0, 0x7, 0xb0, 0xa, 0xa0, 0x3e, 0x10,
    0x0, 0xe5, 0xd4, 0x0, 0x0, 0x4f, 0x90, 0x0,
    0x0, 0x6f, 0xc0, 0x0, 0x2, 0xe2, 0xb8, 0x0,
    0xc, 0x70, 0x1e, 0x30, 0x8b, 0x0, 0x5, 0xd0,

    /* U+59 "Y" */
    0xc, 0x60, 0x0, 0x3d, 0x0, 0x2e, 0x10, 0xc,
    0x40, 0x0, 0x99, 0x6, 0xb0, 0x0, 0x1, 0xe4,
    0xe2, 0x0, 0x0, 0x6, 0xf8, 0x0, 0x0, 0x0,
    0xf, 0x10, 0x0, 0x0, 0x0, 0xf1, 0x0, 0x0,
    0x0, 0xf, 0x10, 0x0,

    /* U+5A "Z" */
    0x7f, 0xff, 0xff, 0xb0, 0x0, 0x2, 0xe3, 0x0,
    0x0, 0xd6, 0x0, 0x0, 0xaa, 0x0, 0x0, 0x6d,
    0x0, 0x0, 0x3e, 0x20, 0x0, 0x1e, 0x50, 0x0,
    0x8, 0xff, 0xff, 0xfe,

    /* U+5B "[" */
    0xde, 0x6d, 0x30, 0xd3, 0xd, 0x30, 0xd3, 0xd,
    0x30, 0xd3, 0xd, 0x30, 0xd3, 0xd, 0xe6,

    /* U+5C "\\" */
    0x24, 0x0, 0x0, 0x1d, 0x0, 0x0, 0xb, 0x30,
    0x0, 0x6, 0x90, 0x0, 0x1, 0xe0, 0x0, 0x0,
    0xb4, 0x0, 0x0, 0x59, 0x0, 0x0, 0xe, 0x0,
    0x0, 0xa, 0x40, 0x0, 0x4, 0xa0, 0x0, 0x0,
    0xe0,

    /* U+5D "]" */
    0xbf, 0x80, 0x88, 0x8, 0x80, 0x88, 0x8, 0x80,
    0x88, 0x8, 0x80, 0x88, 0x8, 0x8b, 0xf8,

    /* U+5E "^" */
    0x0, 0x26, 0x0, 0x0, 0xac, 0x10, 0x1, 0xb4,
    0x80, 0x8, 0x40, 0xc0, 0xc, 0x0, 0x76,

    /* U+5F "_" */
    0xbb, 0xbb, 0xb5,

    /* U+60 "`" */
    0x36, 0x0, 0x7, 0x90,

    /* U+61 "a" */
    0x1a, 0xee, 0xa0, 0x3, 0x0, 0xa7, 0x8, 0xcc,
    0xe9, 0x5c, 0x0, 0x7a, 0x5b, 0x0, 0xca, 0xa,
    0xcc, 0xaa,

    /* U+62 "b" */
    0xf1, 0x0, 0x0, 0xf, 0x10, 0x0, 0x0, 0xf7,
    0xdf, 0xa1, 0xf, 0xb0, 0xb, 0xa0, 0xf2, 0x0,
    0x1f, 0xf, 0x20, 0x1, 0xf0, 0xfa, 0x11, 0xaa,
    0xf, 0x6d, 0xfa, 0x10,

    /* U+63 "c" */
    0x4, 0xcf, 0xd4, 0x2e, 0x40, 0x47, 0x7a, 0x0,
    0x0, 0x7a, 0x0, 0x0, 0x2e, 0x40, 0x47, 0x4,
    0xdf, 0xd4,

    /* U+64 "d" */
    0x0, 0x0, 0x9, 0x80, 0x0, 0x0, 0x98, 0x5,
    0xde, 0xba, 0x82, 0xf4, 0x4, 0xf8, 0x7a, 0x0,
    0xa, 0x87, 0xa0, 0x0, 0xa8, 0x2e, 0x30, 0x3f,
    0x80, 0x5d, 0xdb, 0xa8,

    /* U+65 "e" */
    0x4, 0xde, 0xc3, 0x2, 0xc1, 0x3, 0xd0, 0x7e,
    0xcc, 0xcd, 0x37, 0xa0, 0x0, 0x0, 0x2f, 0x50,
    0x37, 0x0, 0x4d, 0xfd, 0x50,

    /* U+66 "f" */
    0x5, 0xee, 0x10, 0xd4, 0x0, 0xbf, 0xec, 0x0,
    0xd3, 0x0, 0xd, 0x30, 0x0, 0xd3, 0x0, 0xd,
    0x30, 0x0, 0xd3, 0x0,

    /* U+67 "g" */
    0x4, 0xdf, 0xb8, 0x92, 0xf4, 0x3, 0xe9, 0x79,
    0x0, 0x8, 0x97, 0xa0, 0x0, 0x89, 0x2f, 0x40,
    0x3f, 0x90, 0x4d, 0xec, 0xa8, 0x5, 0x10, 0x1d,
    0x40, 0x9d, 0xed, 0x70,

    /* U+68 "h" */
    0xf1, 0x0, 0x0, 0xf1, 0x0, 0x0, 0xf7, 0xde,
    0x90, 0xf9, 0x1, 0xd5, 0xf2, 0x0, 0x88, 0xf1,
    0x0, 0x88, 0xf1, 0x0, 0x88, 0xf1, 0x0, 0x88,

    /* U+69 "i" */
    0x1e, 0x20, 0x40, 0xf, 0x10, 0xf1, 0xf, 0x10,
    0xf1, 0xf, 0x10, 0xf1,

    /* U+6A "j" */
    0x0, 0xe, 0x20, 0x0, 0x40, 0x0, 0xf, 0x10,
    0x0, 0xf1, 0x0, 0xf, 0x10, 0x0, 0xf1, 0x0,
    0xf, 0x10, 0x0, 0xf1, 0x0, 0x1f, 0x0, 0xce,
    0x80,

    /* U+6B "k" */
    0xf1, 0x0, 0x0, 0xf1, 0x0, 0x0, 0xf1, 0x5,
    0xd2, 0xf1, 0x6e, 0x20, 0xf7, 0xf4, 0x0, 0xfd,
    0x9c, 0x0, 0xf2, 0xb, 0x90, 0xf1, 0x1, 0xd5,

    /* U+6C "l" */
    0xf1, 0xf1, 0xf1, 0xf1, 0xf1, 0xf1, 0xf1, 0xf1,

    /* U+6D "m" */
    0xf7, 0xde, 0x76, 0xde, 0xa0, 0xf8, 0x1, 0xec,
    0x10, 0xb7, 0xf1, 0x0, 0xb6, 0x0, 0x6a, 0xf1,
    0x0, 0xb6, 0x0, 0x6b, 0xf1, 0x0, 0xb6, 0x0,
    0x6b, 0xf1, 0x0, 0xb6, 0x0, 0x6b,

    /* U+6E "n" */
    0xf7, 0xde, 0x90, 0xf9, 0x1, 0xd5, 0xf1, 0x0,
    0x88, 0xf1, 0x0, 0x88, 0xf1, 0x0, 0x88, 0xf1,
    0x0, 0x88,

    /* U+6F "o" */
    0x4, 0xdf, 0xd4, 0x2, 0xe4, 0x4, 0xe2, 0x7a,
    0x0, 0xa, 0x77, 0xa0, 0x0, 0xa7, 0x2e, 0x40,
    0x4e, 0x20, 0x4d, 0xfd, 0x40,

    /* U+70 "p" */
    0xf7, 0xde, 0xa1, 0xf, 0xa0, 0xa, 0xa0, 0xf2,
    0x0, 0x1f, 0xf, 0x20, 0x1, 0xf0, 0xfb, 0x0,
    0xba, 0xf, 0x7d, 0xea, 0x10, 0xf1, 0x0, 0x0,
    0xf, 0x10, 0x0, 0x0,

    /* U+71 "q" */
    0x5, 0xdf, 0xb9, 0x82, 0xf4, 0x4, 0xf8, 0x7a,
    0x0, 0xa, 0x87, 0xa0, 0x0, 0xa8, 0x2f, 0x40,
    0x4f, 0x80, 0x5d, 0xfb, 0xa8, 0x0, 0x0, 0x9,
    0x80, 0x0, 0x0, 0x98,

    /* U+72 "r" */
    0xf7, 0xe2, 0xfa, 0x10, 0xf2, 0x0, 0xf1, 0x0,
    0xf1, 0x0, 0xf1, 0x0,

    /* U+73 "s" */
    0x1b, 0xee, 0x90, 0x7a, 0x0, 0x20, 0x5e, 0x74,
    0x0, 0x2, 0x6a, 0xd0, 0x32, 0x1, 0xf1, 0x5d,
    0xee, 0x70,

    /* U+74 "t" */
    0x6, 0x10, 0x0, 0xd3, 0x0, 0xbf, 0xec, 0x0,
    0xd3, 0x0, 0xd, 0x30, 0x0, 0xd3, 0x0, 0xc,
    0x60, 0x0, 0x5e, 0xe1,

    /* U+75 "u" */
    0xf, 0x0, 0xa, 0x70, 0xf0, 0x0, 0xa7, 0xf,
    0x0, 0xa, 0x70, 0xf0, 0x0, 0xa7, 0xd, 0x60,
    0x2f, 0x70, 0x3c, 0xeb, 0xa7,

    /* U+76 "v" */
    0xc, 0x40, 0x1, 0xe0, 0x6, 0xb0, 0x8, 0x80,
    0x0, 0xe2, 0xe, 0x10, 0x0, 0x88, 0x5a, 0x0,
    0x0, 0x1e, 0xc3, 0x0, 0x0, 0xa, 0xd0, 0x0,

};


/*---------------------
 *  GLYPH DESCRIPTION
 *--------------------*/

static const lv_font_fmt_txt_glyph_dsc_t glyph_dsc[] = {
    {.bitmap_index = 0, .adv_w = 0, .box_w = 0, .box_h = 0, .ofs_x = 0, .ofs_y = 0} /* id = 0 reserved */,
    {.bitmap_index = 0, .adv_w = 47, .box_w = 3, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 12, .adv_w = 69, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 4},
    {.bitmap_index = 20, .adv_w = 124, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 52, .adv_w = 109, .box_w = 7, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 94, .adv_w = 148, .box_w = 9, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 130, .adv_w = 121, .box_w = 8, .box_h = 9, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 166, .adv_w = 37, .box_w = 2, .box_h = 4, .ofs_x = 0, .ofs_y = 4},
    {.bitmap_index = 170, .adv_w = 59, .box_w = 3, .box_h = 10, .ofs_x = 1, .ofs_y = -2},
    {.bitmap_index = 185, .adv_w = 59, .box_w = 3, .box_h = 10, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 200, .adv_w = 70, .box_w = 5, .box_h = 5, .ofs_x = 0, .ofs_y = 3},
    {.bitmap_index = 213, .adv_w = 102, .box_w = 6, .box_h = 5, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 228, .adv_w = 67, .box_w = 4, .box_h = 1, .ofs_x = 0, .ofs_y = 3},
    {.bitmap_index = 230, .adv_w = 40, .box_w = 2, .box_h = 2, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 232, .adv_w = 62, .box_w = 6, .box_h = 11, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 265, .adv_w = 117, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 293, .adv_w = 65, .box_w = 3, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 305, .adv_w = 101, .box_w = 6, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 329, .adv_w = 101, .box_w = 6, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 353, .adv_w = 118, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 385, .adv_w = 101, .box_w = 6, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 409, .adv_w = 109, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 437, .adv_w = 105, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 465, .adv_w = 113, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 493, .adv_w = 109, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 521, .adv_w = 40, .box_w = 2, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 527, .adv_w = 40, .box_w = 2, .box_h = 8, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 535, .adv_w = 102, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 553, .adv_w = 102, .box_w = 6, .box_h = 4, .ofs_x = 0, .ofs_y = 2},
    {.bitmap_index = 565, .adv_w = 102, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 583, .adv_w = 101, .box_w = 6, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 607, .adv_w = 182, .box_w = 11, .box_h = 10, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 662, .adv_w = 129, .box_w = 10, .box_h = 8, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 702, .adv_w = 133, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 730, .adv_w = 127, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 762, .adv_w = 145, .box_w = 8, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 794, .adv_w = 118, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 818, .adv_w = 112, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 842, .adv_w = 136, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 874, .adv_w = 143, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 902, .adv_w = 55, .box_w = 2, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 910, .adv_w = 90, .box_w = 6, .box_h = 8, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 934, .adv_w = 127, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 962, .adv_w = 105, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 986, .adv_w = 168, .box_w = 9, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1022, .adv_w = 143, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1050, .adv_w = 148, .box_w = 9, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1086, .adv_w = 127, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1114, .adv_w = 148, .box_w = 10, .box_h = 10, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 1164, .adv_w = 128, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1192, .adv_w = 109, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1220, .adv_w = 103, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1248, .adv_w = 139, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1276, .adv_w = 125, .box_w = 9, .box_h = 8, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 1312, .adv_w = 198, .box_w = 13, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1364, .adv_w = 118, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1396, .adv_w = 114, .box_w = 9, .box_h = 8, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 1432, .adv_w = 116, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1460, .adv_w = 59, .box_w = 3, .box_h = 10, .ofs_x = 1, .ofs_y = -2},
    {.bitmap_index = 1475, .adv_w = 62, .box_w = 6, .box_h = 11, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 1508, .adv_w = 59, .box_w = 3, .box_h = 10, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 1523, .adv_w = 103, .box_w = 6, .box_h = 5, .ofs_x = 0, .ofs_y = 2},
    {.bitmap_index = 1538, .adv_w = 88, .box_w = 6, .box_h = 1, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1541, .adv_w = 106, .box_w = 4, .box_h = 2, .ofs_x = 1, .ofs_y = 7},
    {.bitmap_index = 1545, .adv_w = 105, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1563, .adv_w = 120, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1591, .adv_w = 100, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1609, .adv_w = 120, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1637, .adv_w = 108, .box_w = 7, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1658, .adv_w = 62, .box_w = 5, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1678, .adv_w = 121, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 1706, .adv_w = 120, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1730, .adv_w = 49, .box_w = 3, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1742, .adv_w = 50, .box_w = 5, .box_h = 10, .ofs_x = -2, .ofs_y = -2},
    {.bitmap_index = 1767, .adv_w = 108, .box_w = 6, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1791, .adv_w = 49, .box_w = 2, .box_h = 8, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1799, .adv_w = 186, .box_w = 10, .box_h = 6, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1829, .adv_w = 120, .box_w = 6, .box_h = 6, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1847, .adv_w = 112, .box_w = 7, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1868, .adv_w = 120, .box_w = 7, .box_h = 8, .ofs_x = 1, .ofs_y = -2},
    {.bitmap_index = 1896, .adv_w = 120, .box_w = 7, .box_h = 8, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 1924, .adv_w = 72, .box_w = 4, .box_h = 6, .ofs_x = 1, .ofs_y = 0},
    {.bitmap_index = 1936, .adv_w = 88, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1954, .adv_w = 73, .box_w = 5, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1974, .adv_w = 119, .box_w = 7, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1995, .adv_w = 98, .box_w = 8, .box_h = 6, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 2019, .adv_w = 158, .box_w = 10, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2049, .adv_w = 97, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2067, .adv_w = 98, .box_w = 8, .box_h = 8, .ofs_x = -1, .ofs_y = -2},
    {.bitmap_index = 2099, .adv_w = 92, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2117, .adv_w = 62, .box_w = 4, .box_h = 10, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 2137, .adv_w = 53, .box_w = 2, .box_h = 10, .ofs_x = 1, .ofs_y = -2},
    {.bitmap_index = 2147, .adv_w = 62, .box_w = 4, .box_h = 10, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 2167, .adv_w = 102, .box_w = 6, .box_h = 2, .ofs_x = 0, .ofs_y = 3},
    {.bitmap_index = 2173, .adv_w = 176, .box_w = 11, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 2239, .adv_w = 176, .box_w = 11, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2289, .adv_w = 176, .box_w = 11, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 2344, .adv_w = 176, .box_w = 11, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2394, .adv_w = 121, .box_w = 8, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2426, .adv_w = 176, .box_w = 12, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 2498, .adv_w = 176, .box_w = 11, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 2564, .adv_w = 198, .box_w = 13, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 2629, .adv_w = 176, .box_w = 12, .box_h = 12, .ofs_x = -1, .ofs_y = -2},
    {.bitmap_index = 2701, .adv_w = 198, .box_w = 13, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2760, .adv_w = 176, .box_w = 11, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 2826, .adv_w = 88, .box_w = 6, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 2856, .adv_w = 132, .box_w = 9, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 2901, .adv_w = 198, .box_w = 13, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 2979, .adv_w = 176, .box_w = 11, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 3029, .adv_w = 154, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = -1},
    {.bitmap_index = 3073, .adv_w = 154, .box_w = 10, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 3133, .adv_w = 154, .box_w = 10, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 3183, .adv_w = 154, .box_w = 10, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 3233, .adv_w = 154, .box_w = 8, .box_h = 11, .ofs_x = 1, .ofs_y = -1},
    {.bitmap_index = 3277, .adv_w = 154, .box_w = 11, .box_h = 10, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 3332, .adv_w = 110, .box_w = 7, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 3367, .adv_w = 110, .box_w = 7, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 3402, .adv_w = 154, .box_w = 10, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 3452, .adv_w = 154, .box_w = 10, .box_h = 3, .ofs_x = 0, .ofs_y = 3},
    {.bitmap_index = 3467, .adv_w = 198, .box_w = 13, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 3526, .adv_w = 220, .box_w = 14, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 3610, .adv_w = 198, .box_w = 14, .box_h = 12, .ofs_x = -1, .ofs_y = -2},
    {.bitmap_index = 3694, .adv_w = 176, .box_w = 11, .box_h = 11, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 3755, .adv_w = 154, .box_w = 10, .box_h = 6, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 3785, .adv_w = 154, .box_w = 10, .box_h = 6, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 3815, .adv_w = 220, .box_w = 14, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 3885, .adv_w = 176, .box_w = 11, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 3935, .adv_w = 176, .box_w = 11, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 4001, .adv_w = 176, .box_w = 12, .box_h = 12, .ofs_x = -1, .ofs_y = -2},
    {.bitmap_index = 4073, .adv_w = 154, .box_w = 10, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 4123, .adv_w = 154, .box_w = 10, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 4183, .adv_w = 154, .box_w = 10, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 4233, .adv_w = 110, .box_w = 8, .box_h = 12, .ofs_x = -1, .ofs_y = -2},
    {.bitmap_index = 4281, .adv_w = 154, .box_w = 10, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 4341, .adv_w = 154, .box_w = 10, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 4401, .adv_w = 198, .box_w = 13, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 4460, .adv_w = 176, .box_w = 13, .box_h = 12, .ofs_x = -1, .ofs_y = -2},
    {.bitmap_index = 4538, .adv_w = 132, .box_w = 9, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 4592, .adv_w = 220, .box_w = 14, .box_h = 11, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 4669, .adv_w = 220, .box_w = 14, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 4725, .adv_w = 220, .box_w = 14, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 4781, .adv_w = 220, .box_w = 14, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 4837, .adv_w = 220, .box_w = 14, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 4893, .adv_w = 220, .box_w = 14, .box_h = 8, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 4949, .adv_w = 220, .box_w = 14, .box_h = 10, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 5019, .adv_w = 154, .box_w = 10, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 5079, .adv_w = 154, .box_w = 10, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 5139, .adv_w = 176, .box_w = 12, .box_h = 12, .ofs_x = -1, .ofs_y = -2},
    {.bitmap_index = 5211, .adv_w = 220, .box_w = 14, .box_h = 9, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 5274, .adv_w = 132, .box_w = 9, .box_h = 12, .ofs_x = 0, .ofs_y = -2},
    {.bitmap_index = 5328, .adv_w = 177, .box_w = 12, .box_h = 8, .ofs_x = 0, .ofs_y = 0}
};

/*---------------------
 *  CHARACTER MAPPING
 *--------------------*/

static const uint16_t unicode_list_2[] = {
    0x0, 0x7, 0xa, 0xb, 0xc, 0x10, 0x12, 0x14,
    0x18, 0x1b, 0x20, 0x25, 0x26, 0x27, 0x3d, 0x47,
    0x4a, 0x4b, 0x4c, 0x50, 0x51, 0x52, 0x53, 0x66,
    0x67, 0x6d, 0x6f, 0x70, 0x73, 0x76, 0x77, 0x78,
    0x7a, 0x92, 0x94, 0xc3, 0xc4, 0xc6, 0xe6, 0xe9,
    0xf2, 0x11b, 0x123, 0x15a, 0x1ea, 0x23f, 0x240, 0x241,
    0x242, 0x243, 0x286, 0x292, 0x2ec, 0x303, 0x559, 0x7c1,
    0x8a1
};

/*Collect the unicode lists and glyph_id offsets*/
static const lv_font_fmt_txt_cmap_t cmaps[] =
{
    {
        .range_start = 33, .range_length = 11, .glyph_id_start = 1,
        .unicode_list = NULL, .glyph_id_ofs_list = NULL, .list_length = 0, .type = LV_FONT_FMT_TXT_CMAP_FORMAT0_TINY
    },
    {
        .range_start = 45, .range_length = 82, .glyph_id_start = 12,
        .unicode_list = NULL, .glyph_id_ofs_list = NULL, .list_length = 0, .type = LV_FONT_FMT_TXT_CMAP_FORMAT0_TINY
    },
    {
        .range_start = 61441, .range_length = 2210, .glyph_id_start = 94,
        .unicode_list = unicode_list_2, .glyph_id_ofs_list = NULL, .list_length = 57, .type = LV_FONT_FMT_TXT_CMAP_SPARSE_TINY
    }
};

/*-----------------
 *    KERNING
 *----------------*/


/*Map glyph_ids to kern left classes*/
static const uint8_t kern_left_class_mapping[] =
{
    0, 1, 2, 0, 3, 4, 5, 2,
    6, 7, 8, 9, 9, 10, 11, 12,
    0, 13, 14, 15, 16, 17, 18, 19,
    12, 20, 20, 0, 0, 0, 21, 22,
    23, 24, 25, 22, 26, 27, 28, 29,
    29, 30, 31, 32, 29, 29, 22, 33,
    34, 35, 3, 36, 30, 37, 37, 38,
    39, 40, 41, 42, 43, 0, 44, 0,
    45, 46, 47, 48, 49, 50, 51, 45,
    52, 52, 53, 48, 45, 45, 46, 46,
    54, 55, 56, 57, 51, 58, 58, 59,
    58, 60, 41, 0, 0, 9, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0
};

/*Map glyph_ids to kern right classes*/
static const uint8_t kern_right_class_mapping[] =
{
    0, 1, 2, 0, 3, 4, 5, 2,
    6, 7, 8, 9, 9, 10, 11, 12,
    13, 14, 15, 16, 17, 12, 18, 19,
    20, 21, 21, 0, 0, 0, 22, 23,
    24, 25, 23, 25, 25, 25, 23, 25,
    25, 26, 25, 25, 25, 25, 23, 25,
    23, 25, 3, 27, 28, 29, 29, 30,
    31, 32, 33, 34, 35, 0, 36, 0,
    37, 38, 39, 39, 39, 0, 39, 38,
    40, 41, 38, 38, 42, 42, 39, 42,
    39, 42, 43, 44, 45, 46, 46, 47,
    46, 48, 0, 0, 35, 9, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0
};

/*Kern values between classes*/
static const int8_t kern_class_values[] =
{
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 2, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 8, 0, 5, -4, 0, 0, 0,
    0, -10, -11, 1, 8, 4, 3, -7,
    1, 9, 1, 7, 2, 6, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 11, 1, -1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 0, 0, 0, 0, 0, -4,
    3, 4, 0, 0, -2, 0, -1, 2,
    0, -2, 0, -2, -1, -4, 0, 0,
    0, 0, -2, 0, 0, -2, -3, 0,
    0, -2, 0, -4, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -2, -2, 0,
    0, -5, 0, -21, 0, 0, -4, 0,
    4, 5, 0, 0, -4, 2, 2, 6,
    4, -3, 4, 0, 0, -10, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -7, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -2, -9, 0, -7, -1, 0, 0, 0,
    0, 0, 7, 0, -5, -1, -1, 1,
    0, -3, 0, 0, -1, -13, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -14, -1, 7, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 6, 0, 2, 0, 0, -4,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 7, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -7, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 4, 2, 5, -2, 0, 0, 4,
    -2, -6, -24, 1, 5, 4, 0, -2,
    0, 6, 0, 6, 0, 6, 0, -16,
    0, -2, 5, 0, 6, -2, 4, 2,
    0, 0, 1, -2, 0, 0, -3, 14,
    0, 14, 0, 5, 0, 7, 2, 3,
    0, 0, 0, -7, 0, 0, 0, 0,
    1, -1, 0, 1, -3, -2, -4, 1,
    0, -2, 0, 0, 0, -7, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -11, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    1, -10, 0, -11, 0, 0, 0, 0,
    -1, 0, 17, -2, -2, 2, 2, -2,
    0, -2, 2, 0, 0, -9, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -17, 0, 2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 11, 0, 0, -7, 0, 6, 0,
    -12, -17, -12, -4, 5, 0, 0, -12,
    0, 2, -4, 0, -3, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 5, 5, -21, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 1,
    1, -2, -4, 0, -1, -1, -2, 0,
    0, -1, 0, 0, 0, -4, 0, -1,
    0, -4, -4, 0, -4, -6, -6, -3,
    0, -4, 0, -4, 0, 0, 0, 0,
    -1, 0, 0, 2, 0, 1, -2, 0,
    0, 0, 0, 2, -1, 0, 0, 0,
    -1, 2, 2, -1, 0, 0, 0, -3,
    0, -1, 0, 0, 0, 0, 0, 1,
    0, 2, -1, 0, -2, 0, -3, 0,
    0, -1, 0, 5, 0, 0, -2, 0,
    0, 0, 0, 0, -1, 1, -1, -1,
    0, -2, 0, -2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    -2, -2, 0, 0, 0, 0, 0, 1,
    0, 0, -1, 0, -2, -2, -2, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, 0, 0, -1, -2, 0,
    0, -5, -1, -5, 4, 0, 0, -4,
    2, 4, 5, 0, -4, -1, -2, 0,
    -1, -8, 2, -1, 1, -9, 2, 0,
    0, 1, -9, 0, -9, -1, -15, -1,
    0, -9, 0, 4, 5, 0, 2, 0,
    0, 0, 0, 0, 0, -3, -2, 0,
    0, 0, 0, -2, 0, 0, 0, -2,
    0, 0, 0, 0, 0, -1, -1, 0,
    -1, -2, 0, 0, 0, 0, 0, 0,
    0, -2, -2, 0, -1, -2, -1, 0,
    0, -2, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    0, -1, 0, -4, 2, 0, 0, -2,
    1, 2, 2, 0, 0, 0, 0, 0,
    0, -1, 0, 0, 0, 0, 0, 1,
    0, 0, -2, 0, -2, -1, -2, 0,
    0, 0, 0, 0, 0, 0, 1, 0,
    -1, 0, 0, 0, 0, -2, -3, 0,
    0, 5, -1, 1, -6, 0, 0, 5,
    -9, -9, -7, -4, 2, 0, -1, -11,
    -3, 0, -3, 0, -4, 3, -3, -11,
    0, -5, 0, 0, 1, -1, 1, -1,
    0, 2, 0, -5, -7, 0, -9, -4,
    -4, -4, -5, -2, -5, 0, -3, -5,
    0, 1, 0, -2, 0, 0, 0, 1,
    0, 2, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -2, 0, -1,
    0, -1, -2, 0, -3, -4, -4, -1,
    0, -5, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, 0, 0, 1, -1, 0,
    0, 2, 0, 0, 0, 0, 0, 0,
    0, 0, 8, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, -2, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -3, 0, 2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, 0, -3, 0, 0, 0,
    0, -9, -5, 0, 0, 0, -3, -9,
    0, 0, -2, 2, 0, -5, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -3, 0, 0, -3, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -3, 0, 0, 0, 0, 2, 0,
    1, -4, -4, 0, -2, -2, -2, 0,
    0, 0, 0, 0, 0, -5, 0, -2,
    0, -3, -2, 0, -4, -4, -5, -1,
    0, -4, 0, -5, 0, 0, 0, 0,
    14, 0, 0, 1, 0, 0, -2, 0,
    0, -8, 0, 0, 0, 0, 0, -16,
    -3, 6, 5, -1, -7, 0, 2, -3,
    0, -9, -1, -2, 2, -12, -2, 2,
    0, 3, -6, -3, -7, -6, -7, 0,
    0, -11, 0, 10, 0, 0, -1, 0,
    0, 0, -1, -1, -2, -5, -6, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -2, 0, -1, -2, -3, 0,
    0, -4, 0, -2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, -4, 0, 0, 4,
    -1, 2, 0, -4, 2, -1, -1, -5,
    -2, 0, -2, -2, -1, 0, -3, -3,
    0, 0, -1, -1, -1, -3, -2, 0,
    0, -2, 0, 2, -1, 0, -4, 0,
    0, 0, -4, 0, -3, 0, -3, -3,
    0, 0, 0, 0, 0, 0, 0, 0,
    -4, 2, 0, -2, 0, -1, -2, -5,
    -1, -1, -1, -1, -1, -2, -1, 0,
    0, 0, 0, 0, -2, -1, -1, 0,
    0, 0, 0, 2, -1, 0, -1, 0,
    0, 0, -1, -2, -1, -2, -2, -2,
    1, 7, -1, 0, -5, 0, -1, 4,
    0, -2, -7, -2, 3, 0, 0, -8,
    -3, 2, -3, 1, 0, -1, -1, -6,
    0, -3, 1, 0, 0, -3, 0, 0,
    0, 2, 2, -4, -3, 0, -3, -2,
    -3, -2, -2, 0, -3, 1, -3, -3,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 2, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -3, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, -2, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, -3,
    0, 0, -2, 0, 0, -2, -2, 0,
    0, 0, 0, -2, 0, 0, 0, 0,
    -1, 0, 0, 0, 0, 0, -1, 0,
    0, 0, -3, 0, -4, 0, 0, 0,
    -6, 0, 1, -4, 4, 0, -1, -8,
    0, 0, -4, -2, 0, -7, -4, -5,
    0, 0, -8, -2, -7, -7, -8, 0,
    -5, 0, 1, 12, -2, 0, -4, -2,
    -1, -2, -3, -5, -3, -7, -7, -4,
    0, 0, -1, 0, 1, 0, 0, -12,
    -2, 5, 4, -4, -7, 0, 1, -5,
    0, -9, -1, -2, 4, -16, -2, 1,
    0, 0, -11, -2, -9, -2, -13, 0,
    0, -12, 0, 10, 1, 0, -1, 0,
    0, 0, 0, -1, -1, -7, -1, 0,
    0, 0, 0, 0, -6, 0, -2, 0,
    -1, -5, -8, 0, 0, -1, -3, -5,
    -2, 0, -1, 0, 0, 0, 0, -8,
    -2, -6, -6, -1, -3, -4, -2, -3,
    0, -4, -2, -6, -3, 0, -2, -3,
    -2, -3, 0, 1, 0, -1, -6, 0,
    0, -3, 0, 0, 0, 0, 2, 0,
    1, -4, 7, 0, -2, -2, -2, 0,
    0, 0, 0, 0, 0, -5, 0, -2,
    0, -3, -2, 0, -4, -4, -5, -1,
    0, -4, 1, 7, 0, 0, 0, 0,
    14, 0, 0, 1, 0, 0, -2, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, -1, -4,
    0, 0, 0, 0, 0, -1, 0, 0,
    0, -2, -2, 0, 0, -4, -2, 0,
    0, -4, 0, 3, -1, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0,
    4, 1, -2, 0, -6, -3, 0, 5,
    -6, -6, -4, -4, 7, 3, 2, -15,
    -1, 4, -2, 0, -2, 2, -2, -6,
    0, -2, 2, -2, -1, -5, -1, 0,
    0, 5, 4, 0, -5, 0, -10, -2,
    5, -2, -7, 1, -2, -6, -6, -2,
    2, 0, -3, 0, -5, 0, 1, 6,
    -4, -7, -7, -4, 5, 0, 1, -13,
    -1, 2, -3, -1, -4, 0, -4, -7,
    -3, -3, -1, 0, 0, -4, -4, -2,
    0, 5, 4, -2, -10, 0, -10, -2,
    0, -6, -10, -1, -6, -3, -6, -5,
    0, 0, -2, 0, -4, -2, 0, -2,
    -3, 0, 3, -6, 2, 0, 0, -9,
    0, -2, -4, -3, -1, -5, -4, -6,
    -4, 0, -5, -2, -4, -3, -5, -2,
    0, 0, 1, 8, -3, 0, -5, -2,
    0, -2, -4, -4, -5, -5, -7, -2,
    4, 0, -3, 0, -9, -2, 1, 4,
    -6, -7, -4, -6, 6, -2, 1, -16,
    -3, 4, -4, -3, -7, 0, -5, -7,
    -2, -2, -1, -2, -4, -5, -1, 0,
    0, 5, 5, -1, -11, 0, -11, -4,
    4, -7, -12, -4, -6, -7, -9, -6,
    0, 0, 0, 0, -2, 0, 0, 2,
    -2, 4, 1, -3, 4, 0, 0, -5,
    -1, 0, -1, 0, 1, 1, -1, 0,
    0, 0, 0, 0, 0, -2, 0, 0,
    0, 0, 1, 5, 0, 0, -2, 0,
    0, 0, 0, -1, -1, -2, 0, 0,
    1, 1, 0, 0, 0, 0, 1, 0,
    -1, 0, 7, 0, 3, 1, 1, -2,
    0, 4, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 5, 0, 5, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -11, 0, -2, 3, 0, 5, 0,
    0, 17, 2, -4, -4, 2, 2, -1,
    1, -9, 0, 0, 8, -11, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -12, 7, 25, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -3, 0, 0, -3, -2, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, 0, -5, 0, 0, 1, 0,
    0, 2, 23, -4, -1, 6, 5, -5,
    2, 0, 0, 2, 2, -2, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -23, 5, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, -5, 0, 0, 0, -5,
    0, 0, 0, 0, -4, -1, 0, 0,
    0, -4, 0, -2, 0, -8, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -12, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, -2, 0, 0,
    0, -3, 0, -5, 0, 0, 0, -3,
    2, -2, 0, 0, -5, -2, -4, 0,
    0, -5, 0, -2, 0, -8, 0, -2,
    0, 0, -14, -3, -7, -2, -6, 0,
    0, -12, 0, -5, -1, 0, 0, 0,
    0, 0, 0, 0, 0, -3, -3, -1,
    0, 0, 0, 0, -4, 0, -4, 2,
    -2, 4, 0, -1, -4, -1, -3, -3,
    0, -2, -1, -1, 1, -5, -1, 0,
    0, 0, -15, -1, -2, 0, -4, 0,
    -1, -8, -2, 0, 0, -1, -1, 0,
    0, 0, 0, 1, 0, -1, -3, -1,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 2, 0, 0, 0, 0,
    0, -4, 0, -1, 0, 0, 0, -4,
    2, 0, 0, 0, -5, -2, -4, 0,
    0, -5, 0, -2, 0, -8, 0, 0,
    0, 0, -17, 0, -4, -7, -9, 0,
    0, -12, 0, -1, -3, 0, 0, 0,
    0, 0, 0, 0, 0, -2, -3, -1,
    1, 0, 0, 3, -2, 0, 5, 9,
    -2, -2, -5, 2, 9, 3, 4, -5,
    2, 7, 2, 5, 4, 5, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 11, 8, -3, -2, 0, -1, 14,
    8, 14, 0, 0, 0, 2, 0, 0,
    0, 0, -3, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 2, 0, 0,
    0, 0, -15, -2, -1, -7, -9, 0,
    0, -12, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -3, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 2, 0, 0,
    0, 0, -15, -2, -1, -7, -9, 0,
    0, -7, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    -4, 2, 0, -2, 1, 3, 2, -5,
    0, 0, -1, 2, 0, 1, 0, 0,
    0, 0, -4, 0, -2, -1, -4, 0,
    -2, -7, 0, 11, -2, 0, -4, -1,
    0, -1, -3, 0, -2, -5, -4, -2,
    0, 0, -3, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 2, 0, 0,
    0, 0, -15, -2, -1, -7, -9, 0,
    0, -12, 0, 0, 0, 0, 0, 0,
    9, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -3, 0, -6, -2, -2, 5,
    -2, -2, -7, 1, -1, 1, -1, -5,
    0, 4, 0, 1, 1, 1, -4, -7,
    -2, 0, -7, -3, -5, -7, -7, 0,
    -3, -4, -2, -2, -1, -1, -2, -1,
    0, -1, -1, 3, 0, 3, -1, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, -2, -2, 0,
    0, -5, 0, -1, 0, -3, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -11, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -2, -2, 0,
    0, 0, 0, 0, -1, 0, 0, -3,
    -2, 2, 0, -3, -3, -1, 0, -5,
    -1, -4, -1, -2, 0, -3, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -12, 0, 6, 0, 0, -3, 0,
    0, 0, 0, -2, 0, -2, 0, 0,
    0, 0, -1, 0, -4, 0, 0, 7,
    -2, -6, -5, 1, 2, 2, 0, -5,
    1, 3, 1, 5, 1, 6, -1, -5,
    0, 0, -7, 0, 0, -5, -5, 0,
    0, -4, 0, -2, -3, 0, -3, 0,
    -3, 0, -1, 3, 0, -1, -5, -2,
    0, 0, -2, 0, -4, 0, 0, 2,
    -4, 0, 2, -2, 1, 0, 0, -6,
    0, -1, -1, 0, -2, 2, -1, 0,
    0, 0, -7, -2, -4, 0, -5, 0,
    0, -8, 0, 7, -2, 0, -3, 0,
    1, 0, -2, 0, -2, -5, 0, -2,
    0, 0, 0, 0, -1, 0, 0, 2,
    -2, 1, 0, 0, -2, -1, 0, -2,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -11, 0, 4, 0, 0, -1, 0,
    0, 0, 0, 0, 0, -2, -2, 0
};


/*Collect the kern class' data in one place*/
static const lv_font_fmt_txt_kern_classes_t kern_classes =
{
    .class_pair_values   = kern_class_values,
    .left_class_mapping  = kern_left_class_mapping,
    .right_class_mapping = kern_right_class_mapping,
    .left_class_cnt      = 60,
    .right_class_cnt     = 48,
};

/*--------------------
 *  ALL CUSTOM DATA
 *--------------------*/

/*Store all the custom data of the font*/
static lv_font_fmt_txt_dsc_t font_dsc = {
    .glyph_bitmap = gylph_bitmap,
    .glyph_dsc = glyph_dsc,
    .cmaps = cmaps,
    .kern_dsc = &kern_classes,
    .kern_scale = 16,
    .cmap_num = 3,
    .bpp = 4,
    .kern_classes = 1,
    .bitmap_format = 0
};


/*-----------------
 *  PUBLIC FONT
 *----------------*/

/*Initialize a public general font descriptor*/
lv_font_t lv_font_montserratMedium_11 = {
    .get_glyph_dsc = lv_font_get_glyph_dsc_fmt_txt,    /*Function pointer to get glyph's data*/
    .get_glyph_bitmap = lv_font_get_bitmap_fmt_txt,    /*Function pointer to get glyph's bitmap*/
    .line_height = 12,          /*The maximum line height required by the font*/
    .base_line = 2,             /*Baseline measured from the bottom of the line*/
#if !(LVGL_VERSION_MAJOR == 6 && LVGL_VERSION_MINOR == 0)
    .subpx = LV_FONT_SUBPX_NONE,
#endif
#if LV_VERSION_CHECK(7, 4, 0)
    .underline_position = -1,
    .underline_thickness = 1,
#endif
    .dsc = &font_dsc           /*The custom font data. Will be accessed by `get_glyph_bitmap/dsc` */
};



#endif /*#if LV_FONT_MONTSERRATMEDIUM_11*/

