#include "lvgl.h"

/*******************************************************************************
 * Size: 5 px
 * Bpp: 4
 * Opts: 
 ******************************************************************************/

#ifndef LV_FONT_MONTSERRATMEDIUM_5
#define LV_FONT_MONTSERRATMEDIUM_5 1
#endif

#if LV_FONT_MONTSERRATMEDIUM_5

/*-----------------
 *    BITMAPS
 *----------------*/

/*Store the image of the glyphs*/
static LV_ATTRIBUTE_LARGE_CONST const uint8_t gylph_bitmap[] = {
    /* U+20 " " */

    /* U+21 "!" */
    0x87, 0x45,

    /* U+22 "\"" */
    0x66, 0x33,

    /* U+23 "#" */
    0x5, 0x50, 0x49, 0x92, 0x68, 0x91, 0x31, 0x50,

    /* U+24 "$" */
    0x2, 0x6, 0xa5, 0x78, 0x0, 0x79, 0x6a, 0x80,
    0x20,

    /* U+25 "%" */
    0x55, 0x33, 0x4, 0x56, 0x0, 0x38, 0x45, 0x1,
    0x54, 0x60,

    /* U+26 "&" */
    0x27, 0x40, 0x2a, 0x20, 0x75, 0x90, 0x77, 0x92,
    0x0, 0x0,

    /* U+27 "'" */
    0x63,

    /* U+28 "(" */
    0x25, 0x60, 0x70, 0x60, 0x25,

    /* U+29 ")" */
    0x70, 0x51, 0x43, 0x51, 0x70,

    /* U+2A "*" */
    0x66, 0x66, 0x0,

    /* U+2B "+" */
    0x3, 0x4, 0xa4, 0x6, 0x0,

    /* U+2D "-" */
    0x54,

    /* U+2E "." */
    0x50,

    /* U+2F "/" */
    0x0, 0x30, 0x6, 0x1, 0x50, 0x50, 0x6, 0x0,
    0x60,

    /* U+30 "0" */
    0x48, 0x70, 0x70, 0x70, 0x70, 0x70, 0x48, 0x70,

    /* U+31 "1" */
    0x95, 0x25, 0x25, 0x25,

    /* U+32 "2" */
    0x68, 0x40, 0x16, 0x8, 0xa, 0x85,

    /* U+33 "3" */
    0x6a, 0x50, 0xa0, 0x3, 0x87, 0x85,

    /* U+34 "4" */
    0x5, 0x20, 0x35, 0x30, 0x87, 0xb2, 0x0, 0x70,

    /* U+35 "5" */
    0x78, 0x46, 0x73, 0x0, 0x87, 0x85,

    /* U+36 "6" */
    0x37, 0x58, 0x75, 0xa0, 0x84, 0x87,

    /* U+37 "7" */
    0xa8, 0xa1, 0x25, 0x7, 0x0, 0x70,

    /* U+38 "8" */
    0x67, 0x86, 0x89, 0x80, 0x86, 0x78,

    /* U+39 "9" */
    0x67, 0x58, 0xa, 0x47, 0x94, 0x74,

};


/*---------------------
 *  GLYPH DESCRIPTION
 *--------------------*/

static const lv_font_fmt_txt_glyph_dsc_t glyph_dsc[] = {
    {.bitmap_index = 0, .adv_w = 0, .box_w = 0, .box_h = 0, .ofs_x = 0, .ofs_y = 0} /* id = 0 reserved */,
    {.bitmap_index = 0, .adv_w = 22, .box_w = 0, .box_h = 0, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 0, .adv_w = 21, .box_w = 1, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 2, .adv_w = 31, .box_w = 2, .box_h = 2, .ofs_x = 0, .ofs_y = 2},
    {.bitmap_index = 4, .adv_w = 56, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 12, .adv_w = 50, .box_w = 3, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 21, .adv_w = 67, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 31, .adv_w = 55, .box_w = 4, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 41, .adv_w = 17, .box_w = 1, .box_h = 2, .ofs_x = 0, .ofs_y = 2},
    {.bitmap_index = 42, .adv_w = 27, .box_w = 2, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 47, .adv_w = 27, .box_w = 2, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 52, .adv_w = 32, .box_w = 2, .box_h = 3, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 55, .adv_w = 47, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 60, .adv_w = 31, .box_w = 2, .box_h = 1, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 61, .adv_w = 18, .box_w = 1, .box_h = 1, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 62, .adv_w = 28, .box_w = 3, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 71, .adv_w = 53, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 79, .adv_w = 30, .box_w = 2, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 83, .adv_w = 46, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 89, .adv_w = 46, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 95, .adv_w = 54, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 103, .adv_w = 46, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 109, .adv_w = 49, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 115, .adv_w = 48, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 121, .adv_w = 52, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 127, .adv_w = 49, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 133, .adv_w = 18, .box_w = 1, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 135, .adv_w = 18, .box_w = 1, .box_h = 4, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 137, .adv_w = 47, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 143, .adv_w = 47, .box_w = 3, .box_h = 2, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 146, .adv_w = 47, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 152, .adv_w = 46, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 158, .adv_w = 83, .box_w = 5, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 171, .adv_w = 59, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 179, .adv_w = 61, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 187, .adv_w = 58, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 195, .adv_w = 66, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 203, .adv_w = 54, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 211, .adv_w = 51, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 217, .adv_w = 62, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 225, .adv_w = 65, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 233, .adv_w = 25, .box_w = 2, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 237, .adv_w = 41, .box_w = 4, .box_h = 4, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 245, .adv_w = 58, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 253, .adv_w = 48, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 259, .adv_w = 76, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 269, .adv_w = 65, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 277, .adv_w = 67, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 285, .adv_w = 58, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 293, .adv_w = 67, .box_w = 5, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 306, .adv_w = 58, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 314, .adv_w = 50, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 320, .adv_w = 47, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 326, .adv_w = 63, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 334, .adv_w = 57, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 342, .adv_w = 90, .box_w = 6, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 354, .adv_w = 54, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 362, .adv_w = 52, .box_w = 5, .box_h = 4, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 372, .adv_w = 53, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 380, .adv_w = 27, .box_w = 2, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 385, .adv_w = 28, .box_w = 3, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 394, .adv_w = 27, .box_w = 2, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 399, .adv_w = 47, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 404, .adv_w = 40, .box_w = 3, .box_h = 1, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 406, .adv_w = 48, .box_w = 2, .box_h = 1, .ofs_x = 0, .ofs_y = 3},
    {.bitmap_index = 407, .adv_w = 48, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 412, .adv_w = 55, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 420, .adv_w = 46, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 425, .adv_w = 55, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 431, .adv_w = 49, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 436, .adv_w = 28, .box_w = 2, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 440, .adv_w = 55, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 446, .adv_w = 54, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 452, .adv_w = 22, .box_w = 2, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 456, .adv_w = 23, .box_w = 3, .box_h = 5, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 464, .adv_w = 49, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 472, .adv_w = 22, .box_w = 1, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 474, .adv_w = 85, .box_w = 5, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 482, .adv_w = 54, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 487, .adv_w = 51, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 492, .adv_w = 55, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 500, .adv_w = 55, .box_w = 3, .box_h = 4, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 506, .adv_w = 33, .box_w = 2, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 509, .adv_w = 40, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 514, .adv_w = 33, .box_w = 2, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 518, .adv_w = 54, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 523, .adv_w = 45, .box_w = 4, .box_h = 3, .ofs_x = -1, .ofs_y = 0},
    {.bitmap_index = 529, .adv_w = 72, .box_w = 5, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 537, .adv_w = 44, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 542, .adv_w = 45, .box_w = 4, .box_h = 4, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 550, .adv_w = 42, .box_w = 3, .box_h = 3, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 555, .adv_w = 28, .box_w = 2, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 560, .adv_w = 24, .box_w = 1, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 563, .adv_w = 28, .box_w = 2, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 568, .adv_w = 47, .box_w = 3, .box_h = 2, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 571, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 586, .adv_w = 80, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 596, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 611, .adv_w = 80, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 621, .adv_w = 55, .box_w = 4, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 629, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 644, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 659, .adv_w = 90, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 677, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 692, .adv_w = 90, .box_w = 6, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 704, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 719, .adv_w = 40, .box_w = 3, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 727, .adv_w = 60, .box_w = 4, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 737, .adv_w = 90, .box_w = 6, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 755, .adv_w = 80, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 765, .adv_w = 70, .box_w = 4, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 777, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 792, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 807, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 822, .adv_w = 70, .box_w = 4, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 834, .adv_w = 70, .box_w = 6, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 852, .adv_w = 50, .box_w = 3, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 860, .adv_w = 50, .box_w = 3, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 868, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 883, .adv_w = 70, .box_w = 5, .box_h = 2, .ofs_x = 0, .ofs_y = 1},
    {.bitmap_index = 888, .adv_w = 90, .box_w = 6, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 900, .adv_w = 100, .box_w = 7, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 921, .adv_w = 90, .box_w = 7, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 942, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 957, .adv_w = 70, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 967, .adv_w = 70, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 977, .adv_w = 100, .box_w = 7, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 991, .adv_w = 80, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1001, .adv_w = 80, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1016, .adv_w = 80, .box_w = 6, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 1034, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1049, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1064, .adv_w = 70, .box_w = 5, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1077, .adv_w = 50, .box_w = 5, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 1092, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1107, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1122, .adv_w = 90, .box_w = 6, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1134, .adv_w = 80, .box_w = 7, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 1155, .adv_w = 60, .box_w = 4, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1167, .adv_w = 100, .box_w = 7, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1188, .adv_w = 100, .box_w = 7, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1202, .adv_w = 100, .box_w = 7, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1216, .adv_w = 100, .box_w = 7, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1230, .adv_w = 100, .box_w = 7, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1244, .adv_w = 100, .box_w = 7, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1258, .adv_w = 100, .box_w = 7, .box_h = 5, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1276, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1291, .adv_w = 70, .box_w = 5, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1306, .adv_w = 80, .box_w = 6, .box_h = 6, .ofs_x = -1, .ofs_y = -1},
    {.bitmap_index = 1324, .adv_w = 100, .box_w = 7, .box_h = 4, .ofs_x = 0, .ofs_y = 0},
    {.bitmap_index = 1338, .adv_w = 60, .box_w = 4, .box_h = 6, .ofs_x = 0, .ofs_y = -1},
    {.bitmap_index = 1350, .adv_w = 80, .box_w = 5, .box_h = 4, .ofs_x = 0, .ofs_y = 0}
};

/*---------------------
 *  CHARACTER MAPPING
 *--------------------*/

static const uint16_t unicode_list_2[] = {
    0x0, 0x7, 0xa, 0xb, 0xc, 0x10, 0x12, 0x14,
    0x18, 0x1b, 0x20, 0x25, 0x26, 0x27, 0x3d, 0x47,
    0x4a, 0x4b, 0x4c, 0x50, 0x51, 0x52, 0x53, 0x66,
    0x67, 0x6d, 0x6f, 0x70, 0x73, 0x76, 0x77, 0x78,
    0x7a, 0x92, 0x94, 0xc3, 0xc4, 0xc6, 0xe6, 0xe9,
    0xf2, 0x11b, 0x123, 0x15a, 0x1ea, 0x23f, 0x240, 0x241,
    0x242, 0x243, 0x286, 0x292, 0x2ec, 0x303, 0x559, 0x7c1,
    0x8a1
};

/*Collect the unicode lists and glyph_id offsets*/
static const lv_font_fmt_txt_cmap_t cmaps[] =
{
    {
        .range_start = 32, .range_length = 12, .glyph_id_start = 1,
        .unicode_list = NULL, .glyph_id_ofs_list = NULL, .list_length = 0, .type = LV_FONT_FMT_TXT_CMAP_FORMAT0_TINY
    },
    {
        .range_start = 45, .range_length = 82, .glyph_id_start = 13,
        .unicode_list = NULL, .glyph_id_ofs_list = NULL, .list_length = 0, .type = LV_FONT_FMT_TXT_CMAP_FORMAT0_TINY
    },
    {
        .range_start = 61441, .range_length = 2210, .glyph_id_start = 95,
        .unicode_list = unicode_list_2, .glyph_id_ofs_list = NULL, .list_length = 57, .type = LV_FONT_FMT_TXT_CMAP_SPARSE_TINY
    }
};

/*-----------------
 *    KERNING
 *----------------*/


/*Map glyph_ids to kern left classes*/
static const uint8_t kern_left_class_mapping[] =
{
    0, 0, 1, 2, 0, 3, 4, 5,
    2, 6, 7, 8, 9, 9, 10, 11,
    12, 0, 13, 14, 15, 16, 17, 18,
    19, 12, 20, 20, 0, 0, 0, 21,
    22, 23, 24, 25, 22, 26, 27, 28,
    29, 29, 30, 31, 32, 29, 29, 22,
    33, 34, 35, 3, 36, 30, 37, 37,
    38, 39, 40, 41, 42, 43, 0, 44,
    0, 45, 46, 47, 48, 49, 50, 51,
    45, 52, 52, 53, 48, 45, 45, 46,
    46, 54, 55, 56, 57, 51, 58, 58,
    59, 58, 60, 41, 0, 0, 9, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0
};

/*Map glyph_ids to kern right classes*/
static const uint8_t kern_right_class_mapping[] =
{
    0, 0, 1, 2, 0, 3, 4, 5,
    2, 6, 7, 8, 9, 9, 10, 11,
    12, 13, 14, 15, 16, 17, 12, 18,
    19, 20, 21, 21, 0, 0, 0, 22,
    23, 24, 25, 23, 25, 25, 25, 23,
    25, 25, 26, 25, 25, 25, 25, 23,
    25, 23, 25, 3, 27, 28, 29, 29,
    30, 31, 32, 33, 34, 35, 0, 36,
    0, 37, 38, 39, 39, 39, 0, 39,
    38, 40, 41, 38, 38, 42, 42, 39,
    42, 39, 42, 43, 44, 45, 46, 46,
    47, 46, 48, 0, 0, 35, 9, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0
};

/*Kern values between classes*/
static const int8_t kern_class_values[] =
{
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 4, 0, 2, -2, 0, 0, 0,
    0, -4, -5, 1, 4, 2, 1, -3,
    1, 4, 0, 3, 1, 3, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 5, 1, -1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -2, 0, 0, 0, 0, 0, -2,
    1, 2, 0, 0, -1, 0, -1, 1,
    0, -1, 0, -1, 0, -2, 0, 0,
    0, 0, -1, 0, 0, -1, -1, 0,
    0, -1, 0, -2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    0, -2, 0, -10, 0, 0, -2, 0,
    2, 2, 0, 0, -2, 1, 1, 3,
    2, -1, 2, 0, 0, -5, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -3, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -1, -4, 0, -3, -1, 0, 0, 0,
    0, 0, 3, 0, -2, -1, 0, 0,
    0, -1, 0, 0, -1, -6, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -6, -1, 3, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 3, 0, 1, 0, 0, -2,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 3, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -3, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 2, 1, 2, -1, 0, 0, 2,
    -1, -3, -11, 1, 2, 2, 0, -1,
    0, 3, 0, 3, 0, 3, 0, -7,
    0, -1, 2, 0, 3, -1, 2, 1,
    0, 0, 0, -1, 0, 0, -1, 6,
    0, 6, 0, 2, 0, 3, 1, 1,
    0, 0, 0, -3, 0, 0, 0, 0,
    0, -1, 0, 1, -1, -1, -2, 1,
    0, -1, 0, 0, 0, -3, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -4, 0, -5, 0, 0, 0, 0,
    -1, 0, 8, -1, -1, 1, 1, -1,
    0, -1, 1, 0, 0, -4, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -8, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 5, 0, 0, -3, 0, 3, 0,
    -5, -8, -5, -2, 2, 0, 0, -5,
    0, 1, -2, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 2, 2, -10, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 1,
    1, -1, -2, 0, 0, 0, -1, 0,
    0, -1, 0, 0, 0, -2, 0, -1,
    0, -2, -2, 0, -2, -3, -3, -2,
    0, -2, 0, -2, 0, 0, 0, 0,
    -1, 0, 0, 1, 0, 1, -1, 0,
    0, 0, 0, 1, -1, 0, 0, 0,
    -1, 1, 1, 0, 0, 0, 0, -2,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, -1, 0, -1, 0, -1, 0,
    0, -1, 0, 2, 0, 0, -1, 0,
    0, 0, 0, 0, 0, 0, -1, -1,
    0, -1, 0, -1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -1, -1, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, -1, -1, -1, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    0, -2, -1, -2, 2, 0, 0, -2,
    1, 2, 2, 0, -2, 0, -1, 0,
    0, -4, 1, -1, 1, -4, 1, 0,
    0, 0, -4, 0, -4, -1, -7, -1,
    0, -4, 0, 2, 2, 0, 1, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    0, 0, 0, -1, 0, 0, 0, -1,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, 0, 0, 0, 0, 0, 0,
    0, -1, -1, 0, -1, -1, -1, 0,
    0, -1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    0, -1, 0, -2, 1, 0, 0, -1,
    0, 1, 1, 0, 0, 0, 0, 0,
    0, -1, 0, 0, 0, 0, 0, 1,
    0, 0, -1, 0, -1, -1, -1, 0,
    0, 0, 0, 0, 0, 0, 1, 0,
    -1, 0, 0, 0, 0, -1, -1, 0,
    0, 2, -1, 0, -3, 0, 0, 2,
    -4, -4, -3, -2, 1, 0, -1, -5,
    -1, 0, -1, 0, -2, 1, -1, -5,
    0, -2, 0, 0, 0, 0, 1, -1,
    0, 1, 0, -2, -3, 0, -4, -2,
    -2, -2, -2, -1, -2, 0, -2, -2,
    0, 0, 0, -1, 0, 0, 0, 1,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, 0, 0,
    0, 0, -1, 0, -1, -2, -2, 0,
    0, -2, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 4, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, -1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, 0, -2, 0, 0, 0,
    0, -4, -2, 0, 0, 0, -1, -4,
    0, 0, -1, 1, 0, -2, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    -1, 0, 0, -2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, 0, 0, 0, 0, 1, 0,
    1, -2, -2, 0, -1, -1, -1, 0,
    0, 0, 0, 0, 0, -2, 0, -1,
    0, -1, -1, 0, -2, -2, -2, -1,
    0, -2, 0, -2, 0, 0, 0, 0,
    6, 0, 0, 0, 0, 0, -1, 0,
    0, -3, 0, 0, 0, 0, 0, -7,
    -1, 3, 2, -1, -3, 0, 1, -1,
    0, -4, 0, -1, 1, -6, -1, 1,
    0, 1, -3, -1, -3, -3, -3, 0,
    0, -5, 0, 5, 0, 0, 0, 0,
    0, 0, 0, 0, -1, -2, -3, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, 0, -1, -1, 0,
    0, -2, 0, -1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -2, 0, 0, 2,
    0, 1, 0, -2, 1, -1, 0, -2,
    -1, 0, -1, -1, -1, 0, -1, -1,
    0, 0, -1, 0, -1, -1, -1, 0,
    0, -1, 0, 1, -1, 0, -2, 0,
    0, 0, -2, 0, -1, 0, -1, -1,
    0, 0, 0, 0, 0, 0, 0, 0,
    -2, 1, 0, -1, 0, -1, -1, -2,
    -1, -1, -1, 0, -1, -1, 0, 0,
    0, 0, 0, 0, -1, -1, -1, 0,
    0, 0, 0, 1, -1, 0, -1, 0,
    0, 0, -1, -1, -1, -1, -1, -1,
    1, 3, 0, 0, -2, 0, -1, 2,
    0, -1, -3, -1, 1, 0, 0, -4,
    -1, 1, -1, 1, 0, -1, -1, -3,
    0, -1, 0, 0, 0, -1, 0, 0,
    0, 1, 1, -2, -2, 0, -1, -1,
    -1, -1, -1, 0, -1, 0, -2, -1,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, -1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, -1,
    0, 0, -1, 0, 0, -1, -1, 0,
    0, 0, 0, -1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, -1, 0,
    0, 0, -1, 0, -2, 0, 0, 0,
    -3, 0, 1, -2, 2, 0, -1, -4,
    0, 0, -2, -1, 0, -3, -2, -2,
    0, 0, -3, -1, -3, -3, -4, 0,
    -2, 0, 1, 5, -1, 0, -2, -1,
    0, -1, -1, -2, -1, -3, -3, -2,
    0, 0, -1, 0, 0, 0, 0, -6,
    -1, 2, 2, -2, -3, 0, 0, -2,
    0, -4, -1, -1, 2, -7, -1, 0,
    0, 0, -5, -1, -4, -1, -6, 0,
    0, -6, 0, 5, 0, 0, -1, 0,
    0, 0, 0, 0, -1, -3, -1, 0,
    0, 0, 0, 0, -3, 0, -1, 0,
    0, -2, -4, 0, 0, 0, -1, -2,
    -1, 0, -1, 0, 0, 0, 0, -4,
    -1, -3, -3, -1, -1, -2, -1, -1,
    0, -2, -1, -3, -1, 0, -1, -2,
    -1, -2, 0, 0, 0, -1, -3, 0,
    0, -1, 0, 0, 0, 0, 1, 0,
    1, -2, 3, 0, -1, -1, -1, 0,
    0, 0, 0, 0, 0, -2, 0, -1,
    0, -1, -1, 0, -2, -2, -2, -1,
    0, -2, 1, 3, 0, 0, 0, 0,
    6, 0, 0, 0, 0, 0, -1, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, -1, -2,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, -1, 0, 0, -2, -1, 0,
    0, -2, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    2, 1, -1, 0, -3, -1, 0, 2,
    -3, -3, -2, -2, 3, 1, 1, -7,
    -1, 2, -1, 0, -1, 1, -1, -3,
    0, -1, 1, -1, -1, -2, -1, 0,
    0, 2, 2, 0, -2, 0, -4, -1,
    2, -1, -3, 0, -1, -3, -3, -1,
    1, 0, -1, 0, -2, 0, 1, 3,
    -2, -3, -3, -2, 2, 0, 0, -6,
    -1, 1, -1, -1, -2, 0, -2, -3,
    -1, -1, -1, 0, 0, -2, -2, -1,
    0, 2, 2, -1, -4, 0, -4, -1,
    0, -3, -5, 0, -3, -1, -3, -2,
    0, 0, -1, 0, -2, -1, 0, -1,
    -1, 0, 1, -3, 1, 0, 0, -4,
    0, -1, -2, -1, -1, -2, -2, -3,
    -2, 0, -2, -1, -2, -2, -2, -1,
    0, 0, 0, 4, -1, 0, -2, -1,
    0, -1, -2, -2, -2, -2, -3, -1,
    2, 0, -1, 0, -4, -1, 0, 2,
    -3, -3, -2, -3, 3, -1, 0, -7,
    -1, 2, -2, -1, -3, 0, -2, -3,
    -1, -1, -1, -1, -2, -2, 0, 0,
    0, 2, 2, -1, -5, 0, -5, -2,
    2, -3, -5, -2, -3, -3, -4, -3,
    0, 0, 0, 0, -1, 0, 0, 1,
    -1, 2, 1, -2, 2, 0, 0, -2,
    0, 0, 0, 0, 0, 0, -1, 0,
    0, 0, 0, 0, 0, -1, 0, 0,
    0, 0, 1, 2, 0, 0, -1, 0,
    0, 0, 0, -1, -1, -1, 0, 0,
    0, 1, 0, 0, 0, 0, 1, 0,
    -1, 0, 3, 0, 1, 0, 0, -1,
    0, 2, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 2, 0, 2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 0, -1, 1, 0, 2, 0,
    0, 8, 1, -2, -2, 1, 1, -1,
    0, -4, 0, 0, 4, -5, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 3, 11, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, 0, -2, -1, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -1, 0, -2, 0, 0, 0, 0,
    0, 1, 10, -2, -1, 3, 2, -2,
    1, 0, 0, 1, 1, -1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -10, 2, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, -2, 0, 0, 0, -2,
    0, 0, 0, 0, -2, 0, 0, 0,
    0, -2, 0, -1, 0, -4, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, 0, 0,
    0, -1, 0, -2, 0, 0, 0, -1,
    1, -1, 0, 0, -2, -1, -2, 0,
    0, -2, 0, -1, 0, -4, 0, -1,
    0, 0, -6, -2, -3, -1, -3, 0,
    0, -5, 0, -2, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, -1,
    0, 0, 0, 0, -2, 0, -2, 1,
    -1, 2, 0, -1, -2, -1, -1, -2,
    0, -1, 0, -1, 1, -2, 0, 0,
    0, 0, -7, -1, -1, 0, -2, 0,
    -1, -4, -1, 0, 0, -1, -1, 0,
    0, 0, 0, 1, 0, -1, -1, -1,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0,
    0, -2, 0, -1, 0, 0, 0, -2,
    1, 0, 0, 0, -2, -1, -2, 0,
    0, -2, 0, -1, 0, -4, 0, 0,
    0, 0, -8, 0, -2, -3, -4, 0,
    0, -5, 0, -1, -1, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    0, 0, 0, 1, -1, 0, 2, 4,
    -1, -1, -2, 1, 4, 1, 2, -2,
    1, 3, 1, 2, 2, 2, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 5, 4, -1, -1, 0, -1, 6,
    3, 6, 0, 0, 0, 1, 0, 0,
    0, 0, -1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, -7, -1, -1, -3, -4, 0,
    0, -5, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, -7, -1, -1, -3, -4, 0,
    0, -3, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    -2, 1, 0, -1, 1, 1, 1, -2,
    0, 0, -1, 1, 0, 1, 0, 0,
    0, 0, -2, 0, -1, -1, -2, 0,
    -1, -3, 0, 5, -1, 0, -2, -1,
    0, -1, -1, 0, -1, -2, -2, -1,
    0, 0, -1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, -7, -1, -1, -3, -4, 0,
    0, -5, 0, 0, 0, 0, 0, 0,
    4, 0, 0, 0, 0, 0, 0, 0,
    0, 0, -1, 0, -3, -1, -1, 2,
    -1, -1, -3, 0, 0, 0, -1, -2,
    0, 2, 0, 1, 0, 1, -2, -3,
    -1, 0, -3, -2, -2, -3, -3, 0,
    -1, -2, -1, -1, -1, -1, -1, -1,
    0, -1, 0, 1, 0, 1, -1, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, -1, -1, -1, 0,
    0, -2, 0, 0, 0, -1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, -1, -1, 0,
    0, 0, 0, 0, -1, 0, 0, -1,
    -1, 1, 0, -1, -2, -1, 0, -2,
    -1, -2, -1, -1, 0, -1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 0, 3, 0, 0, -1, 0,
    0, 0, 0, -1, 0, -1, 0, 0,
    0, 0, -1, 0, -2, 0, 0, 3,
    -1, -3, -2, 1, 1, 1, 0, -2,
    1, 1, 1, 2, 1, 3, -1, -2,
    0, 0, -3, 0, 0, -2, -2, 0,
    0, -2, 0, -1, -1, 0, -1, 0,
    -1, 0, -1, 1, 0, -1, -2, -1,
    0, 0, -1, 0, -2, 0, 0, 1,
    -2, 0, 1, -1, 1, 0, 0, -3,
    0, -1, 0, 0, -1, 1, -1, 0,
    0, 0, -3, -1, -2, 0, -2, 0,
    0, -4, 0, 3, -1, 0, -1, 0,
    0, 0, -1, 0, -1, -2, 0, -1,
    0, 0, 0, 0, -1, 0, 0, 1,
    -1, 0, 0, 0, -1, -1, 0, -1,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, -5, 0, 2, 0, 0, -1, 0,
    0, 0, 0, 0, 0, -1, -1, 0
};


/*Collect the kern class' data in one place*/
static const lv_font_fmt_txt_kern_classes_t kern_classes =
{
    .class_pair_values   = kern_class_values,
    .left_class_mapping  = kern_left_class_mapping,
    .right_class_mapping = kern_right_class_mapping,
    .left_class_cnt      = 60,
    .right_class_cnt     = 48,
};

/*--------------------
 *  ALL CUSTOM DATA
 *--------------------*/

/*Store all the custom data of the font*/
static lv_font_fmt_txt_dsc_t font_dsc = {
    .glyph_bitmap = gylph_bitmap,
    .glyph_dsc = glyph_dsc,
    .cmaps = cmaps,
    .kern_dsc = &kern_classes,
    .kern_scale = 16,
    .cmap_num = 3,
    .bpp = 4,
    .kern_classes = 1,
    .bitmap_format = 0
};


/*-----------------
 *  PUBLIC FONT
 *----------------*/

/*Initialize a public general font descriptor*/
lv_font_t lv_font_montserratMedium_5 = {
    .get_glyph_dsc = lv_font_get_glyph_dsc_fmt_txt,    /*Function pointer to get glyph's data*/
    .get_glyph_bitmap = lv_font_get_bitmap_fmt_txt,    /*Function pointer to get glyph's bitmap*/
    .line_height = 6,          /*The maximum line height required by the font*/
    .base_line = 1,             /*Baseline measured from the bottom of the line*/
#if !(LVGL_VERSION_MAJOR == 6 && LVGL_VERSION_MINOR == 0)
    .subpx = LV_FONT_SUBPX_NONE,
#endif
#if LV_VERSION_CHECK(7, 4, 0)
    .underline_position = 0,
    .underline_thickness = 0,
#endif
    .dsc = &font_dsc           /*The custom font data. Will be accessed by `get_glyph_bitmap/dsc` */
};



#endif /*#if LV_FONT_MONTSERRATMEDIUM_5*/

