/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "events_init.h"
#include <stdio.h>
#include "lvgl.h"
#include <stdio.h>

void events_init(lv_ui *ui)
{
}

static void screen_btn_home_event_handler(lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);
	switch (code)
	{
	case LV_EVENT_CLICKED:
	{
		if (!lv_obj_is_valid(guider_ui.home_page)){
		    rt_kprintf("guider_ui.home_page no exist\n");
	        setup_scr_home_page(&guider_ui);
	        rt_kprintf("time_page to home_page:%x",guider_ui.home_page);
		}else{
		    rt_kprintf("guider_ui.home_page exist\n");
		}

		lv_timer_pause(get_time_timer);
		lv_timer_reset(homepage_timer);
		lv_scr_load_anim(guider_ui.home_page, LV_SCR_LOAD_ANIM_FADE_ON, 500, 0, true);
	}
		break;
	default:
		break;
	}
}

void events_init_screen(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->screen_btn_home, screen_btn_home_event_handler, LV_EVENT_ALL, NULL);
}

static void home_page_btn_adjustlight_event_handler(lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);
	switch (code)
	{
	case LV_EVENT_CLICKED:
	{
		if (!lv_obj_is_valid(guider_ui.adjust_light_page))
			setup_scr_adjust_light_page(&guider_ui);
		lv_timer_pause(homepage_timer);
		lv_scr_load_anim(guider_ui.adjust_light_page, LV_SCR_LOAD_ANIM_OVER_LEFT, 500, 0, true);
	}
		break;
	default:
		break;
	}
}

static void home_page_btn_sport_event_handler(lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);
	switch (code)
	{
	case LV_EVENT_CLICKED:
	{
		if (!lv_obj_is_valid(guider_ui.sport_data_page))
			setup_scr_sport_data_page(&guider_ui);
		lv_timer_pause(homepage_timer);
		lv_scr_load_anim(guider_ui.sport_data_page, LV_SCR_LOAD_ANIM_OVER_LEFT, 500, 0, true);
	}
		break;
	default:
		break;
	}
}

void events_init_home_page(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->home_page_btn_adjustlight, home_page_btn_adjustlight_event_handler, LV_EVENT_ALL, NULL);
	lv_obj_add_event_cb(ui->home_page_btn_sport, home_page_btn_sport_event_handler, LV_EVENT_ALL, NULL);
}

static void adjust_light_page_btn_light_set_event_handler(lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);
	switch (code)
	{
	case LV_EVENT_CLICKED:
	{
		if (!lv_obj_is_valid(guider_ui.home_page)){
		    setup_scr_home_page(&guider_ui);
		    rt_kprintf("light_page to home_page:%x",guider_ui.home_page);
		}
		 rt_kprintf("light_page to home_page:%x",guider_ui.home_page);
		 lv_timer_reset(homepage_timer);
		 lv_scr_load_anim(guider_ui.home_page, LV_SCR_LOAD_ANIM_FADE_ON, 500, 0, true);
	}
		break;
	default:
		break;
	}
}

void events_init_adjust_light_page(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->adjust_light_page_btn_light_set, adjust_light_page_btn_light_set_event_handler, LV_EVENT_ALL, NULL);
}

static void sport_data_page_btn_sport_data_page_event_handler(lv_event_t *e)
{
	lv_event_code_t code = lv_event_get_code(e);
	switch (code)
	{
	case LV_EVENT_CLICKED:
	{
		if (!lv_obj_is_valid(guider_ui.home_page))
			setup_scr_home_page(&guider_ui);
		lv_timer_reset(homepage_timer);
		lv_scr_load_anim(guider_ui.home_page, LV_SCR_LOAD_ANIM_FADE_ON, 500, 0, true);
	}
		break;
	default:
		break;
	}
}

void events_init_sport_data_page(lv_ui *ui)
{
	lv_obj_add_event_cb(ui->sport_data_page_btn_sport_data_page, sport_data_page_btn_sport_data_page_event_handler, LV_EVENT_ALL, NULL);
}
