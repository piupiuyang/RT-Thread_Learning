/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"

lv_ui guider_ui;
void setup_ui(lv_ui *guider_ui){
	setup_scr_screen(guider_ui);
	lv_scr_load(guider_ui->screen);
}
